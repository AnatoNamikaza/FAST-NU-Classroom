const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const app = express();
const port = 3000;
const mongoUrl = 'mongodb://localhost:27017';
const dbName = 'blogging_platform';

app.use(express.json());

// MongoDB Connection
let db;

MongoClient.connect(mongoUrl, { useUnifiedTopology: true }, (err, client) => {
  if (err) {
    console.error('Error connecting to MongoDB:', err);
    return;
  }

  console.log('Connected to MongoDB');
  db = client.db(dbName);
});

// GET /posts
app.get('/posts', (req, res) => {
  db.collection('posts')
    .find()
    .toArray((err, posts) => {
      if (err) {
        console.error('Error getting posts:', err);
        res.status(500).json({ error: 'Internal server error' });
        return;
      }

      res.json(posts);
    });
});

// POST /posts
app.post('/posts', (req, res) => {
  const { title, author, date, content } = req.body;

  const newPost = {
    title,
    author,
    date,
    content,
  };

  db.collection('posts').insertOne(newPost, (err, result) => {
    if (err) {
      console.error('Error creating post:', err);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }

    res.status(201).json(result.ops[0]);
  });
});

// PUT /posts/:id
app.put('/posts/:id', (req, res) => {
  const { id } = req.params;
  const { title, author, date, content } = req.body;

  const updatedPost = {
    $set: {
      title,
      author,
      date,
      content,
    },
  };

  db.collection('posts').updateOne({ _id: ObjectId(id) }, updatedPost, (err) => {
    if (err) {
      console.error('Error updating post:', err);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }

    res.sendStatus(204);
  });
});

// DELETE /posts/:id
app.delete('/posts/:id', (req, res) => {
  const { id } = req.params;

  db.collection('posts').deleteOne({ _id: ObjectId(id) }, (err) => {
    if (err) {
      console.error('Error deleting post:', err);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }

    res.sendStatus(204);
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
