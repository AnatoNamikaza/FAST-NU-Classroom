import React from 'react';
import ReactDOM from 'react-dom/client';

// import './index.css';
// //import App from './App';
//import Login from './Login.js~'
// import AddTwo from './components/AddTwoNumbers';
//import UpdateName from './components/UpdateName';
//import click from './components/click';
import reportWebVitals from './reportWebVitals';
//import Calculator from './axios.js';
// const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(
//   <React.StrictMode>
//     <App />
//   </React.StrictMode>
// );
import './components/wishlist.css';
import WishList from './components/wishlist';
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <WishList />
  </React.StrictMode>
);

// const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(
//   <React.StrictMode>
//         <click />
//   </React.StrictMode>
// );

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
