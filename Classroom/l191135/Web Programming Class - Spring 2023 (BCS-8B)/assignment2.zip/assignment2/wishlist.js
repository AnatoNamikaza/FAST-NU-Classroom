import React, { Component } from 'react';

class WishList extends Component {
    constructor(props) {
        super(props);

        this.state = {
            items: [],
            priorityCounter: 0,
            sortedItems: [],
        };

        this.addItem = this.addItem.bind(this);
        this.removeItem = this.removeItem.bind(this);
        this.updatePriority = this.updatePriority.bind(this);
        this.sortItems = this.sortItems.bind(this);
    }

    addItem(name, priority) {
        const newItem = { name, priority, id: Date.now() };
        this.setState((prevState) => ({
            items: [...prevState.items, newItem],
            priorityCounter: prevState.priorityCounter + 1,
        }));
    }

    removeItem(id) {
        this.setState((prevState) => ({
            items: prevState.items.filter((item) => item.id !== id),
        }));
    }

    updatePriority(id, newPriority) {
        this.setState((prevState) => ({
            items: prevState.items.map((item) => {
                if (item.id === id) {
                    return { ...item, priority: newPriority };
                }
                return item;
            }),
        }));
    }

    sortItems() {
        const sorted = [...this.state.items].sort((a, b) => a.priority - b.priority);
        this.setState({
            sortedItems: sorted,
        });
    }

    componentDidMount() {
        this.sortItems();
    }

    componentDidUpdate(prevProps, prevState) {
        if (prevState.items !== this.state.items) {
            this.sortItems();
        }
    }

    render() {
        const { sortedItems } = this.state;

        return (
            <div>
                <h2>Wish List</h2>
                <form onSubmit={(e) => e.preventDefault()}>
                    <label>
                        Item name:
                        <input type="text" name="name" />
                    </label>
                    <label id="priority-lable">
                        Priority:
                        <input type="number" name="priority" min="1" max="10" />
                    </label>
                    <button
                        type="button"
                        onClick={() => {
                            const name = document.getElementsByName('name')[0].value;
                            const priority = Number(document.getElementsByName('priority')[0].value);
                            this.addItem(name, priority);
                        }}
                    >
                        Add Item
                    </button>
                </form>
                <ul>
                    {sortedItems.map((item) => (
                        <li key={item.id}>
                            <span id="item-name">{item.name}</span>
                            <span>
                                Priority:
                                <input
                                    type="number"
                                    value={item.priority}
                                    onChange={(e) => this.updatePriority(item.id, Number(e.target.value))}
                                    min="1"
                                    max="10"
                                />
                            </span>
                            <button type="button" onClick={() => this.removeItem(item.id)}>
                                Remove
                            </button>
                        </li>
                    ))}
                </ul>
                <button type="button">
                    Sort Items
                </button>
            </div>
        );
    }
}

export default WishList;
