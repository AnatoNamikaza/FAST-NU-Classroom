#include <stdio.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <pthread.h>

void * changeCase(void *arg){
	char *map = (char *) arg;

	for (int i = 0; i < 50; i++){
		if (map[i] >= 'A' && map[i] <= 'Z')
			map[i] += 32;
		else if (map[i] >= 'a' && map[i] <= 'z')
			map[i] -= 32;
	}

	return NULL;
}

int main(int argc, char **argv) {
	int fd = open(argv[1], O_RDWR);
	if (fd == -1){
		fprintf(stderr, "File not found / Could not be opened!\n");
		return 1;
	}

	printf("File opened successfully\n");
	char *map = (char *) mmap(NULL, 50, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	close(fd);

	if (map == MAP_FAILED){
		fprintf(stderr, "Could not create memory map!\n");
		return 1;
	}

	pthread_t pid[2];
	if (pthread_create(&pid[0], NULL, &changeCase, map) != 0 || pthread_create(&pid[1], NULL, &changeCase, map + 50) != 0){
		fprintf(stderr, "Thread creation failed!\n");
		return 1;
	}

	pthread_join(pid[0], NULL);
	pthread_join(pid[1], NULL);

	if (munmap(map, 100) == -1){
		fprintf(stderr, "Could not munmap!\n");
		return 1;
	}

	return 0;
}
