#include <iostream>
#include <fstream>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>

using namespace std;

int main(int argc, char *argv[]){
	ifstream fin(argv[1]);
	if (!fin){
		cerr << "File not found / could not be opened!\n";
		return 1;
	}

	int p1[2], p2[2];
	if (pipe(p1) == -1 || pipe(p2) == -1){
		cerr << "Pipe creation failed!\n";
		return 1;
	}

	//Creating backup of fd[1] and redirecting it to write end of p1
	int backup_stdout = dup(1);
	dup2(p1[1], 1);
	close(p1[1]);

	//Reading from input file character by character and writing each character to p1
	char ch;
	int noOfCharacters = 0;
	for ( ; fin.get(ch); ){
		noOfCharacters++;
		cout << ch;
	}

	//Writing '\n' and flushing the buffer and then closing stdout and restoring it.
	cout << endl;
	close(1);
	dup2(backup_stdout, 1);

	pid_t pid = fork();
	if (pid < 0){
		cerr << "Fork failed!\n";
		return 1;
	}

	else if (pid == 0){
		close(p1[1]);
		close(p2[0]);

		//Redirect stdin to read end of p1 and stdout to write end of p2
		dup2(p1[0], 0);
		dup2(p2[1], 1);

		close(p1[0]);
		close(p2[1]);

		//Reading from p1 character by character and changing the case of English alphabets
		for (int i = 0; i < noOfCharacters; i++){
			cin.get(ch);
			if ( (ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') ){
				if (ch >= 'A' && ch <= 'Z')
					ch += 32;
				else
					ch -= 32;
			}
			cout << ch;
		}

		close(0);
		close(1);
	}

	else if (pid > 0){
		close(p1[1]);
		wait(NULL);

		//Reading from p2 into buffer what Child1 wrote in it and writing it back to p2
		char buffer[noOfCharacters];
		int size = read(p2[0], buffer, noOfCharacters);
		buffer[size] = '\0';
		write(p2[1], buffer, size);
		close(p2[1]);

		pid_t pid = fork();
		if (pid < 0){
			cerr << "Fork failed!\n";
			return 1;
		}

		else if (pid == 0){
			close(p1[0]);
			close(p1[1]);
			close(p2[1]);

			//Reading from p2 what parent wrote in it and storing it in buffer
			size = read(p2[0], buffer, noOfCharacters);
			buffer[size] = '\0';
			close(p2[0]);

			//Opening output file and writing buffer into it
			int fd = open(argv[2], O_WRONLY | O_CREAT, 0666);
			if (fd == -1){
				cerr << "File not found / could not be opened!\n";
				return 1;
			}

			write(fd, buffer, size);
		}

		else if (pid > 0){
			wait(NULL);
			close(p2[0]);
			close(p1[0]);
			cout << "Task Completed\n";
		}
	}
}