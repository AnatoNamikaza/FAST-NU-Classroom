#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

char **tokenize(char **expression, const char *buffer){
	int i = 0;
	//Ignoring whitespaces after index 0
	for (i = 1; buffer[i] == ' '; i++);

	//Calculating the number of characters of operand1 by reading till next space
	int operand1Size = 0;
	for (; buffer[i] != ' '; i++, operand1Size++);

	//Creating a 1D char array of size operand1Size
	expression[0] = (char *) malloc(operand1Size * sizeof(char));

	//Copying operand1 in index 0 of expression 2D array.
	int j = 0;
	for (i = i - operand1Size; buffer[i] != ' '; i++, j++)
		expression[0][j] = buffer[i];

	//Ignoring more whitespaces
	for ( ; buffer[i] == ' '; i++);

	//Calculating operand2 size and copying it in expression[1]
	int operand2Size = 0;
	for (; buffer[i] != ' ' && buffer[i] != '\0'; i++, operand2Size++);

	expression[1] = (char *) malloc(operand2Size * sizeof(char));
	for (j = 0, i = i - operand2Size; buffer[i] != ' ' && buffer[i]; i++, j++)
		expression[1][j] = buffer[i];

	return expression;
}

long int calculate(char operator, long int operand1, long int operand2){
	if (operator == '+')
		return operand1 + operand2;
	else if (operator == '-')
		return operand1 - operand2;
	else if (operator == '*')
		return operand1 * operand2;
	else if (operator == '/')
		return operand1 / operand2;
	else
		return -1;
}

int main(){
	//Creating named pipe
	if (mkfifo("fifo", 0777) == -1){
		//If the pipe doesn't exist
		if (errno != EEXIST){
			fprintf(stderr, "FIFO creation failed!\n");
			return 1;
		}
	}

	//Open named pipe in read-write mode.
	int fd = open("fifo", O_RDWR);
	if (fd == -1){
		fprintf(stderr, "FIFO not found / could not be opened!\n");
		return 1;
	}

	char buffer[100];
	//Read from client in buffer
	int size = read(fd, buffer, sizeof(buffer));
	buffer[size] = '\0';
	printf("Read %s from pipe\n", buffer);

	//Creating a 2D array for storing the operands
	char **operands = (char **) malloc(2 * sizeof(char *));

	//Retrieving operator from index 0 of buffer
	char operator = buffer[0];

	//Tokenizing buffer into a 2D array containing an operand at both indices
	operands = tokenize(operands, buffer);

	//Converting boths operands into long int from char *
	long int operand1 = strtol(operands[0], NULL, 10);
	long int operand2 = strtol(operands[1], NULL, 10);

	//Getting the result from calculate function
	long int result = calculate(operator, operand1, operand2);

	//Writing the result to named pipe so that client reads it.
	write(fd, &result, sizeof(result));

	close(fd);
	//Freeing heap-allocated memory
	free(operands[0]);
	free(operands[1]);
	free(operands);
}
