#include <stdio.h>
#include <semaphore.h>
#include <sys/shm.h>
#include <unistd.h>
#include <string.h>

struct sems {
	sem_t binary_sem, produced, consumed;
};

int main() {
	//Creating shared memory region for semaphores struct
	int shmid = shmget(77, sizeof(struct sems), IPC_CREAT | 0666);
	if (shmid == -1) {
		fprintf(stderr, "SHM created failed!\n");
		return 1;
	}

	struct sems *semsSHM = shmat(shmid, NULL, 0);

	//Shared memory region for reading data read from file
	int shmid2 = shmget(78, 20, IPC_CREAT | 0666);
	char *buffer = shmat(shmid2, NULL, 0);

	for (;;) {

		sem_wait(&semsSHM->consumed);
		sem_wait(&semsSHM->binary_sem);

		//If $ is found in shared memory, print $ and break the loop.
		if (strcmp(buffer, "$") == 0) {
			printf("Read %s from shared memory\n", buffer);
			sem_post(&semsSHM->binary_sem);
			sem_post(&semsSHM->produced);
			break;
		}

		else {
			printf("Read %s from shared memory\n", buffer);
			printf("Press enter key to continue: ");
			getchar();
		}

		sem_post(&semsSHM->binary_sem);
		sem_post(&semsSHM->produced);

	}

	//Detaching the attached pointers
	shmdt(semsSHM);
	shmdt(buffer);

	//Marking both shared memory regions for deletion
	shmctl(shmid2, IPC_RMID, NULL);
	shmctl(shmid, IPC_RMID, NULL);
}