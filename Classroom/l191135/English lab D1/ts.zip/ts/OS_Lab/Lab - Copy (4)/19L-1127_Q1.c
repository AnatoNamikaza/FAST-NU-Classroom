#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <stdio.h>
#include <unistd.h>

int main() {
	int shmid = shmget(77, 20, 0666 | IPC_CREAT);

	if (shmid != -1){

		pid_t pid = fork();

		if (pid < 0){
			perror(NULL);
			return 1;
		}

		else if (pid == 0){
			//Get a pointer to the shared memory region.
			int *shmptr = (int *) shmat(shmid, NULL, 0);

			printf("Enter 5 ints: ");
			for (int i = 0; i < 5; i++)
				scanf("%d", &shmptr[i]);

			printf("Finished storing 5 ints in shared memory. The 5 ints are:\n");
			for (int i = 0; i < 5; i++)
				printf("%d\t", shmptr[i]);

			printf("\n");
			//Detaching shared memory region
			shmdt(shmptr);
		}

		else {
			wait(NULL);

			//Get a pointer to the shared memory region.
			int *shmptr = (int *) shmat(shmid, NULL, 0);

			printf("Now displaying the squares of those 5 ints:\n");

			for (int i = 0; i < 5; i++)
				printf("%d\t", shmptr[i] * shmptr[i]);

			shmctl(shmid, IPC_RMID, NULL); //mark the shared region for deletion

			//detach
			shmdt(shmptr);
		}

	}

	return 0;
}