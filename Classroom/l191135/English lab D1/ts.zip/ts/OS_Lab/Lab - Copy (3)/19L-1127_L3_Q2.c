#include <unistd.h>
#include <stdio.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <string.h>

int main(){

	int pipe1[2];
	int pipe2[2];

	//store the fds of stdin and stdout
	int backup_stdin = dup(0);
	int backup_stdout = dup(1);

	/* create the pipe */
	if (pipe(pipe1) == -1 || pipe(pipe2) == -1) {
		write(2, "Pipe failed\n", strlen("Pipe failed\n"));
		return 1;
	}

	pid_t pid = fork();
	if (pid < 0){
		perror(NULL);
		return 1;
	}

	else if (pid == 0){
		//closing unused pipes
		close(pipe1[0]);
		close(pipe2[0]);
		close(pipe2[1]);

		//Redirect stdout to write end of pipe1 and then close pipe1
		dup2(pipe1[1], 1);
		close(pipe1[1]);

		//man ls fails, print error to stderr and return with status 1
		if (execlp("man", "man", "ls", NULL) == - 1){
			fprintf(stderr, "man ls failed!\n");
			return 1;
		}
	}

	else if (pid > 0) {
		wait(NULL);

		pid = fork();

		if (pid < 0)
			perror(NULL);

		else if (pid == 0) {

			//closing unused pipes
			close(pipe1[1]);
			close(pipe2[0]);

			//redirect stdin to read end of pipe1 and close it
			dup2(pipe1[0], 0);
			close(pipe1[0]);

			//redirect stdout to write end of pipe2
			dup2(pipe2[1], 1);
			close(pipe2[1]);

			if (execlp("grep", "grep", "ls", NULL) == -1) {
				fprintf(stderr, "grep ls failed!\n");
				return 1;
			}
		}

		else if (pid > 0){

			//closing unused pipes
			close(pipe1[0]);
			close(pipe1[1]);
			close(pipe2[1]);
			wait(NULL);

			int fd = open("file.txt", O_WRONLY | O_CREAT, 0664);
			if (fd != -1) {

				//create a buffer, read into buffer from pipe2 and write to "file.txt" and then close "file.txt" and pipe2
				char buffer[10000];
				read(pipe2[0], buffer, sizeof(buffer));
				write(fd, buffer, strlen(buffer));

				close(fd);
				close(pipe2[0]);
			}

			close(pipe2[0]);
		}

	}

	//closing unused pipes
	close(pipe1[1]);
	close(pipe1[0]);
	close(pipe2[0]);
	close(pipe2[1]);

	//closing ununsed fds
	close(0);
	close(1);

	//restore stdin and stdout
	dup2(backup_stdin, 0);
	dup2(backup_stdout, 1);

	return 0;
}