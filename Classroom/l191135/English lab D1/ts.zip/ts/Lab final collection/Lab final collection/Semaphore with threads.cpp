#include<iostream>
#include<fcntl.h>
#include <sys/wait.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<stdlib.h>
#include<cstring>
#include<string>
#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<semaphore.h>
#include<pthread.h>
#include<sys/ipc.h>
#include<sys/shm.h>
using namespace std;

sem_t sem1[3];
/*
0 for aaa
1 for b
2 for c

*/
void* aaa(void* temp){
    while(1){

        cout<<"aaa";
        sem_post(&sem1[1]);
        sem_wait(&sem1[0]);
    }
}
void *b(void * temp){
    while(1){
        sem_wait(&sem1[1]);
        cout<<"b";
        sem_post(&sem1[2]);
    }
} 

void* c(void * temp){
    while(1){
        sem_wait(&sem1[2]);
        cout<<"c";
        sem_post(&sem1[0]);
    }
}

int main(){

    
    pthread_t thread[3];
    sem_init(&sem1[0],0,0);
    sem_init(&sem1[1],0,0);
    sem_init(&sem1[2],0,0);


    pthread_create(&thread[0],NULL,&aaa,NULL);
    pthread_create(&thread[1],NULL,&b,NULL);
    pthread_create(&thread[2],NULL,&c,NULL);
    
    pthread_join(thread[0],NULL);
    pthread_join(thread[1],NULL);
    pthread_join(thread[2],NULL);

    return 0;
}