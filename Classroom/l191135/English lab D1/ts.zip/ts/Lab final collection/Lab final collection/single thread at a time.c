#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>

int arr[100];
int size = 0;
void print(int i){
    printf("\nThread \t%d : ",i); // print thread number
    for(int i = 0; i<= size; i++){
        printf("%d ",arr[i]);
    }
}
void* foo(void *p) {
    int genNumber = 0;
    for (int i = 2; genNumber < atoi(p); i++) { // check is parameter number is smaller or not
        genNumber = arr[i-2] + arr[i-1];
        arr[i] = genNumber;
        size = i;
    }
    if(genNumber != arr[size]){
        size++;
        arr[size] = genNumber; 
    }
}



int main(int argc, char**argv)
{   
    arr[0] = 0;
    arr[1] = 1;
    for(int i = 0; i< argc - 1; i++){
        
        
        pthread_t t1;
        pthread_create(&t1,NULL,&foo,argv[i+1]);
        pthread_join(t1,NULL);
        print(i);
    }
    return 0;
}