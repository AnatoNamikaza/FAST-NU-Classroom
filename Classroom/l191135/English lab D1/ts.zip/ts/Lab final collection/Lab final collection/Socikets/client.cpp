#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <errno.h>
#include <string.h>
#include <iostream>
#include <arpa/inet.h>
using namespace std;

int main()
{
 sockaddr_in remote_server;
 int sock_fd;

 if ( (sock_fd= socket(AF_INET, SOCK_STREAM, 0) ) ==-1) 
 {
    perror("socket: ");
    exit(-1);
 }

 remote_server.sin_family=AF_INET;
 remote_server.sin_port= htons(8000); 
 remote_server.sin_addr.s_addr= inet_addr("127.0.0.1");
 bzero(&remote_server.sin_zero, 8);
 
 //cout<<ntohl(inet_addr("127.0.0.1"))<<endl;

 if (connect(sock_fd, (sockaddr*) &remote_server, sizeof(sockaddr))==-1)
 {
   perror("connect: ");
   exit(-1);
 }

 int bytes_sent= send(sock_fd, "Hello Server", strlen("Hello Server"), 0);
 if (bytes_sent==-1)
 {
  perror("send: ");
  exit(-1);
 }

 char recv_message[20];
 int bytes_recv=recv(sock_fd, recv_message,  20, 0);
 if (bytes_recv==-1)
 {
  perror("recv: ");
  exit(-1);
 }

 cout<<"The server sent: "<<recv_message<<endl;
 close(sock_fd);

}
