#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include <iostream>
using namespace std;

int main()
{

  int sock_fd, client_fd;
  sockaddr_in server, client;

  if ((sock_fd= socket(AF_INET, SOCK_STREAM, 0))==-1)
  {
     perror("socket: ");
     exit(-1);
  }

 server.sin_family= AF_INET;
 server.sin_port= htons(8000);
 server.sin_addr.s_addr= INADDR_ANY; //if you want to bind the socket to a specific address only, then use inet_addr(any_valid_ip_address_assigned_to_machine)
 bzero(&server.sin_zero, 8);

 int len=sizeof(sockaddr_in);
 
 if ((bind(sock_fd, (sockaddr*) &server, len))==-1)
 {
  perror("bind:");
  exit(-1);
 }

 if (listen(sock_fd, 10)==-1)
 {
       perror("listen:");
       exit(-1);
 }

 if( (client_fd=accept(sock_fd, (sockaddr*) &client, (socklen_t*) &len) )==-1)
 {
  perror("accept:");
  exit(-1);
 } 

 char message[20];
 int bytes_recv= recv(client_fd, message, 20, 0);
 
 int bytes_sent=send(client_fd, message,  strlen(message), 0);

 cout<<"Data Sent to client: "<<ntohl(client.sin_addr.s_addr)<<endl;
 cout<<"Data Sent to client: "<<inet_ntoa(client.sin_addr)<<" (Dotted ASCII)"<<endl;
 close(sock_fd);
 close(client_fd);

}
