#include<stdio.h> 
#include<string.h> 
#include<pthread.h> 
#include<stdlib.h> 
#include<unistd.h> 
#include<iostream>
#include <sys/types.h>
#include <sys/wait.h>
#include <semaphore.h>
#include <sys/mman.h>
 #include <sys/stat.h>        /* For mode constants */
#include <fcntl.h>    
using namespace std;
  
 const char * NAME="semaphore";
 const char * count="counter";
 const int size=4096;
long * counter;
sem_t *sem1;
void Increment() 
{ 
  sem_wait(sem1);
   for(int i=0;i<100000;i++)
     *counter=*counter+1;
    sem_post(sem1);

} 

void Decrement()
{ 
    sem_wait(sem1);
   for(int i=0;i<100000;i++)
   *counter=*counter-1;
    sem_post(sem1) ;
} 
  
int main(void) 
{ 

  int fd = shm_open(NAME, O_CREAT | O_RDWR, 0600);
  if (fd < 0) {
    perror("shm_open()");
    return 0;
  }
    
ftruncate(fd, size);
sem1 = (sem_t*)mmap(NULL, size, PROT_READ | PROT_WRITE,MAP_SHARED, fd, 0);

sem_init(sem1,2,1);

 int fd1 = shm_open(count, O_CREAT  | O_RDWR, 0600);
  if (fd < 0) {
    perror("shm_open()");
    return 0;
  }
    
ftruncate(fd1, size);
counter =(long *) mmap(NULL, size, PROT_READ | PROT_WRITE,MAP_SHARED, fd1, 0);
    *counter=0;

    int i = 0; 
    int error; 
    int pid=fork();
    if(pid==0)
    {
      Increment();
      munmap(counter, size);
      munmap(sem1, size);

    }
    
    else if(pid>0)
    {
      Decrement();
      wait(NULL);
      cout<<"value of counter is"<<*counter<<endl;
      munmap(counter,size);
      munmap(sem1,size);
      shm_unlink(NAME);

    
    }

  
    return 0; 
} 
