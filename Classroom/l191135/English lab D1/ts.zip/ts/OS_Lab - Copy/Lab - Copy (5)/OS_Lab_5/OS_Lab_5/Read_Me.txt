Name:       Abdul-Rehman
Rollno:     19L-1135
Section:    CS_4A
---------------------------------------------
Note: As Q1 didnot ask or required for memory mapped file mentioned anywhere, so it is done without it.

For task#1, use command: 

        g++ Q1.cpp -o 1out

	./1out
	or
	valgrind ./1out

For task#2, use command: 

	g++ -o 2out Q2.cpp -lrt

	./2out
	or
	valgrind ./2out

You can also use the makefiles to run the code using commands:

	./MakeFile1
	./MakeFile2

	Thank you :)