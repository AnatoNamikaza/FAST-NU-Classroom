#include <stdio.h>
#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include<sys/wait.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>        /* For mode constants */
#include <fcntl.h>           /* For O_* constants */
#include <unistd.h>
#include <sys/types.h>


// read from file
// array 
int main(){
	int fd =shm_open("hello",O_RDONLY|O_CREAT,0666);
	ftruncate(fd,30);
	char *array = (char *) mmap(0,30,PROT_READ|PROT_WRITE|PROT_EXEC,MAP_SHARED,fd,0);
	char x[] = "hello I am fine\n";
	write(array, x,30);
	
}
