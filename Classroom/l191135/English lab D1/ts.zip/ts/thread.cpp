#include <stdio.h>
#include <iostream>
#include <pthread.h>
#include <semaphore.h>

sem_t mutex;


struct num{
	int a;
	int b;
	int c;
	};

void * a(void *two){
	struct num n1 = *(struct num*)(two);

	n1.c =n1.a+ n1.b;
	n1.c += n1.c;
	sem_wait(&mutex);
	std::cout<<"Hello, I am learning thread	.sdafhasdfknasld.asdfasd\n";		
	std::cout<< n1.c<<std::endl;
	sem_post(&mutex);
	
	return NULL;
}

int main(){
sem_init(&mutex,0,1);
	pthread_t t[10];
	struct num num2;
	num2.a=2;
	num2.b=6;
	
	for(int i=0;i< 10;i++)
	{
	pthread_create(&t[i],NULL,&a,&num2);
	
	}

	for(int i=0;i< 10;i++)
	{
	pthread_join(t[i],NULL);
	}
	
	return 0;
	
}
