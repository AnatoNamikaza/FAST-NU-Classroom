#include <stdio.h>
#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include<sys/wait.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

// read from file
// array 
int main(){
	int fd = open("input.txt",'r');
	char *array = (char *) mmap(0,30,PROT_READ|PROT_WRITE|PROT_EXEC,MAP_SHARED,fd,0);
	for(int i=0; i< 20; i++) printf("%c\n",array[i]+1);
	munmap(&array,30);apro
}
