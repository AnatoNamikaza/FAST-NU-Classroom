#include<iostream>
#include<fcntl.h>
#include <sys/wait.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<stdlib.h>
#include<cstring>
#include<string>
#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<semaphore.h>
#include<pthread.h>
#include<sys/ipc.h>
#include<sys/shm.h>
using namespace std;



int main(){

    key_t key = 3;
    int size = 1024;

    int forkId = fork();
    if(forkId == 0){
        int shmSemid = shmget(key,size,0);
        int shmStrid = shmget(key + 1,size,0);
        sem_t *sem =(sem_t*) shmat(shmSemid,(void*)0, 0);  
        int *num =(int*) shmat(shmStrid,(void*)0, 0);

        cout<<"\nWaiting ....";
        while(1){
            sem_wait(sem);
            cout<<"\n\n--------------------------------------\n";
            for(int i = 0; i < num[0]; i++){
                cout<<num[i]<<" ";
            }
        }
    }
    else if(forkId>0){
        int shmSemid = shmget(key,size,0666 | IPC_CREAT | IPC_EXCL);
        int shmStrid = shmget(key + 1,size,0666 | IPC_CREAT | IPC_EXCL);
        
        sem_t *sem =(sem_t*) shmat(shmSemid,(void*)0, 0);  
        int *num =(int*) shmat(shmStrid,(void*)0, 0); 
        num[0] = 0;
        sem_init(sem,1,0);
        for(int i = 1; 1; i++){
            num[0]++;
            cout<<"\nParent process index "<<i<<" enter number :";
            cin>> num[i];
            sem_post(sem);
        }

    }





    return 0;
}