#include <fcntl.h>
#include <unistd.h>
#include <iostream>
#include <pthread.h>
#include <sys/mman.h>

void* Case__Conversion(void* arg)
{
	char* g_ch = (char*)arg;
	for (int i = 0; i < 50; i++)
		if (g_ch[i] >= 'A' && g_ch[i] <= 'Z') g_ch[i] += 32;
		else if (g_ch[i] >= 'a' && g_ch[i] <= 'z') g_ch[i] -= 32;
	return NULL;
}

int main(int argc, char** argv)
{
	int fd = open(argv[1], O_RDWR);
	if (fd == -1)
	{
		std::cout << "File not found / Could not be opened!\n";
		return 1;
	}
	std::cout << "File opened successfully\n";
	char* map = (char*)mmap(NULL, 50, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	close(fd);
	if (map == MAP_FAILED)
	{
		std::cout << "Could not create memory map!\n";
		return 1;
	}
	pthread_t p_id[2];
	if (pthread_create(&p_id[0], NULL, &Case__Conversion, map) != 0 || pthread_create(&p_id[1], NULL, &Case__Conversion, map + 50) != 0)
	{
		std::cout << "Thread creation failed!\n";
		return 1;
	}
	pthread_join(p_id[0], NULL);
	pthread_join(p_id[1], NULL);
	if (munmap(map, 100) == -1)
	{
		std::cout << "Could not munmap!\n";
		return 1;
	}
	return 0;
}
