#include<stdio.h>//libraries
#include<string.h>
#include<sys/types.h>
#include<unistd.h>
#include <sys/wait.h>
#include<stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include<math.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include<pthread.h>
// declaration 
float avg=0;
int max = -99999;
int min = 99999;
int arrSize = 0;
float sum=0;
void * average(void * num);
void *maxValue(void * num);
void *minValue(void * num);
void threadFunction(char ** argv);

int main(int argc,char * argv[]){
    arrSize = argc - 1;
    threadFunction(argv);

    printf("Average : %f\n",avg);
    printf("Max Value is : %d\n",max);
    printf("Minimum Vlaue is : %d\n",min);
    
    return 0;
}

void * average(void * num) { //calculate arr average
    sum += atoi(num);
    avg= sum / arrSize;
}

void *maxValue(void * num) { // find max numnber from the arr
    int temp = atoi(num);
    if(max < temp) {
    max = atoi(num);
    }
}

void *minValue(void * num) { //find min number from the arr
    int temp = atoi(num);
    if(min > temp) {
        min = atoi(num);
    }
}

void threadFunction(char ** argv){ // generate thread and calculate average, min, max value of the array
    pthread_t avgThread; // thread for average
    pthread_t pidthread2; // thread for max number
    pthread_t pidthread3; // thread for min number

    for ( int i=0 ; i < arrSize ; i++) {
        // creating the thread
        pthread_create(&avgThread, NULL,& average, argv[i + 1]);
        pthread_create(&pidthread2, NULL,& maxValue, argv[i + 1]);
        pthread_create(&pidthread3, NULL,& minValue, argv[i + 1]);
        
        // join thread 
        pthread_join(avgThread,NULL);
        pthread_join(pidthread2,NULL);
        pthread_join(pidthread3,NULL);
    }
}