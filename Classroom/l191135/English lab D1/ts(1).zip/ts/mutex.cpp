#include <stdio.h>
#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include<sys/wait.h>
// 5 thread
// each thread writes 10 numbers in array
// 6 thread adds all values of array and print the sum
// [1:10,11:20,21,30...]

int A[100] = {0};

sem_t mutex;


struct boundary{
	int a;
	int b;
	boundary(int _a, int _b){
		a = _a;
		b = _b;
	}
	};

void * addNumber(void *lst){
	sem_wait(&mutex);
	struct boundary b= *(struct boundary*)(lst);

	for(int i = b.a; i<= b.b;i++)
	{
		A[i-1]=i;
		//std::cout<< A[i-1]<<'\t'<<i<<'\n';
	}	
	sem_post(&mutex);
		

	return NULL;
}

int main(){
	sem_init(&mutex,0,1);
	
	pthread_t t[5];
	int start=1;
	int end = 10;

	
	for(int i=0;i< 5;i++)
	{
	boundary *num2 = new boundary(start,end);
	
	//std::cout<<"--------"<<num2.a<<'\t'<<num2.b<<'\n';
	pthread_create(&t[i],NULL,&addNumber,num2);
	start = start+10;
	end = end+10;
	
	}

	
	for(int i=0;i< 5;i++)
	{
	pthread_join(t[i],NULL);
	
	}
	int sum =0;
	for(int i=0;i< 50;i++)
	{
		sum+= A[i];
	}
	std::cout<< sum<<'\n';	
	std::cout<<std::endl;

	return 0;
	
}
