#include <stdio.h>
#include <semaphore.h>
#include <sys/shm.h>
#include <unistd.h>
#include <string.h>

struct sems {
	sem_t binary_sem, produced, consumed;
};

int main(int argc, char **argv){
	//Creating shared memory region for semaphores struct
	int shmid = shmget(77, sizeof (struct sems), IPC_CREAT | 0666);
	if (shmid == -1){
		fprintf(stderr, "SHM created failed!\n");
		return 1;
	}

	struct sems *semsSHM = (struct sems *) shmat(shmid, NULL, 0);

	// Initializing semaphores
	sem_init(&semsSHM->binary_sem, 1, 1);
	sem_init(&semsSHM->produced, 1, 1);
	sem_init(&semsSHM->consumed, 1, 0);

	FILE *fin = fopen(argv[1], "r");
	if (!fin){
		perror("File not found / could not be opened!");
		return 1;
	}

	//Shared memory region for reading data read from file
	int shmid2 = shmget(78, 20, IPC_CREAT | 0666);
	if (shmid2 == -1){
		fprintf(stderr, "SHM created failed!\n");
		return 1;
	}

	char *buffer = (char *) shmat(shmid2, NULL, 0);

	//Character array for storing data read from file
	char data[20];

	//Variable for checking if EOF reached
	int exit = 0;

	for ( ; exit == 0; ){
		sem_wait(&semsSHM->produced);
		sem_wait(&semsSHM->binary_sem);

		int dataRead = fgets(data, 21, fin) ? 1 : 0;

		if (dataRead == 0){
			strcpy(buffer, "$");
			exit = 1;
		}

		else
			strcpy(buffer, data);

		sem_post(&semsSHM->binary_sem);
		sem_post(&semsSHM->consumed);
	}

	//Destroying all initialized semaphores
	sem_destroy(&semsSHM->binary_sem);
	sem_destroy(&semsSHM->produced);
	sem_destroy(&semsSHM->consumed);

	//Detaching the attached pointers
	shmdt(semsSHM);
	shmdt(buffer);

	//Marking both shared memory regions for deletion
	shmctl(shmid2, IPC_RMID, NULL);
	shmctl(shmid, IPC_RMID, NULL);
}

