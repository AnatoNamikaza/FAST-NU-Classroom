#include "Calculator.h"

int Subtract(int a, int b) {
	return a - b;
}

