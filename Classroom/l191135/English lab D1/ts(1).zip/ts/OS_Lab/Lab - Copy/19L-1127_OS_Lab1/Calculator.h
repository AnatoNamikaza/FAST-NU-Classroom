
#ifndef OSLAB1_CALCULATOR_H
#define OSLAB1_CALCULATOR_H


int Add(int a, int b);

int Subtract(int a, int b);

int Mutiply(int a, int b);

int Divide(int a , int b);

#endif //OSLAB1_CALCULATOR_H
