#include "Calculator.h"

int Divide(int a, int b) {
	return a / b;
}
