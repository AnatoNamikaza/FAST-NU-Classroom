#include <iostream>
#include "Calculator.h"
using namespace std;

int main(){
	int a = 6, b = 5;

	cout << "The 2 numbers are: " << a << " and " << b << '\n';
	cout << "The result of addition is " << Add(a, b) << '\n';
	cout << "The result of subtraction is " << Subtract(a, b) << '\n';
	cout << "The result of multiplication is " << Mutiply(a, b) << '\n';
	cout << "The result of division is " << Divide(a, b) << '\n';

	return 0;
}
