#include "Calculator.h"

int Mutiply(int a, int b) {
	return a * b;
}