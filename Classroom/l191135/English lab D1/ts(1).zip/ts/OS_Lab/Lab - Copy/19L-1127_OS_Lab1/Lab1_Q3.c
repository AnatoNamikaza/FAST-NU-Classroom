#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int main(){

  pid_t pid;
  pid = fork();

  if (pid == 0){
    printf("I'm a child process and my PID is ");
    pid_t child_PID = getpid();
    if (child_PID % 2 == 0)
      printf("Even\n");
    else
      printf("Odd\n");
  }

  else if (pid > 0){
    wait(NULL);
    printf("I'm a parent process and my PID is %d\n", pid);
  }

  else
    printf("Error! No PID was assigned\n");

}
