#include <stdio.h>

int main(){
	FILE *fp = fopen("Input File.txt", "r");

	if (fp){
		int index = 0, fileSize = 0;

		// obtaining file size:
		fseek (fp , 0 , SEEK_END);
		fileSize = ftell (fp);
		rewind (fp);

		char buffer[fileSize];
		char c = 0;

		for (int i = 0; i < fileSize; i++){
			c = fgetc(fp);
			c = c >= 48 && c <= 57 ? ++c : c;
			buffer[index++] = c;
		}

		//null-terminate the buffer
		buffer[index] = '\0';
		// printf("The file contents are %s\n",buffer);
		fclose(fp);     //close the file

		FILE *of = fopen("Output_File.txt", "wb");
		fwrite(buffer, sizeof(char), index, fp);
		fclose(of);     //close the file
	}

	else
		printf("File not found!\n");

	return 0;
}
