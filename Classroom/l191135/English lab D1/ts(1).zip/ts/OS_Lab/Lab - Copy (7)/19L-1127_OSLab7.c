#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include <sys/shm.h>
#include <string.h>

struct sems {
	sem_t binarySem, writerSem, readerSem, binarySemReader;
	char data[1000];
	int n;
};

void writer(void *sems){
	struct sems *sem = (struct sems *) sems;

	//Char array for storing input taken from user.
	size_t size = 1000;
	char *data = (char *) malloc(size);

	for ( ; ; ){
		sem_wait(&sem->writerSem);
		sem_wait(&sem->binarySem);

		printf("Enter data: ");
		getline(&data, &size, stdin);
		strcpy(sem->data, data);

		sem_post(&sem->binarySem);
		sem_post(&sem->readerSem);
	}
}

void reader(void *sems) {
	struct sems *sem = (struct sems *) sems;
	for ( ; ; ){
		sem_wait(&sem->readerSem);
		sem_wait(&sem->binarySem);

		for (int i = 0; i < sem->n; i++){
			sem_wait(&sem->binarySemReader);
			printf("Thread %d read from shared memory: %s", i + 1, sem->data);
			sem_post(&sem->binarySemReader);
		}

		sem_post(&sem->binarySem);
		sem_post(&sem->writerSem);
	}
}

int main(){
	//Creating SHM for struct sems
	int semID = shmget(77, sizeof(struct sems), IPC_CREAT | 0666);
	if (semID == -1){
		fprintf(stderr, "SHM created failed!\n");
		return 1;
	}

	struct sems *sem = (struct sems *) shmat(semID, NULL, 0);

	//Initializing all semaphores
	sem_init(&sem->binarySem, 1, 1);
	sem_init(&sem->writerSem, 1, 1);
	sem_init(&sem->readerSem, 1, 0);
	sem_init(&sem->binarySemReader, 1, 1);

	printf("Enter the number of reader threads: ");
	scanf("%d", &sem->n);

	//For ignoring '\n' placed in input buffer
	char newline = getchar();

	pthread_t writerThread, readerThread;
	if (pthread_create(&writerThread, NULL, &writer, sem) != 0 || pthread_create(&readerThread, NULL, &reader, sem) != 0){
		fprintf(stderr, "Thread creation failed!\n");
		return 1;
	}

	pthread_join(writerThread, NULL);
	pthread_join(readerThread, NULL);

	//Destroying all semaphores
	sem_destroy(&sem->binarySem);
	sem_destroy(&sem->writerSem);
	sem_destroy(&sem->readerSem);
	sem_destroy(&sem->binarySemReader);

	//Detaching and removing SHMs
	shmdt(sem);

	shmctl(semID, IPC_RMID, NULL);
	return 0;
}