#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

int main(){
	//Opening the pipe in read-write
	int fd = open("fifo", O_RDWR);
	if (fd == -1){
		fprintf(stderr, "FIFO not found / could not be opened!\n");
		return 1;
	}

	//Creating a 1D array on heap for storing input taken from user.
	size_t size = 100;
	char *buffer = (char *) malloc(size * sizeof(char));
	printf("Enter data: ");
	getline(&buffer, &size, stdin);

	//Write the input to pipe for server to read
	write(fd, buffer, strlen(buffer));

	//Reading result from server and printing it
	long int result = 0;
	read(fd, &result, sizeof(result));
	printf("Server returned %ld", result);

	close(fd);
	//Freeing heap-allocated memory
	free(buffer);
}