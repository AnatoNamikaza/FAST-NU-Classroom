#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdbool.h>
#include <sys/types.h>
#include <sys/wait.h>

bool checkSChar(char c){
	//If passed character is neither space nor alphabet nor number, then it is a special character.
	return !( c == 32 || (c >= 48 && c <= 57) || (c >= 65 && c <= 90) || (c >= 97 && c <= 122) );
}

int main() {
	int pfd1[2];    //pipe for reading from "file.txt" and IPC
	int pfd2[2];    //pipe for writing to "updated.txt"

	/* create the pipe */
	if (pipe(pfd1) == -1 || pipe(pfd2) == -1) {
		write(2, "Pipe failed\n", strlen("Pipe failed\n"));
		return 1;
	}

	pid_t pid = fork();

	if (pid < 0){
		write(2, "Fork Failed\n", strlen("Fork Failed\n"));
		return 1;
	}

	else if (pid > 0){
		//Open file "file.txt" and read its contents in buffer and send that buffer to child
		char buffer[100];
		int fd1 = open("file.txt", O_RDONLY);
		ssize_t size = read(fd1, buffer, sizeof(buffer));
		write(pfd1[1], buffer, strlen(buffer));

		//Create buffer1 that will receive buffer from child without special characters
		char buffer1[size];
		size = read(pfd2[0], buffer1, sizeof(buffer1));
		buffer1[size] = '\0';

		//Write buffer1 to "updated.txt" and close the respective pipes
		int fd2 = open("updated.txt", O_WRONLY | O_CREAT, S_IRWXU | S_IRGRP | S_IROTH);
		write(fd2, buffer1, strlen(buffer1));
		wait(NULL);
		close(pfd1[1]);
		close(pfd2[0]);
		close(fd1);
		close(fd2);
	}

	else {
		//Read buffer containing contents of "file.txt" from parent
		char buffer[100];
		ssize_t size = read(pfd1[0], buffer, sizeof(buffer));

		//Counting number of special characters
		int SCharCount = 0;
		for (int i = 0; i < size; i++)
			if ( checkSChar(buffer[i]) )
				SCharCount++;

		//Create buffer1 that won't have special characters
		char buffer1[size - SCharCount];
		for (int i = 0, j = 0; i < size; i++)
			if ( !checkSChar(buffer[i]) )
				buffer1[j++] = buffer[i];
		buffer1[size - SCharCount] = '\0';

		//Send buffer1 to parent and close respective pipes
		write(pfd2[1], buffer1, size - SCharCount);
		close(pfd1[0]);
		close(pfd2[1]);
	}
	return 0;
}