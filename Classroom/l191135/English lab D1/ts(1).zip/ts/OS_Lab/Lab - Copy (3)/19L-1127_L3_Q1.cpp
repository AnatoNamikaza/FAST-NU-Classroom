#include <unistd.h>
#include <stdio.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <string.h>
#include <iostream>
using namespace std;

int main() {

	//backup stdin and stdout
	int backup_stdin = dup(0);
	int backup_stdout = dup(1);

	int fdp[2];

	if (pipe(fdp) == -1 ){
		write(2, "Pipe failed\n", strlen("Pipe failed\n"));
		return 1;
	}

	pid_t pid = fork();

	if (pid < 0){
		perror(nullptr);
		return 1;
	}

	else if (pid == 0){

		close(fdp[0]);

		int fd1 = open("input.txt", O_RDONLY);
		if (fd1 == -1){
			fprintf(stderr, "File not found/opened!\n");
			return 1;
		}

		//redirect stdin to "input.txt" and stdout to fdp
		dup2(fd1, 0);
		dup2(fdp[1], 1);

		//close the unused fds
		close(fd1);
		close(fdp[1]);

		int digit = 0, sum = 0;
		while (!cin.eof()){
			cin >> digit;
			sum += digit;
		}

		// Write sum to fdp
		cout << sum;
	}

	else {
		close(fdp[1]);

		//create a buffer and read from pipe into it
		char buffer[10];
		ssize_t size = read(fdp[0], buffer, sizeof(buffer));
		buffer[size] = '\0';

		//close unused pipe
		close(fdp[0]);

		int fd2 = open("output.txt", O_WRONLY | O_CREAT, 0664);
		write(fd2, buffer, size);
		close(fd2);

		//restore stdin and stdout
		close(0);
		dup2(backup_stdin, 0);

		close(1);
		dup2(backup_stdout, 1);
	}

	return 0;
}
