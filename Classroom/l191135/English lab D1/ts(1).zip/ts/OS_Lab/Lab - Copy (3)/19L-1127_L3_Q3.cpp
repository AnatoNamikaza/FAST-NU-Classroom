#include <unistd.h>
#include <cstdio>
#include <sys/wait.h>

int main(){

	pid_t pid = fork();

	if (pid < 0){
		perror(NULL);
		return 1;
	}

	else if (pid == 0)
		execlp("mkdir", "mkdir", "./myFolder_1", "./my_Folder2", NULL);

	else if (pid > 0){
		wait(NULL);

		pid = fork();

		if (pid < 0)
			perror(NULL);

		else if (pid == 0)
			execlp("mkdir", "mkdir", "./myFolder_1/mySubFolder", NULL);

		wait(NULL);

		pid = fork();

		if (pid < 0)
			perror(NULL);

		else if (pid == 0){
			printf("\n\n\n");
			execlp("ls", "ls", "-S", NULL);
		}

		wait(NULL);
	}

	return 0;
}