#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <stdlib.h>

void* removeDupAndFindNeg(void *filename){
	//Open the passed file
	FILE *file = fopen((char *) filename, "r");

	//If file not found or could not be opened, print error and return with error code 1.
	if (!file){
		fprintf(stderr, "File not found / could not be opened!\n");
		return NULL;
	}

	//Counting the number of negative values.
	int negativeValues = 0;
	int temp = 0, totalValues = 0;
	for (; fscanf(file, "%d", &temp) == 1; ){
		totalValues++;
		if (temp < 0)
			negativeValues++;
	}

	//Create an int buffer of size (totalValues - negativeValues).
	totalValues -= negativeValues;
	int buffer[totalValues];

	//Move file cursor to beginning of file.
	rewind(file);

	//Copying non-negative values in buffer.
	for (int i = 0, j = 0; i < totalValues + negativeValues; i++){
		fscanf(file, "%d", &temp);
		if (temp >= 0)
			buffer[j++] = temp;
	}

	//Counting duplicate values and marking them with -1.
	int duplicateValues = 0;
	for (int i = 0; i < totalValues; i++){
		if (buffer[i] >= 0){
			for (int j = i + 1; j < totalValues; j++){
				if (buffer[j] == buffer[i]){
					buffer[j] = -1;
					duplicateValues++;
				}
			}
		}
	}

	//Creating a heap-allocated int buffer for storing unique and non-negative values.
	int *uniqueBuffer = (int *) malloc((totalValues - duplicateValues + 1) * sizeof(int));
	for (int i = 0, j = 0; i < totalValues; i++){
		if (buffer[i] != -1)
			uniqueBuffer[j++] = buffer[i];
	}

	//Storing -1 at last index of uniqueBuffer for detecting the end of uniqueBuffer.
	uniqueBuffer[totalValues - duplicateValues] = -1;

	//Close the file and return uniqueBuffer.
	fclose(file);
	return (void *) uniqueBuffer;
}

int main() {
	char file1name[10], file2name[10];
	strcpy(file1name, "f1.txt");
	strcpy(file2name, "f2.txt");
	pthread_t id[2];

	//If the creation of any or both threads fail, print error and exit with error code 1.
	if (pthread_create(&id[0], NULL, &removeDupAndFindNeg, &file1name) == -1 ||
	    pthread_create(&id[1], NULL, &removeDupAndFindNeg, &file2name) == -1){

		fprintf(stderr, "Creation of one or more threads failed!\n");
		return 1;
	}

	//Create 2 int pointers and attach them with the respective threads.
	int *uniqueBuffer1 = NULL, *uniqueBuffer2 = NULL;
	pthread_join(id[0], (void **) &uniqueBuffer1);
	pthread_join(id[1], (void **) &uniqueBuffer2);

	//If both int pointers are non-null, meaning that both files were opened and hence both point to an int array.
	if (uniqueBuffer1 && uniqueBuffer2){
		int totalValues = 0, sum = 0;

		//Calculate sum of unique and non-negative values of "f1.txt".
		for (int i = 0; uniqueBuffer1[i] != -1; i++, totalValues++)
			sum += uniqueBuffer1[i];

		//Calculate sum of unique and non-negative values of "f2.txt".
		for (int i = 0; uniqueBuffer2[i] != -1; i++, totalValues++)
			sum += uniqueBuffer2[i];

		//Print the average.
		printf("\n%d", sum / totalValues);

		//Free both heap-allocated int arrays.
		free(uniqueBuffer1);
		free(uniqueBuffer2);
	}

	else {
		fprintf(stderr, "Did not get any int array(s)\nExiting");
		return 1;
	}

	return 0;
}