#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include <iostream>
#include <unistd.h>

using namespace std;

int main(){
	sockaddr_in remote_server;
	int sock_fd;

	if ( (sock_fd = socket(AF_INET, SOCK_STREAM, 0) ) == -1){
		perror("socket: ");
		return -1;
	}

	remote_server.sin_family = AF_INET;
	remote_server.sin_port = htons(8005);
	remote_server.sin_addr.s_addr = inet_addr("127.0.0.1");
	bzero(&remote_server.sin_zero, 8);

	if (connect(sock_fd, (sockaddr *) &remote_server, sizeof(sockaddr)) == -1){
		perror("connect :");
		return -1;
	}

	char message[100], recv_message[100];

	while (strcmp(message, "exit") != 0) {
		cout << "Enter data to send to server: ";
		cin.getline(message, 100, '\n');
		if (send(sock_fd, message, strlen(message) + 1, 0) == -1){
			perror("send :");
			return -1;
		}

		else {
			if (recv(sock_fd, recv_message, 100, 0) == -1){
				perror("receive: ");
				return -1;
			}

			else
				cout << "The server sent: " << recv_message << endl;
		}
	}

	close(sock_fd);
}