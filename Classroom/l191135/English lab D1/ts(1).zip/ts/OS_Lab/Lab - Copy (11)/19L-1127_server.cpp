#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <errno.h>
#include <string.h>
#include <arpa/inet.h>
#include <iostream>
#include <pthread.h>
#include <unistd.h>

using namespace std;

void* comThread(void *arg){
	int* client_fd = (int *) arg;

	char message[100];
	bzero(message, 100);    //zeroing message array

	while (strcmp(message, "exit") != 0){
		recv(*client_fd, message, 100, 0);
		cout << "Client sent: \"" << message << "\"" << endl;
		send(*client_fd, message, strlen(message) + 1, 0);
	}

	return NULL;
}

int main(){
	int sock_fd, client_fd;
	sockaddr_in server, client;

	if ( (sock_fd = socket(AF_INET, SOCK_STREAM, 0)) == -1){
		perror("socket: ");
		return -1;
	}

	server.sin_family = AF_INET;
	server.sin_port = htons(8005);
	server.sin_addr.s_addr = INADDR_ANY;
	bzero(&server.sin_zero, 8);

	int len = sizeof(sockaddr_in);
	if ((bind(sock_fd, (sockaddr *) &server, len) == -1)){
		perror("bind: ");
		return -1;
	}

	if (listen(sock_fd, 10) == -1){
		perror("listen: ");
		return -1;
	}

	pthread_t tid;

	while (true){
		cout << "Waiting for a new client\n";

		if ( (client_fd = accept(sock_fd, (sockaddr *) &client, (socklen_t *) &len) ) == -1)
			perror("accept: ");

		if (pthread_create(&tid, NULL, &comThread, &client_fd) == -1){
			perror("pthread_create: ");
			continue;
		}

		pthread_join(tid, NULL);
	}

	close(sock_fd);
	close(client_fd);
}
