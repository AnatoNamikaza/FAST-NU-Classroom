#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <limits.h>
#include <sys/wait.h>
#include <string.h>
#include <semaphore.h>

int main(int argc, char **argv){
	//Array for storing all max values returned from child processes and initializing all values in array to 0
	int ans[argc - 1];
	for (int i = 0; i < argc - 1; i++)
		ans[i] = 0;

	//Storing PID of main in ppid
	int ppid = getpid();
	pid_t pid;
	int p1[2], p2[2];

	//Running the loop argc - 1 times as there will be argc - 1 child processes
	for (int i = 1; i < argc; i++){
		if (pipe(p1) == -1 || pipe(p2) == -1){
			fprintf(stderr, "Pipe creation failed!\n");
			return 1;
		}

		//Write filename[i] to p1
		write(p1[1], argv[i], strlen(argv[i]));

		pid = fork();
		if (pid < 0){
			fprintf(stderr, "Fork failed!\n");
			return 1;
		}
		else if (pid == 0){
			close(p1[1]);
			close(p2[0]);

			//Reading filename[i] from p1
			char *filename = (char *) malloc(100 * sizeof(char));
			int size = read(p1[0], filename, 100);
			filename[size] = '\0';

			FILE *fin = fopen(filename, "r");
			if (!fin){
				fprintf(stderr, "File not found / could not be opened!\n");
				return 1;
			}

			int temp = 0, max = INT_MIN;
			//Reading from file till EOF encountered
			for ( ; fscanf(fin, "%d", &temp) == 1; )
				max = temp > max ? temp : max;

			//Writing the maximum value in file to p2
			write(p2[1], &max, sizeof(max));
		}

		//Reading the maximum value returned from child in ans array.
		read(p2[0], &ans[i - 1], sizeof(ans[i - 1]));
	}

	//Checking if PID of the current process is the PID of main
	if (getpid() == ppid){
		//Waiting for all children
		for (int i = 1; i < argc; i++)
			wait(NULL);

		//Printing maximum value out of all values in ans array.
		int max = INT_MIN;
		for (int i = 1; i < argc; i++)
			max = ans[i - 1] > max ? ans[i - 1] : max;
		printf("The maximum value is %d", max);
	}
}