Name:       Abdul-Rehman
Rollno:     19L-1135
Section:    CS_4A
---------------------------------------------

Use command: 

        gcc -g server.c -pthread -o server.exe
	gcc -g client.c -pthread -o client.exe
	./server.exe
	./client.exe

Note:	run ./server.exe first and then open a terminal again while server is waiting
	then run ./client.exe

	similary open five termianls at once or porovide all votes through one terminal
	./server.exe will wailt till all votes have taken place of five cities

	Thank you :)