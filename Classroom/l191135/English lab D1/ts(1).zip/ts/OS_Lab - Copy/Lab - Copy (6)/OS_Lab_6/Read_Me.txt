Name:       Abdul-Rehman
Rollno:     19L-1135
Section:    CS_4A
---------------------------------------------

Use command: 

        ./MakeFile

	Thank you :)