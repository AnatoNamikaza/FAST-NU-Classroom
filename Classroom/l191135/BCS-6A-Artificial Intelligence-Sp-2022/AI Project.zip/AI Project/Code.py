#Libraries
from asyncio import sleep
from asyncore import ExitNow
import sys
import numpy as np
import heapq
from matplotlib.pyplot import figure
import random
from matplotlib import colors
import matplotlib.pyplot as plt

# to run GUI event loop
#plt.ion()

# Values of 
# Free cell         = 0     (White)
# Hospital cell     = 1     (Red)
# Current cell      = 2     (Yellow)
# Block cell        = 4     (Black)
F_cell, C_cell, B_cell = 0, 3, 1

# Gird Dimension
Map_value = 19

# Original Grid
Grid = np.array([
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]])

# No of Hospitals, No of Cases
Hos_no, Case_no = 6, 5

# Current Location to solve
Curr_X, Curr_Y = 0, 0

# Current_case to solve
Current_case = 0

# Maximum and Minimum Blocked Cells
Max_Block, Min_Block = 50, 80

# Blocked
def Blocked(Grid):
    for i in range(Map_value): 
        for j in range(Map_value):    
            if Grid[i][j] == B_cell: Grid[i][j] = F_cell

    for i in range(random.randint(Max_Block, Min_Block)):
        x,y = random.randint(0,Map_value),random.randint(0,Map_value)
        if Grid[x][y] == F_cell: Grid[x][y] = B_cell

Blocked(Grid)

# Hospital Location
Hos_Loc_X       = []
Hos_Loc_Y       = []
Hos_Treatments  = []
for i in range(Hos_no): 
    r = []
    for j in range(random.randint(1, Case_no)): r.append(random.randint(1,Case_no))
    Hos_Treatments.append(set(r))

for i in range(6): 
    Hos_Loc_X.append(random.randint(0,Map_value))
    Hos_Loc_Y.append(random.randint(0,Map_value))

# Print Grid
#for i in range(Map_value): print(Grid[i])

# Getting Current Location
while(True):
    Curr_X, Curr_Y = map(int, input("Enter Location values: ").split())
    if Curr_X in range(0,Map_value) and Curr_Y in range(0,Map_value) and Grid[Curr_X][Curr_Y] == 0: break 

# Getting Current Case
while(True):
    Current_case = int(input("Enter Case No in Range(1," + str(Case_no) + "): "))
    if Current_case in range(1,Case_no): break 

# Hospital Location with cure
P_Hos_Loc_X       = []
P_Hos_Loc_Y       = []

for i in range(Hos_no): 
    if Current_case in Hos_Treatments[i]:
        P_Hos_Loc_X.append(Hos_Loc_X[i])
        P_Hos_Loc_Y.append(Hos_Loc_Y[i])
    
# heuristic function for path scoring
def heuristic(a, b):
    return np.sqrt((b[0] - a[0]) ** 2 + (b[1] - a[1]) ** 2)

# astar function for path finding
def astar(array, start, goal):
    neighbors = [(0,1),(0,-1),(1,0),(-1,0),(1,1),(1,-1),(-1,1),(-1,-1)]
    close_set = set()
    came_from = {}
    gscore = {start:0}
    fscore = {start:heuristic(start, goal)}
    oheap = []
    heapq.heappush(oheap, (fscore[start], start))
    while oheap:
        current = heapq.heappop(oheap)[1]
        if current == goal:
            data = []
            while current in came_from:
                data.append(current)
                current = came_from[current]
            return data
        close_set.add(current)
        for i, j in neighbors:
            neighbor = current[0] + i, current[1] + j
            tentative_g_score = gscore[current] + heuristic(current, neighbor)
            if 0 <= neighbor[0] < array.shape[0]:
                if 0 <= neighbor[1] < array.shape[1]:                
                    if array[neighbor[0]][neighbor[1]] == 1:
                        continue
                else:
                    # array bound y walls
                    continue
            else:
                # array bound x walls
                continue
            if neighbor in close_set and tentative_g_score >= gscore.get(neighbor, 0):
                continue
            if  tentative_g_score < gscore.get(neighbor, 0) or neighbor not in [i[1]for i in oheap]:
                came_from[neighbor] = current
                gscore[neighbor] = tentative_g_score
                fscore[neighbor] = tentative_g_score + heuristic(neighbor, goal)
                heapq.heappush(oheap, (fscore[neighbor], neighbor))
    return False

while(True):
    full_route = []
    #paths = 0

    if len(P_Hos_Loc_X) == 0:
        print("Treatment is not available in any hospital")
    else:    
        for v in range(len(P_Hos_Loc_X)):
            start = (Curr_X, Curr_Y)
            goal = (P_Hos_Loc_X[v], P_Hos_Loc_Y[v])    
            route = astar(Grid, start, goal)
            if type(route) != type(False):
                #paths = paths + 1
                route = route + [start]
                route = route[::-1]
                full_route.append(route)
            else:
                full_route.append((-1,-1))    

        min_path = 9999999999999
        min_path_indx = 0
        for i in range(len(full_route)):
            if full_route[i][0] != -1 and len(full_route[i]) < min_path: 
                min_path = len(full_route[i])
                min_path_indx = i

        #print(paths)
        x_coords = []
        y_coords = []
        for i in (range(0,len(full_route[min_path_indx]))):
            x = full_route[min_path_indx][i][0]
            y = full_route[min_path_indx][i][1]
            x_coords.append(x)
            y_coords.append(y)
        # plot map and path
        start = (Curr_X, Curr_Y)
        goal = (P_Hos_Loc_X[min_path_indx], P_Hos_Loc_Y[min_path_indx])
        fig, ax = plt.subplots(figsize=(20,20))
        ax.imshow(Grid, cmap=plt.cm.Dark2)
        ax.scatter(start[1],start[0], marker = "H", color = "yellow", s = 200)
        ax.scatter(goal[1], goal[0], marker = "*", color = "red", s = 200)
        ax.plot(y_coords,x_coords, color = "black")
        plt.show()
    
    # rearranging Blockades
    Blocked(Grid)
