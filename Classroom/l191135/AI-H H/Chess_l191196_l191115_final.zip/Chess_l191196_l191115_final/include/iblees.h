#ifndef IBLEES_H
#define IBLEES_H
#include"chessPlayer.h"
#include<climits>
#include<vector>
#include<iostream>
#define ROWS 8
#define COLS 8
using namespace std;

class Iblees:public chessPlayer{
	int actionNumber;
	action Action;
	gameState state1;
public:
  Iblees(Color playerColor) :chessPlayer("Iblees Aur Us ka Chaila",playerColor){
	  actionNumber = 0;
  }


  int minimax_with_pruning(gameState state,
	  
	  int alpha,
	  int beta,
	  int playerType,
	  int depth
	  ) {
	  int actNo = 0;
	  if (depth == 0 || !state.Actions.getActionCount()) {
		  return evaluation_function(state);
	  }
	  if (playerType) {
		  while(actNo< state.Actions.getActionCount()){
			  state1 = state;
			  state.Actions.getAction(actNo, &Action);
			  state1.applyMove(Action);
			  int val = minimax_with_pruning(state1,  alpha, beta, (int)!playerType,depth - 1 );
			  if (depth == 4 && alpha < val) {
				  actionNumber = actNo;
			  }
			  if (alpha <= val) {
				  alpha = val;
			  }
			  if (beta <= alpha)
				  break;
			  actNo++;
		  }
		  return alpha;
	  }
	  else
	  {
		  while(actNo < state.Actions.getActionCount()){
			state1 = state;
			state.Actions.getAction(actNo, &Action);
			state1.applyMove(Action);
			beta = min(beta, minimax_with_pruning(state1, alpha, beta, (int)!playerType, depth - 1));
			if (beta <= alpha)
				break;
			actNo++;
		  }
		  return beta;
	  }
  }

  int evaluation_function(gameState gState) {
    int white_points = 0;
    int black_points = 0;
    for (int i = 0; i < ROWS; i++){
      for (int j = 0; j < COLS; j++){
	if (gState.Board.board[i][j] == 4) white_points += 10;
	else if (gState.Board.board[i][j] == -4) black_points += 10;
	  
	if (gState.Board.board[i][j] == 1) white_points += 5;
	else if(gState.Board.board[i][j] == -1) black_points += 5;

	if (gState.Board.board[i][j] == 5) white_points += 20;
	else if (gState.Board.board[i][j] == -5) black_points += 20;

	if (gState.Board.board[i][j] == 2) white_points += 10;
	else if (gState.Board.board[i][j] == -2) black_points += 10;

	if (gState.Board.board[i][j] == 3) white_points += 5;
	else if (gState.Board.board[i][j] == -3) black_points += 5;

	if (gState.Board.board[i][j] == 6) white_points += 100;
	else if (gState.Board.board[i][j] == -6) black_points += 100;
      }
    }
	if (gState.getPlayer() == White) {
		return white_points - black_points;
	}
	else {
		return ((white_points - black_points) * -1);
	}

  
  }



  void decideMove(gameState* state, action* Move, int maxDepth = -1)
  {
      minimax_with_pruning(*state, -99999, 99999, 1, 4);
      state->Actions.getAction(actionNumber, Move);
    
  }
};
#endif
