#ifndef ENUM_H_INCLUDED
#define ENUM_H_INCLUDED

enum Color {Black, White};


#endif // ENUM_H_INCLUDED
