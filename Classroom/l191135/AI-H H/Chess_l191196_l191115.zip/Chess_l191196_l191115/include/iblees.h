#ifndef IBLEES_H
#define IBLEES_H
#include"chessPlayer.h"
#include<climits>
#include<vector>
#include<iostream>
#define ROWS 8
#define COLS 8
using namespace std;

class Iblees:public chessPlayer{
  int countMoves;
public:
  Iblees(Color playerColor) :chessPlayer("Iblees Aur Us ka Chaila",playerColor){
	countMoves = 0;
	srand(time(NULL));
  }


  int minimax_with_pruning(gameState g,
						   int depth,
						   int alpha,
						   int beta,
						   bool playerType,
						   int& actionNumber,
						   int returnDepth){
	if (depth == 1 || g.Actions.getActionCount() == 0){
		return createScore(g);
	  }
	if (playerType){
		/*int bestValue = INT_MIN;*/
		for (int i = g.Actions.getActionCount() - 1; i >= 0; i--){
			action act;
			g.Actions.getAction(i, &act);
			gameState g1 = g;
			g1.applyMove(act);
			int val = minimax_with_pruning(g1, depth - 1, alpha, beta, false,actionNumber, returnDepth);
			if (depth== returnDepth && alpha < val){
				actionNumber = i;
			  }
			alpha = max(alpha, val);
			if (beta <= alpha)
			  break;
		  }
		return alpha;
	  }
	else
	  {
		for (int i = g.Actions.getActionCount() - 1; i >= 0; i--)
		  {
			action act;
			g.Actions.getAction(i, &act);
			gameState g1 = g;
			g1.applyMove(act);
			int val = minimax_with_pruning(g1, depth - 1, alpha, beta, true,actionNumber, returnDepth);
			beta = min(beta, val);
			if (beta <= alpha)
			  break;
		  }
		return beta;
	  }
  }

  int startEvaluation(gameState g) {
	int points = 0;
	for (int i = 0; i < ROWS; i++)
	  for (int j = 0; j < COLS; j++)
		{

		  points += g.Board.board[i][j] * 3;
		}
	return points;
  }
  int midEvaluation(gameState g) {
	int points = 0;
	for (int i = 0; i < ROWS; i++)
	  for (int j = 0; j < COLS; j++)
		{
		  if (g.Board.board[i][j] == 4 ||
			  g.Board.board[i][j] == -4) {// rock
			points += 10;
		  }
		  else if (g.Board.board[i][j] == 1 ||
				   g.Board.board[i][j] == -1) {// pawn
			points += 5;
		  }
		  else if (g.Board.board[i][j] == 5 ||
				   g.Board.board[i][j] == -5) {// queen
			points += 14;
		  }
		  else if (g.Board.board[i][j] == 2 ||
				   g.Board.board[i][j] == -2) {// knight
			points += 8;
		  }
		  else if (g.Board.board[i][j] == 3 ||
				   g.Board.board[i][j] == -3) {// bishup
			points += 8;
		  }
		  else if (g.Board.board[i][j] == 6 ||
				   g.Board.board[i][j] == -6) {// king
			points += 90;
		  }
		}
	return points;
  }

  int evaluation_function(gameState g) {
	int points = midEvaluation(g);
	if (g.getPlayer() != playerColor) {
	  // if just king underThread
	  if (g.kingUnderThreat(g.getPlayer())) {
		points += 8;
	  }
	  // if king underThread
	  if (g.Actions.getActionCount() == 0 &&
		  g.kingUnderThreat(g.getPlayer())) {
		and no moves are left
		points += 100;
	  }
	}
	return points;
  }

  int createScore(gameState g)
  {
	int score;
	if (countMoves < 3) {
	  score = startEvaluation(g);
	}
	else if (countMoves < 7) {
	  score = midEvaluation(g);
	}
	else {
	  score = evaluation_function(g);
	}
	if (g.getPlayer() == White)
	  {
		return score;
	  }
	else
	  {
		return (score * -1);
	  }
  }


  void decideMove(gameState* state, action* Move, int maxDepth = -1)
  {
	countMoves++;
	if (countMoves == 1) {
	  if (state->Actions.getActionCount() == 0) {
		Move->fromRow = Move->fromCol = Move->toRow = Move->toCol = 0;
		return;
	  }


	  state->Actions.getAction(rand() % state->Actions.getActionCount(), Move);
	  return;
	}
	else {
	  int actNo;
	  int depth = 6;
	  minimax_with_pruning(*state, depth, INT_MIN, INT_MAX, true, actNo, depth);
	  state->Actions.getAction(actNo, Move);
	}
  }
};
#endif
