#include "include/actionList.h"
#include <iostream>
#include<iomanip>
#include "include/chess.h"
#include "include/iblees.h"
#include "include/humanPlayer.h"

using namespace std;

int main(){
    chess Game;
    Game.Players[0] = new humanPlayer("Human Player Name", White);
    Game.Players[1] = new Iblees(Black);
    Game.playGame();
    return 0;
}
