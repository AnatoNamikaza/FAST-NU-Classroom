import pandas as pd

df = pd.read_excel('Fast School of Computing Time Table Spring 2022 v3.1.xlsx')

print(df)