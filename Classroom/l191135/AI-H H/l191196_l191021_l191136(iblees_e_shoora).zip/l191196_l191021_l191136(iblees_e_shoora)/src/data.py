class Room(object):
  def __init__(self, number, seating_capacity):
    self.number = number
    self.seating_capacity = seating_capacity

  def __str__(self):
    return self.number
    
  def __eq__(self, other):
    if isinstance(other, Room):
      return self.number == other.number
    
    return self == other
class Course(object):
  def __init__(self, number, name, max_number_of_students, instructors):
    self.number = number
    self.name = name
    self.max_number_of_students = max_number_of_students
    self.instructors = instructors

  def __str__(self):
    return self.name
class Class(object):
  def __init__(self, id, department, course):
    self.id = id
    self.department = department
    self.course = course
    self.room = None
    self.instructor = None
    self.meeting_time = None

  def __str__(self):
    _fmt = '[{department},{course},{room},{instructor},{meeting_time}]'
    args = {
      'department': str(self.department),
      'course': str(self.course),
      'room': str(self.room),
      'instructor': str(self.instructor),
      'meeting_time': str(self.meeting_time)
    }
    return _fmt.format(**args)

class Instructor(object):
  def __init__(self, id, name):
    self.id = id
    self.name = name
  
  def __str__(self):
    return self.name
  
  def __eq__(self, other):
    if isinstance(other, Instructor):
      return self.id == other.id
    
    return self == other
class Department(object):
  def __init__(self, name, courses):
    self.name = name
    self.courses = courses

  def __str__(self):
    return self.name
class MeetingTime(object):
  def __init__(self, id, time):
    self.id = id
    self.time = time

  def __str__(self):
    return self.time

import random


class Data(object):
    def __init__(self):
        self.rooms = None
        self.instructors = None
        self.courses = None
        self.depts = None
        self.meeting_times = None
        self.number_of_classes = None

        self.initialize()

    def initialize(self):
        # create rooms
        allClasseslist = ["Seminar Hall", "CS-2", "CS-3", "CS-4", "CS-5", "CS-6", "CS-7", "CS-9", "CS-10", "CS-11", "CS-12", "CS-13", "CS-14", "CS-15",
                          "CS-16", "E&M-1", "E&M-2", "E&M-3", "E&M-4", "E&M-5", "E&M-6", "E&M-7", "E&M-5", "E&M-11", "CE-1", "CE-2", "CE-3", "CE-4", "CE-5", "CE-6", "CE-7", "CE-8", "CE-9", "CE-10", "CS-1", "CS-8", "E&M-16"]
        self.rooms = []
        for room in allClasseslist:
            self.rooms.append(
                Room(number=room, seating_capacity=random.randint(20, 60)))
        # self.rooms = [room1, room2, room3]

        # create meeting times
        alltimeSloot = ["08:30 - 10:00", "10:00 - 11:30", "11:30 - 01:00",
                        "01:00 - 02:30", "02:30 - 04:00", "04:00 - 5:30"]
        self.meeting_times = []
        Id = 1
        for time_ in alltimeSloot:
            self.meeting_times .append(
                MeetingTime(id="MT"+str(Id), time=time_))
            Id = Id + 1

        # creating instructors
        allinstructors = [
            "Dr. Saira Karim",
            "Mr. Farooq Ahmad ",
            "Ms. Samin Iftikhar",
            "Dr. Asma Naseer",
            "Ms. Hafsa Tariq Javed",
            "Ms. Arooj Khalil",
            "Ms. Anosha Khan",
            "Ms. Sana Fatima",
            "Mr. Salman Mubarak",
            "Mr. Aftab Alam (VF)",
            "Ms. Sobia Tariq Javed",
            "Mr. Haris Jamil (VF)",
            "Ms. Nazish Saleem (VF)",
            "Mr. Zummar Saad (VF)",
            "Ms. Sana Fatima",
            "Ms. Sarah Asghar (VF)",
            "Dr. Syeda Tayyaba Tehrim (VF)",
            "Dr. Hira Iqbal",
            "Dr. Syed Tauseef Saeed (VF)",
            "Mr. Abdul Hafeez Sheikh (VF)",
            "Dr. Akhlaq Ahmad Bhatti",
            "Dr. Syeda Tayyaba Tehrim (VF)",
            "Ms. Aisha Rashid (VF)",
            "Dr. Hira Iqbal",
            "Ms. Sarah Asghar (VF)",
            "Dr. Saman Shahid",
            "Mr.Farhan Farrukh (VF)",
            "Mr. Tahir Rashid",
            "Ms. Bushra Jabeen",
            "Mr. Muhammad Ashraf (VF)",
            "Mr. Farhan Farrukh (VF)",
        ]
        self.instructors = []
        Id = 1
        for instructor_ in allinstructors:
          #Instructor(id="I1", name="ALGO teacher")
            self.instructors .append(Instructor(
                id="Instructor"+str(Id), name=instructor_))
            Id = Id + 1

        #"Object Oriented Programming"
        self.courses = []
        for i in range(0, 5):
            self.courses.append(Course(number="CS1004", name="Object Oriented Programming",
                                max_number_of_students=random.randint(20, 60), instructors=[self.instructors[i]]))

        # for second course
        for i in range(5, 15):
            self.courses.append(Course(number="CS1002", name="Programming Fundamentals",
                                max_number_of_students=random.randint(20, 60), instructors=[self.instructors[i]]))

        # for 3rd course
        for i in range(13, 19):
            self.courses.append(Course(number="EE1005", name="Digital Logic Design",
                                max_number_of_students=random.randint(20, 60), instructors=[self.instructors[i]]))
        # for 4th course
        for i in range(25, 30):
            self.courses.append(Course(number="MT1006", name="Differential Equations",
                                max_number_of_students=random.randint(20, 60), instructors=[self.instructors[i]]))

        # for 5th course
        for i in range(19, 25):
            self.courses.append(Course(number="MT1003", name="Calculus & Analytical Geometry",
                                max_number_of_students=random.randint(20, 60), instructors=[self.instructors[i]]))
        # for 6th course
        for i in range(17, 20):
            self.courses.append(Course(number="NS1001", name="Applied Physics",
                                max_number_of_students=random.randint(20, 60), instructors=[self.instructors[i]]))

        # for 6th course
        for i in range(21, 30):
            self.courses.append(Course(number="SS1003", name="Pakistan Studies",
                                max_number_of_students=random.randint(20, 60), instructors=[self.instructors[i]]))

        # create departments
        coursesd1 = []
        coursesd2 = []
        coursesd3 = []
        for i in range(0, len(self.courses)):
            if(i % 3 == 0):
                coursesd1.append(self.courses[i])
            elif (i % 3 == 1):
                coursesd2.append(self.courses[i])
            else:
                coursesd3.append(self.courses[i])

        self.depts = [Department(name="MSC", courses=coursesd1), Department(
            name="BSCS", courses=coursesd3), Department(name="BBA", courses=coursesd2)]

        # define the number of classes
        self.number_of_classes = sum([len(x.courses) for x in self.depts])
