from utils import get_random_number
from copy import deepcopy

from data import Room, Course, Class, Instructor, Department, MeetingTime
#defining various steps required for the genetic algorithm
def initilization_of_population(size,n_feat):
    population = []
    for i in range(size):
        chromosome = np.ones(n_feat,dtype=np.bool)
        chromosome[:int(0.3*n_feat)]=False
        np.random.shuffle(chromosome)
        population.append(chromosome)
    return population

def fitness_score(population):
    scores = []
    for chromosome in population:
        logmodel.fit(X_train.iloc[:,chromosome],y_train)
        predictions = logmodel.predict(X_test.iloc[:,chromosome])
        scores.append(accuracy_score(y_test,predictions))
    scores, population = np.array(scores), np.array(population) 
    inds = np.argsort(scores)
    return list(scores[inds][::-1]), list(population[inds,:][::-1])

def selection(pop_after_fit,n_parents):
    population_nextgen = []
    for i in range(n_parents):
        population_nextgen.append(pop_after_fit[i])
    return population_nextgen

def crossover(pop_after_sel):
    population_nextgen=pop_after_sel
    for i in range(len(pop_after_sel)):
        child=pop_after_sel[i]
        child[3:7]=pop_after_sel[(i+1)%len(pop_after_sel)][3:7]
        population_nextgen.append(child)
    return population_nextgen

def mutation(pop_after_cross,mutation_rate):
    population_nextgen = []
    for i in range(0,len(pop_after_cross)):
        chromosome = pop_after_cross[i]
        for j in range(len(chromosome)):
            if random.random() < mutation_rate:
                chromosome[j]= not chromosome[j]
        population_nextgen.append(chromosome)
    #print(population_nextgen)
    return population_nextgen

def generations(size,n_feat,n_parents,mutation_rate,n_gen,X_train,
                                   X_test, y_train, y_test):
    best_chromo= []
    best_score= []
    population_nextgen=initilization_of_population(size,n_feat)
    for i in range(n_gen):
        scores, pop_after_fit = fitness_score(population_nextgen)
        print(scores[:2])
        pop_after_sel = selection(pop_after_fit,n_parents)
        pop_after_cross = crossover(pop_after_sel)
        population_nextgen = mutation(pop_after_cross,mutation_rate)
        best_chromo.append(pop_after_fit[0])
        best_score.append(scores[0])
    return best_chromo,best_score
  
class Schedule(object):
  def __init__(self, data):
    self.data = data
    self._classes = []
    self.class_number = 0
    self._fitness = -1
    self.number_of_conflicts = 0
    self.is_fitness_changed = True
  
  def __str__(self):
    return "\n".join([str(x) for x in self._classes])

  @property
  def fitness(self):
    if self.is_fitness_changed:
      self._fitness = self.calculate_fitness()
      self.is_fitness_changed = False
    
    return self._fitness

  @property
  def classes(self):
    self.is_fitness_changed = True
    return self._classes

  def initialize(self):
    def _create_class(self, course, dept):
      _class = Class(id=self.class_number, department=dept, course=course)
      self.class_number += 1

      _class.meeting_time = deepcopy(self.data.meeting_times[int(len(self.data.meeting_times) * get_random_number())])
      _class.room = deepcopy(self.data.rooms[int(len(self.data.rooms) * get_random_number())])
      _class.instructor = deepcopy(self.data.instructors[int(len(self.data.instructors) * get_random_number())])

      self._classes.append(_class)

    for dept in self.data.depts:
      for course in dept.courses:
        _create_class(self, course, dept)

    return self

  def calculate_fitness(self):
    number_of_conflicts = 0
    for idx, _class in enumerate(self._classes):
      if _class.room.seating_capacity < _class.course.max_number_of_students:
        number_of_conflicts += 1
      
      for _tmp_class in self._classes[idx:]:
        if _class.meeting_time == _tmp_class.meeting_time and _class.id != _tmp_class.id:

          # here the check should be updated to name atleast
          if _class.room == _tmp_class.room:
            number_of_conflicts += 1
          
          if _class.instructor == _tmp_class.instructor:
            number_of_conflicts += 1

    self.number_of_conflicts = number_of_conflicts
    
    return (1/(1.0*(self.number_of_conflicts + 1)))
