import json
from random import random, seed
from tabulate import tabulate

from numpy.random import randint
from numpy.random import rand

# objective function
def objective(x):
	return x[0]**2.0 + x[1]**2.0
 
# decode bitstring to numbers
def decode(bounds, n_bits, bitstring):
	decoded = list()
	largest = 2**n_bits
	for i in range(len(bounds)):
		# extract the substring
		start, end = i * n_bits, (i * n_bits)+n_bits
		substring = bitstring[start:end]
		# convert bitstring to a string of chars
		chars = ''.join([str(s) for s in substring])
		# convert string to integer
		integer = int(chars, 2)
		# scale integer to desired range
		value = bounds[i][0] + (integer/largest) * (bounds[i][1] - bounds[i][0])
		# store
		decoded.append(value)
	return decoded
 
# tournament selection
def selection(pop, scores, k=3):
	# first random selection
	selection_ix = randint(len(pop))
	for ix in randint(0, len(pop), k-1):
		# check if better (e.g. perform a tournament)
		if scores[ix] < scores[selection_ix]:
			selection_ix = ix
	return pop[selection_ix]
 
# crossover two parents to create two children
def crossover(p1, p2, r_cross):
	# children are copies of parents by default
	c1, c2 = p1.copy(), p2.copy()
	# check for recombination
	if rand() < r_cross:
		# select crossover point that is not on the end of the string
		pt = randint(1, len(p1)-2)
		# perform crossover
		c1 = p1[:pt] + p2[pt:]
		c2 = p2[:pt] + p1[pt:]
	return [c1, c2]
 
# mutation operator
def mutation(bitstring, r_mut):
	for i in range(len(bitstring)):
		# check for a mutation
		if rand() < r_mut:
			# flip the bit
			bitstring[i] = 1 - bitstring[i]
 
# genetic algorithm
def genetic_algorithm(objective, bounds, n_bits, n_iter, n_pop, r_cross, r_mut):
	# initial population of random bitstring
	pop = [randint(0, 2, n_bits*len(bounds)).tolist() for _ in range(n_pop)]
	# keep track of best solution
	best, best_eval = 0, objective(decode(bounds, n_bits, pop[0]))
	# enumerate generations
	for gen in range(n_iter):
		# decode population
		decoded = [decode(bounds, n_bits, p) for p in pop]
		# evaluate all candidates in the population
		scores = [objective(d) for d in decoded]
		# check for new best solution
		for i in range(n_pop):
			if scores[i] < best_eval:
				best, best_eval = pop[i], scores[i]
				print(">%d, new best f(%s) = %f" % (gen,  decoded[i], scores[i]))
		# select parents
		selected = [selection(pop, scores) for _ in range(n_pop)]
		# create the next generation
		children = list()
		for i in range(0, n_pop, 2):
			# get selected parents in pairs
			p1, p2 = selected[i], selected[i+1]
			# crossover and mutation
			for c in crossover(p1, p2, r_cross):
				# mutation
				mutation(c, r_mut)
				# store for next generation
				children.append(c)
		# replace population
		pop = children
	return [best, best_eval]

def get_random_number():
    seed()
    return random()


def print_msg(msg):
    if isinstance(msg, dict):
        msg = json.dumps(msg, indent=2)

    print
    print("*", 50)
    print(msg)
    print("*", 50)


def print_data(data):
    print_msg("INPUT DATA INFORMATION")
    print_msg("Available departments")
    for dept in data.depts:
        _courses = [str(x) for x in dept.courses]
        print("name : %s, courses : %s" % (dept.name, _courses))

    print_msg("Available courses")
    for course in data.courses:
        _instructors = [str(x) for x in course.instructors]
        _msg = [
            "Course no.: %s, " % course.number,
            "Name: %s" % course.name,
            "Max no. of students: %s" % course.max_number_of_students,
            "Instructors: %s" % _instructors
        ]
        print(",".join(_msg))

    print_msg("Available rooms")
    for room in data.rooms:
        _msg = [
            "Room No: %s" % room.number,
            "Max seating capacity: %s" % room.seating_capacity
        ]
        print(",".join(_msg))

    print_msg("Available instructors")
    for instructor in data.instructors:
        _msg = [
            "ID: %s" % instructor.id,
            "Name: %s" % instructor.name
        ]
        print(",".join(_msg))

    print_msg("Available meeting times")
    for meeting_time in data.meeting_times:
        _msg = [
            "ID: %s" % meeting_time.id,
            "Meeting Time: %s" % meeting_time.time
        ]
        print(",".join(_msg))


def print_population_schedules(population, generation_number):
    _schedule_number = 0

    print_msg("Generation Number: %s" % generation_number)

    _schedules = []
    for x in population.schedules:
        _schedules.append([
            _schedule_number,
            str(x),
            x.fitness,
            x.number_of_conflicts
        ])
        _schedule_number += 1

    headers = [
        "Schedule #",
        "Classes [dept, class, room, instructor, meeting-time]",
        "Fitness",
        "Conflicts"
    ]

    print(tabulate(_schedules, headers=headers))


def print_schedule_as_table(data, schedule, generation):
    _class_number = 1

    _classes = schedule.classes
    _headers = [
        "Class #",
        "Dept",
        "Course (number, max # of students)",
        "Room (capacity)",
        "Instructor (Id)",
        "Meeting Time"
    ]

    table_data = []
    for _class in _classes:
        major_idx = -1
        for idx, _dept in enumerate(data.depts):
            if _dept.name == _class.department.name:
                major_idx = idx

        course_idx = -1
        for idx, _course in enumerate(data.courses):
            if _course.name == _class.course.name:
                course_idx = idx

        room_idx = -1
        for idx, _room in enumerate(data.rooms):
            if _room.number == _class.room.number:
                room_idx = idx

        instructor_idx = -1
        for idx, _instructor in enumerate(data.instructors):
            if _instructor.id == _class.instructor.id:
                instructor_idx = idx

        meeting_time_idx = -1
        for idx, _meeting_time in enumerate(data.meeting_times):
            if _meeting_time.id == _class.meeting_time.id:
                meeting_time_idx = idx

        table_data.append([
            _class_number,
            data.depts[major_idx].name,
            "%s (%s, %s)" % (data.courses[course_idx].name,
                             data.courses[course_idx].number, _class.course.max_number_of_students),
            "%s (%s)" % (data.rooms[room_idx].number,
                         _class.room.seating_capacity),
            "%s (%s)" % (
                data.instructors[instructor_idx].name, data.instructors[instructor_idx].id),
            "%s (%s)" % (
                data.meeting_times[meeting_time_idx].time, data.meeting_times[meeting_time_idx].id)
        ])
        _class_number += 1

    print(tabulate(table_data, headers=_headers))

    if schedule.fitness == 1.0:
        print_msg("Solution Found in %s generations" % (generation + 1))

