from copy import deepcopy
from utils import get_random_number
from data import *
import random

#defining various steps required for the genetic algorithm
def initilization_of_population(size,n_feat):
    population = []
    for i in range(size):
        chromosome = np.ones(n_feat,dtype=np.bool)
        chromosome[:int(0.3*n_feat)]=False
        np.random.shuffle(chromosome)
        population.append(chromosome)
    return population

def fitness_score(population):
    scores = []
    for chromosome in population:
        logmodel.fit(X_train.iloc[:,chromosome],y_train)
        predictions = logmodel.predict(X_test.iloc[:,chromosome])
        scores.append(accuracy_score(y_test,predictions))
    scores, population = np.array(scores), np.array(population) 
    inds = np.argsort(scores)
    return list(scores[inds][::-1]), list(population[inds,:][::-1])

def selection(pop_after_fit,n_parents):
    population_nextgen = []
    for i in range(n_parents):
        population_nextgen.append(pop_after_fit[i])
    return population_nextgen

def crossover(pop_after_sel):
    population_nextgen=pop_after_sel
    for i in range(len(pop_after_sel)):
        child=pop_after_sel[i]
        child[3:7]=pop_after_sel[(i+1)%len(pop_after_sel)][3:7]
        population_nextgen.append(child)
    return population_nextgen

def mutation(pop_after_cross,mutation_rate):
    population_nextgen = []
    for i in range(0,len(pop_after_cross)):
        chromosome = pop_after_cross[i]
        for j in range(len(chromosome)):
            if random.random() < mutation_rate:
                chromosome[j]= not chromosome[j]
        population_nextgen.append(chromosome)
    #print(population_nextgen)
    return population_nextgen

def generations(size,n_feat,n_parents,mutation_rate,n_gen,X_train,
                                   X_test, y_train, y_test):
    best_chromo= []
    best_score= []
    population_nextgen=initilization_of_population(size,n_feat)
    for i in range(n_gen):
        scores, pop_after_fit = fitness_score(population_nextgen)
        print(scores[:2])
        pop_after_sel = selection(pop_after_fit,n_parents)
        pop_after_cross = crossover(pop_after_sel)
        population_nextgen = mutation(pop_after_cross,mutation_rate)
        best_chromo.append(pop_after_fit[0])
        best_score.append(scores[0])
    return best_chromo,best_score

class Data(object):
    def __init__(self):
        self.rooms = None
        self.instructors = None
        self.courses = None
        self.depts = None
        self.meeting_times = None
        self.number_of_classes = None

        self.initialize()

    def initialize(self):
        # create rooms
        allClasseslist = ["Seminar Hall", "CS-2", "CS-3", "CS-4", "CS-5", "CS-6", "CS-7", "CS-9", "CS-10", "CS-11", "CS-12", "CS-13", "CS-14", "CS-15",
                          "CS-16", "E&M-1", "E&M-2", "E&M-3", "E&M-4", "E&M-5", "E&M-6", "E&M-7", "E&M-5", "E&M-11", "CE-1", "CE-2", "CE-3", "CE-4", "CE-5", "CE-6", "CE-7", "CE-8", "CE-9", "CE-10", "CS-1", "CS-8", "E&M-16"]
        self.rooms = []
        for room in allClasseslist:
            self.rooms.append(
                Room(number=room, seating_capacity=random.randint(20, 60)))
        # self.rooms = [room1, room2, room3]

        # create meeting times
        alltimeSloot = ["08:30 - 10:00", "10:00 - 11:30", "11:30 - 01:00",
                        "01:00 - 02:30", "02:30 - 04:00", "04:00 - 5:30"]
        self.meeting_times = []
        Id = 1
        for time_ in alltimeSloot:
            self.meeting_times .append(
                MeetingTime(id="MT"+str(Id), time=time_))
            Id = Id + 1

        # creating instructors
        allinstructors = [
            "Dr. Saira Karim",
            "Mr. Farooq Ahmad ",
            "Ms. Samin Iftikhar",
            "Dr. Asma Naseer",
            "Ms. Hafsa Tariq Javed",
            "Ms. Arooj Khalil",
            "Ms. Anosha Khan",
            "Ms. Sana Fatima",
            "Mr. Salman Mubarak",
            "Mr. Aftab Alam (VF)",
            "Ms. Sobia Tariq Javed",
            "Mr. Haris Jamil (VF)",
            "Ms. Nazish Saleem (VF)",
            "Mr. Zummar Saad (VF)",
            "Ms. Sana Fatima",
            "Ms. Sarah Asghar (VF)",
            "Dr. Syeda Tayyaba Tehrim (VF)",
            "Dr. Hira Iqbal",
            "Dr. Syed Tauseef Saeed (VF)",
            "Mr. Abdul Hafeez Sheikh (VF)",
            "Dr. Akhlaq Ahmad Bhatti",
            "Dr. Syeda Tayyaba Tehrim (VF)",
            "Ms. Aisha Rashid (VF)",
            "Dr. Hira Iqbal",
            "Ms. Sarah Asghar (VF)",
            "Dr. Saman Shahid",
            "Mr.Farhan Farrukh (VF)",
            "Mr. Tahir Rashid",
            "Ms. Bushra Jabeen",
            "Mr. Muhammad Ashraf (VF)",
            "Mr. Farhan Farrukh (VF)",
        ]
        self.instructors = []
        Id = 1
        for instructor_ in allinstructors:
          #Instructor(id="I1", name="ALGO teacher")
            self.instructors .append(Instructor(
                id="Instructor"+str(Id), name=instructor_))
            Id = Id + 1

        #"Object Oriented Programming"
        self.courses = []
        for i in range(0, 5):
            self.courses.append(Course(number="CS1004", name="Object Oriented Programming",
                                max_number_of_students=random.randint(20, 60), instructors=[self.instructors[i]]))

        # for second course
        for i in range(5, 15):
            self.courses.append(Course(number="CS1002", name="Programming Fundamentals",
                                max_number_of_students=random.randint(20, 60), instructors=[self.instructors[i]]))

        # for 3rd course
        for i in range(13, 19):
            self.courses.append(Course(number="EE1005", name="Digital Logic Design",
                                max_number_of_students=random.randint(20, 60), instructors=[self.instructors[i]]))
        # for 4th course
        for i in range(25, 30):
            self.courses.append(Course(number="MT1006", name="Differential Equations",
                                max_number_of_students=random.randint(20, 60), instructors=[self.instructors[i]]))

        # for 5th course
        for i in range(19, 25):
            self.courses.append(Course(number="MT1003", name="Calculus & Analytical Geometry",
                                max_number_of_students=random.randint(20, 60), instructors=[self.instructors[i]]))
        # for 6th course
        for i in range(17, 20):
            self.courses.append(Course(number="NS1001", name="Applied Physics",
                                max_number_of_students=random.randint(20, 60), instructors=[self.instructors[i]]))

        # for 6th course
        for i in range(21, 30):
            self.courses.append(Course(number="SS1003", name="Pakistan Studies",
                                max_number_of_students=random.randint(20, 60), instructors=[self.instructors[i]]))

        # create departments
        coursesd1 = []
        coursesd2 = []
        coursesd3 = []
        for i in range(0, len(self.courses)):
            if(i % 3 == 0):
                coursesd1.append(self.courses[i])
            elif (i % 3 == 1):
                coursesd2.append(self.courses[i])
            else:
                coursesd3.append(self.courses[i])

        self.depts = [Department(name="MSC", courses=coursesd1), Department(
            name="BSCS", courses=coursesd3), Department(name="BBA", courses=coursesd2)]

        # define the number of classes
        self.number_of_classes = sum([len(x.courses) for x in self.depts])

from population import Population
from utils import get_random_number
from copy import deepcopy

class Schedule(object):
  def __init__(self, data):
    self.data = data
    self._classes = []
    self.class_number = 0
    self._fitness = -1
    self.number_of_conflicts = 0
    self.is_fitness_changed = True
  
  def __str__(self):
    return "\n".join([str(x) for x in self._classes])

  @property
  def fitness(self):
    if self.is_fitness_changed:
      self._fitness = self.calculate_fitness()
      self.is_fitness_changed = False
    
    return self._fitness

  @property
  def classes(self):
    self.is_fitness_changed = True
    return self._classes

  def initialize(self):
    def _create_class(self, course, dept):
      _class = Class(id=self.class_number, department=dept, course=course)
      self.class_number += 1

      _class.meeting_time = deepcopy(self.data.meeting_times[int(len(self.data.meeting_times) * get_random_number())])
      _class.room = deepcopy(self.data.rooms[int(len(self.data.rooms) * get_random_number())])
      _class.instructor = deepcopy(self.data.instructors[int(len(self.data.instructors) * get_random_number())])

      self._classes.append(_class)

    for dept in self.data.depts:
      for course in dept.courses:
        _create_class(self, course, dept)

    return self

  def calculate_fitness(self):
    number_of_conflicts = 0
    for idx, _class in enumerate(self._classes):
      if _class.room.seating_capacity < _class.course.max_number_of_students:
        number_of_conflicts += 1
      
      for _tmp_class in self._classes[idx:]:
        if _class.meeting_time == _tmp_class.meeting_time and _class.id != _tmp_class.id:

          # here the check should be updated to name atleast
          if _class.room == _tmp_class.room:
            number_of_conflicts += 1
          
          if _class.instructor == _tmp_class.instructor:
            number_of_conflicts += 1

    self.number_of_conflicts = number_of_conflicts
    
    return (1/(1.0*(self.number_of_conflicts + 1)))

#from schedule import Schedule

from iblees_e_shoora import NUMB_OF_ELITE_SCHEDULES, CROSSOVER_RATE, TOURNAMENT_SELECTION_SIZE, MUTATION_RATE

class GeneticAlgorithm(object):
  def __init__(self, data):
    self.data = data
  
  def evolve(self, population):
    return self.mutate_population(self.crossover_population(population))

  def crossover_population(self, population):
    _cross_over_popluation = Population(size=len(population.schedules), data=self.data)
    for idx in range(NUMB_OF_ELITE_SCHEDULES):
      _cross_over_popluation.schedules[idx] = deepcopy(population.schedules[idx])
    
    for idx in range(NUMB_OF_ELITE_SCHEDULES, len(population.schedules)):
      if CROSSOVER_RATE > get_random_number():
        schedule1 = self.select_tournament_population(population).sort_by_fitness().schedules[0]
        schedule2 = self.select_tournament_population(population).sort_by_fitness().schedules[1]
        _cross_over_popluation.schedules[idx] = self.crossover_schedule(schedule1, schedule2)
      else:
        _cross_over_popluation.schedules[idx] = deepcopy(population.schedules[idx])

    return _cross_over_popluation
  
  def crossover_schedule(self, schedule1, schedule2):
    _crossover_schedule = Schedule(data=self.data).initialize()
    for idx in range(len(_crossover_schedule.classes)):
      if get_random_number() > 0.5:
        _crossover_schedule.classes[idx] = deepcopy(schedule1.classes[idx])
      else:
        _crossover_schedule.classes[idx] = deepcopy(schedule2.classes[idx])
      
    return _crossover_schedule

  def mutate_population(self, population):
    _mutate_population = Population(size=len(population.schedules), data=self.data)
    
    _schedules = list(_mutate_population.schedules)
    for idx in range(NUMB_OF_ELITE_SCHEDULES):
      _schedules[idx] = deepcopy(population.schedules[idx])
    
    for idx in range(NUMB_OF_ELITE_SCHEDULES, len(population.schedules)):
      _schedules[idx] = self.mutate_schedule(population.schedules[idx])

    _mutate_population.schedules = _schedules

    return _mutate_population

  def mutate_schedule(self, _mutate_schedule):
    _mutate_schedule = deepcopy(_mutate_schedule)
    _schedule = Schedule(data=self.data).initialize()

    for idx in range(len(_mutate_schedule.classes)):
      if MUTATION_RATE > get_random_number():
        _mutate_schedule.classes[idx] = deepcopy(_schedule.classes[idx])
    
    return _mutate_schedule

  def select_tournament_population(self, population):
    tournament_population = Population(size=TOURNAMENT_SELECTION_SIZE, data=self.data)
    for idx in range(TOURNAMENT_SELECTION_SIZE):
      tournament_population.schedules[idx] = population.schedules[int(get_random_number() * len(population.schedules))]
    
    return tournament_population
