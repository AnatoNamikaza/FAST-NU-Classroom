import pandas as pd
from sklearn.cluster import KMeans
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

%matplotlib inline # import all important functions
# read from excel file
data_frame = pd.read_excel("OnlineRetail (1).xlsx")

data_frame.head(5)
data_frame = data_frame.drop(columns = ['StockCode', 'InvoiceNo', 'InvoiceDate', 'Description', 'Country'] ,axis=1)
# normalize the data
data_frame = data_frame.dropna()
# apply kmeans algo
kmeans = KMeans(n_clusters=4,max_iter=50)
# apply best fit
labels = kmeans.fit(data_frame)
# plot the data
plt.figure(figsize=(8,8))
plt.scatter(data_frame['Quantity'],
            data_frame['UnitPrice'], c = kmeans.labels_)
plt.show()
