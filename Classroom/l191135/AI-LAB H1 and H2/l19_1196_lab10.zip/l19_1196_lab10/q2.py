import pandas as pd
from sklearn.cluster import AgglomerativeClustering
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

%matplotlib inline # import all important packages
data_frame = pd.read_excel("OnlineRetail (1).xlsx")
data_frame.head(5)
data_frame = data_frame.drop(columns = ['StockCode', 'InvoiceNo', 'InvoiceDate', 'Description', 'Country'] ,axis=1)
data_frame = data_frame.dropna()

cluster = AgglomerativeClustering(n_clusters=1, affinity='euclidean', linkage='ward')

cluster.fit_predict(data_frame)

plt.figure(figsize=(8,8))

plt.scatter(data_frame['Quantity'],data_frame['UnitPrice'], c = cluster.labels_)

plt.show()
