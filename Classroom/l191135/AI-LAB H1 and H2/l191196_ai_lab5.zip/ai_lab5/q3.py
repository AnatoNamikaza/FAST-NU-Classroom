'''Create an iterator that returns numbers, starting with 1, and each sequence
will increase by one (returning 1,2,3,4,5 etc.):'''
class iterator:
    def __init__(self):
        pass
    def __iter__(self):
        self.start=1
        return self
    def __next__(self):
        x = self.start
        self.start += 1
        return x

myobj = iterator()
itr = iter(myobj)
print(next(itr))
print(next(itr))
print(next(itr))
print(next(itr))
print(next(itr))
