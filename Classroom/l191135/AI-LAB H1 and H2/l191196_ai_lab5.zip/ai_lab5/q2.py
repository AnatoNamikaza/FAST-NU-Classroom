'''Design a code which reads text from the file “Alphabets.txt” and stores its data in reverse order in
another file. For this you may upload the given text file on Google Collab’s session and define the path
as:
file_path= ‘/Alphabets.txt’
The same convention can be followed for defining path of the resultant file (reversed text file).'''

path = "Alphabets.txt"
path_another_file="another_file"
file = open(path,'r')
text = file.read()
text = text[::-1]
print(text)
another_file_fp = open(path_another_file,'w')
another_file_fp.write(text)
another_file_fp.close()
file.close()

