'''Write a Python program to filter a list of integers using Lambda.
Original list of integers:
[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
Even numbers from the said list:
[2, 4, 6, 8, 10]
Odd numbers from the said list:
[1, 3, 5, 7, 9]'''
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
even_lambda = lambda lst: [x for x in lst if x%2==0]
odd_lambda = lambda lst: [x for x in lst if x%2==1]
print("Original list of integers:")
print(numbers)
print("Even numbers from the said list:")
print(even_lambda(numbers))
print("Odd numbers from the said list:")
print(odd_lambda(numbers))



