'''Write a function AMCount() in Python, which should read each character of a
text file STORY.TXT, should count and display the occurrence of alphabets A and
M (including small cases a and m too).
For Example:
If the file content is as follows:
“Updated information
As simplified by official websites.”
The EUCount() function should display the output as:
A or a:4
M or m :2'''

def AMCount():
    fp = open("STORY.txt",'r')    
    file_text = fp.read()
    a_counts=0
    m_counts=0
    for c in file_text:
        if c.lower()=='a':
            a_counts +=1
        elif c.lower()=='m':
            m_counts +=1
        else:
            pass
    print("A or a: ", a_counts)
    print("M or m: ", m_counts)
AMCount()
