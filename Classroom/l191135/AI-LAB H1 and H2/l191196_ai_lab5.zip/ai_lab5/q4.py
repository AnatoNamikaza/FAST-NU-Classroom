'''Create a class for rectangle shape that calculates its area based upon the length
and width. Make a sub class of triangle called Trapezium, such that it inherits the
functionality of rectangle class and implements area method of its own. Length and
width should be defined in the constructor of rectangle class.'''

class Rectangle:
    def __init__(self,l,w):
        self.length =l
        self.width =w
    def area(self):
        return (self.length * self.width)
class Trapezium(Rectangle):    
    def __init__(self,l,w,h):
        self.height = h
        Rectangle.__init__(self,l,w)
    def area(self):
        return(0.5*(self.length+self.width)*self.height)
    
r = Rectangle(2,3)
print(r.area())

t = Trapezium(2,3,1)
print(t.area())
