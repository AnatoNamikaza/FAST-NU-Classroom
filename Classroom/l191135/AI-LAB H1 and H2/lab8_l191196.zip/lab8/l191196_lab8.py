from math import floor
from math import ceil
import numpy as np
import random

pop_size = 10
pop = []
SIZE = 8

def fitness_up(row_col, arr):
    row = row_col[0]
    col = row_col[1]
    count = 0
    for i in range(row - 1, -1, -1):
        if (i, col) in arr:
            count = 1 + count
    return count



def fitness_right(row_col, arr):
    row = row_col[0]
    col = row_col[1]
    count = 0
    for i in range(col + 1, 8):
        if (row, i) in arr:
            count = 1 + count
    return count

def fitness_right_diagnol(row_col, arr):
    row = row_col[0] + 1
    col = row_col[1] + 1
    count = 0
    while row < SIZE and col < SIZE:
        if (row, col) in arr:
            count = 1 + count
        row = row + 1
        col = col + 1
    return count


def fitness_left_diagnol(row_col, arr):
    row = row_col[0] - 1
    col = row_col[1] - 1
    count = 0
    while row >= 0 and col <= 0:
        if (row, col) in arr:
            count = 1 + count
        row = row - 1
        col = col - 1
    return count

def fitness_left(row_col, arr):
    row = row_col[0]
    col = row_col[1]
    count = 0
    for i in range(col - 1, -1, -1):
        if (row, i) in arr:
            count = 1 + count
    return count


def fitness_down(row_col, arr):
    row = row_col[0]
    col = row_col[1]
    count = 0
    for i in range(row + 1, 8):
        if (i, col) in arr:
            count = 1 + count
    return count

def fitness(row_col):
    count = 0
    for row in row_col:
        count = count + fitness_up(row, list(row_col))
        count = count + fitness_down(row, list(row_col))
        count = count + fitness_left(row, list(row_col))
        count = count + fitness_right(row, list(row_col))
        count = count + fitness_left_diagnol(row, list(row_col))
        count = count + fitness_right_diagnol(row, list(row_col))
    return count


def gen_population():
    global pop

    for i in range(pop_size):
        checkduplicate = []
        for j in range(8):
            row = np.random.randint(0, 8)
            col = np.random.randint(0, 8)
            while (row, col) in checkduplicate:
                row = np.random.randint(0, 8)
                col = np.random.randint(0, 8)
            checkduplicate.append((row, col))
            pop[i][j] = (row, col)


def mutation(progeny):
    for i in range(0, 8):
        curr = progeny[i]
        curr = list(curr)
        ran = random.randint(0, 7)
        ind = random.randint(0, 1)
        curr[ind] = ran
        curr = tuple(curr)
        progeny[i] = curr

    return progeny


def crossover(p1, p2):
    row_col = random.randint(4, 6)
    anotherpoint = random.randint(1, 3)
    offspring = np.empty((2, 8), dtype=tuple)
    parent1 = p1[1]
    parent2 = p2[1]
    offspring[0][0:anotherpoint] = parent1[0:anotherpoint]
    offspring[0][anotherpoint:row_col] = parent2[anotherpoint:row_col]
    offspring[0][row_col:] = parent1[row_col:]

    offspring[1][0:anotherpoint] = parent2[0:anotherpoint]
    offspring[1][anotherpoint:row_col] = parent1[anotherpoint:row_col]
    offspring[1][row_col:] = parent2[row_col:]
    return offspring[0], offspring[1]


def remove_duplicates(array):
    checkArray = list(array)
    for i in range(len(array)):
        while checkArray.count(array[i]) > 1:
            array[i] = (random.randint(0, 7), random.randint(0, 7))
    return array


pop = np.empty((pop_size, 8), dtype=tuple)
gen_population()

itr = 0

while True:
    new = []
    for i in pop:
        i = remove_duplicates(i)  
        new.append((fitness(i), i))  

    new.sort(key=lambda x: x[0])  
    if new[0][0] == 0:  
        break
    print(f"Iteration: {itr}  Fitness: {new[0][0]}")

    parents = new[0:4]  
    progeny = []
    parentindex = 0
    for p in range(2):  
        offspring1, offspring2 = crossover(parents[parentindex], parents[parentindex + 1])
        parentindex = parentindex + 2
        progeny.append(offspring1)
        progeny.append(offspring2)

    
    offsprings_fitness = []
    k = 0
    for i in progeny:
        i = mutation(i)  
        i = remove_duplicates(i)
        offsprings_fitness.append((fitness(i), i))
        new.append(offsprings_fitness[k])
        k = k + 1

    new.sort(key=lambda x: x[0])
    pop = np.empty((pop_size, 8), dtype=tuple)
    for l in range(pop_size):  
        pop[l] = new[l][1]
    itr = itr + 1  

print(f"result: {new[0][1]} with {itr} iterations")
