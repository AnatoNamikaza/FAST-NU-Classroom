#include "lexer.h"
using namespace std;
//for printing tokens names, Same as the enum defined in lexer.h
string reserved[] = {
		     "END_OF_FILE",
		     "ERROR",
		     "KEYWORD",
		     "RELATIONAL_OPERATOR",
		     "ASSIGNMENT_OPERATOR",
		     "ARITHMETIC_OPERATOR",
		     "IDENTIFIER",
		     "NUMERICAL_LITERAL",
		     "CHAR_LITERAL",
		     "STRING",
		     "COMMENT",
		     "BEGIN",
		     "END",
		     "COMMA",
		     "HASH",
		     "COLON",
		     "SEMI_COLON"

};
token::token()
{
    this->lexeme = "";
    this->tokenType = TokenType::ERROR;
}
token::token(string lexeme, TokenType tokenType)
{
    this->lexeme = lexeme;
    this->tokenType = tokenType;
}
void token::Print()
{
    cout << "{" << lexeme << ", "
        << reserved[(int)tokenType] << "}\n";
}
int lexer::getCurrentPointer()
{
    return index;
}
void lexer::setCurrentPointer(int pos)
{
    if (pos >= 0 && pos < tokens.size())
        index = pos;
    else
        index = 0;
}

bool is_relational_operator(string op){
  string operators[] = {"<",">","<=",">=","~="};
  bool found = false;
  for(int i=0; i < sizeof(operators)/sizeof(string); i++){
    if(operators[i] == op) return true;
  }
  return false;
}

bool is_arithmetic_operator(string op){
  string operators[] = {"+","-","*","/","%"};
  bool found = false;
  for(int i=0; i < sizeof(operators)/sizeof(string); i++){
    if(operators[i] == op) return true;
  }
  return false;
}

bool is_keyword(string w){
  string keywords[] = {"main","func","int","char","call","if",
		       "elif","else","for","print",
		       "println","return","in","begin","end"};
  bool found = false;
  for(int i=0; i < sizeof(keywords)/sizeof(string); i++){
    if(keywords[i] == w) return true;
  }
  return false;
}

void lexer::Tokenize()//function that tokenizes your input stream
{
  vector<char>::iterator it = stream.begin();
  //your implementation goes here
  enum states {start,alpha,numeric,
	       alpha_numeric,
	       symbol, start_str,
	       end_str,
	       start_comment,
	       end_comment};
  states state = start;
  string lexeme="";

  while(it != stream.end()){
    char c = *it;
    //cout << c;    
    if(isalnum(c)){
      if(state == start && isalpha(c)){
	lexeme = lexeme + c;
	it++;
	state = alpha;
      }
      else if(state == alpha && isalpha(c)){
	lexeme = lexeme + c;
	it++;	  
      }
      else if(state == alpha && isdigit(c)){
	lexeme = lexeme + c;
	it++;
	state = alpha_numeric;
      }
      else if(state == start && isdigit(c) || state == numeric){
	lexeme = lexeme + c;
	it++;
	state = numeric;
      }
      else if(state == start_str){
	lexeme = lexeme + c;
	it++;
	state = start_str;
      }
      else if(state == start_comment){
	lexeme = lexeme + c;
	it++;
	state = start_comment;
      }
      else{
      	// other than alphanumeric letter
      	if(is_keyword(lexeme)){
      	  // is a keyword
      	  tokens.push_back(token(lexeme, TokenType::KEYWORD));	    
      	}
	else if(lexeme == "=" || lexeme == "<-"){
	  tokens.push_back(token(lexeme, TokenType::ASSIGNMENT_OPERATOR));	    
	}
	else if(lexeme == ";"){
	  tokens.push_back(token(lexeme, TokenType::SEMI_COLON));	    
	}
      	else{
      	  // identifier
      	  tokens.push_back(token(lexeme, TokenType::IDENTIFIER));
      	  //cout << "#####" << lexeme << "####\n";
      	}
      	lexeme = ""; // reset lexeme
      	state = start;
      }
    }
    else if(c ==  '#'){	
      state = start_comment;
      it++;
    }
    else if(c ==  '\n'){
      if(state == start_comment){
	state = end_comment;
	tokens.push_back(token(lexeme, TokenType::COMMENT));
      }
      else if(state == symbol){
	if(is_relational_operator(lexeme)){
	  tokens.push_back(token(lexeme, TokenType::RELATIONAL_OPERATOR));
	}
	else if(is_arithmetic_operator(lexeme)){
	  tokens.push_back(token(lexeme, TokenType::ARITHMETIC_OPERATOR));
	}
	else if(lexeme == "=" || lexeme == "<-"){
	  // assignemnt operator
	  tokens.push_back(token(lexeme, TokenType::ASSIGNMENT_OPERATOR));
	}
	else if(lexeme == ":"){
	  // COLON
	  tokens.push_back(token(lexeme, TokenType::COLON));
	}

	else if(lexeme == ";"){
	  // SEMI COLON
	  tokens.push_back(token(lexeme, TokenType::SEMI_COLON));
	}
	
	else{
	  tokens.push_back(token(lexeme, TokenType::ERROR));
	}
	lexeme = "";
	state = start;
      }
      
      it++;
      lexeme = "";	
      state = start;
    }
    else if(c == '\"'){
      // double quote opeing or closing
      if(state != start_str){
	state = start_str;
	it++;
      }
      else {
	tokens.push_back(token(lexeme, TokenType::STRING));
	it++;
	state = start;
	lexeme = "";
      }
    }
    
    else if(ispunct(c)){      
      if(state == start){
	lexeme = lexeme + c;
	it++;
	state = symbol;
      }
      else if(state == start_comment || state == start_str){
	lexeme = lexeme + c;
	it++;
      }
      else if(state == symbol){
	lexeme = lexeme + c;
	it++;
	state = symbol;
      }
      else if(state == numeric){
	tokens.push_back(token(lexeme, TokenType::NUMERICAL_LITERAL));
	lexeme = "";
	it++;
	state = start;
      }
      else if(state == alpha){
	if(is_keyword(lexeme)){
	  // is a keyword
	  tokens.push_back(token(lexeme, TokenType::KEYWORD));	    
	}
	else{
	  tokens.push_back(token(lexeme, TokenType::IDENTIFIER));
	}
	lexeme = ""; // reset lexeme
	state = start;
	//it++;
      }
      else if(state == alpha_numeric){
	if(is_keyword(lexeme)){
	  // is a keyword
	  tokens.push_back(token(lexeme, TokenType::IDENTIFIER));	    
	}
	lexeme = ""; // reset lexeme
	state = start;
	it++;
      }
      
      else{
	// alphanumeric state
	if(is_relational_operator(lexeme)){
	  // is a ro
	  tokens.push_back(token(lexeme, TokenType::RELATIONAL_OPERATOR));
	}
	else if(c == ':'){
	  tokens.push_back(token(lexeme, TokenType::COLON));
	}
	else if(c == ';'){
	  tokens.push_back(token(lexeme, TokenType::SEMI_COLON));
	}
	else if(is_arithmetic_operator(lexeme)){
	  tokens.push_back(token(lexeme, TokenType::ARITHMETIC_OPERATOR));
	}
	else if(lexeme == "=" || lexeme == "<-"){
	  // assignemnt operator
	  tokens.push_back(token(lexeme, TokenType::ASSIGNMENT_OPERATOR));
	}
	else{
	  // if not valid relational operator
	  tokens.push_back(token(lexeme, TokenType::ERROR));
	}
	lexeme = ""; // reset lexeme
	it++;
	state = start;
      }
    }
    else if( c==  ' '){
      // if state == string or comment then make part of the lexeme
      if(state == start_comment || state == start_str){
	lexeme = lexeme + c;	
      }
      else if(state == alpha_numeric || state == alpha){
	if(is_keyword(lexeme)){
	  // is a keyword
	  tokens.push_back(token(lexeme, TokenType::KEYWORD));	    
	}
	else{
	  tokens.push_back(token(lexeme, TokenType::IDENTIFIER));	    
	}
	
	lexeme = "";
	state = start;
      }
      else if(state == symbol){
	if(is_relational_operator(lexeme)){
	  tokens.push_back(token(lexeme, TokenType::RELATIONAL_OPERATOR));
	}
	else if(is_arithmetic_operator(lexeme)){
	  tokens.push_back(token(lexeme, TokenType::ARITHMETIC_OPERATOR));
	}
	else if(lexeme == "=" || lexeme == "<-"){
	  // assignemnt operator
	  tokens.push_back(token(lexeme, TokenType::ASSIGNMENT_OPERATOR));
	}
	else{
	  tokens.push_back(token(lexeme, TokenType::ERROR));
	}
	lexeme = "";
	state = start;
      }
      else if(state == numeric){
	tokens.push_back(token(lexeme, TokenType::NUMERICAL_LITERAL));
	lexeme = "";
	state = start;
      }
      it++;
    }
    else{
      it++;
    }
  }
  //push_back EOF token at end to identify End of File
  tokens.push_back(token(string(""), TokenType::END_OF_FILE));
}

lexer::lexer(const char filename[])
{
    //constructors: takes file name as an argument and store all
    //the contents of file into the class varible stream
    ifstream fin(filename);
    if (!fin) //if file not found
    {
        cout << "file not found" << endl;
    }
    else
    {
        char byte = 0;
        while (fin.get(byte))
        { //store file contents into stream
            if (byte != '\r')
                stream.push_back(byte);
        }
        stream.push_back(' ');//dummy spaces appended at the end
        stream.push_back(' ');
        //Tokenize function to get all the (token,lexeme) pairs
        Tokenize();
        //assigning tokens to iterator::pointer
        index = 0;
    }
 }
lexer::lexer()
{
    index = -1;
}
void lexer::printRaw()
{
    //helper function to print the content of file
    vector<char>::iterator it = stream.begin();
    for (it = stream.begin(); it != stream.end(); it++)
    {
        cout << *it;
    }
    cout << endl;
}
token lexer::getNextToken()
{
    //this function will return single (token,lexeme) pair on each call
    //this is an iterator which is pointing to the beginning of vector of tokens
    token _token;
    if (index == tokens.size())
    {                       // return end of file if
        _token.lexeme = ""; // index is too large
        _token.tokenType = TokenType::END_OF_FILE;
    }
    else
    {
        _token = tokens[index];
        index = index + 1;
    }
    return _token;
}
void lexer::resetPointer()
{
    index = 0;
}
token lexer::peek(int howFar)
{
    if (howFar <= 0)
    { // peeking backward or in place is not allowed
        cout << "LexicalAnalyzer:peek:Error: non positive argument\n";
        exit(-1);
    }

    int peekIndex = index + howFar - 1;
    if (peekIndex > (tokens.size() - 1))
    {                                                 // if peeking too far
        return token("", TokenType::END_OF_FILE); // return END_OF_FILE
    }
    else
        return tokens[peekIndex];
}
