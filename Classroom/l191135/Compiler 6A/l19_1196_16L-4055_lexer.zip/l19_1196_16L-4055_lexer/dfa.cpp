// C program to implement DFS that accepts
#include <iostream>
using namespace std;

int main(){
  if(ispunct('{')) cout << "yes";
}
