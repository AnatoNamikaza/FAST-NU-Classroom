mc is our file extension abbreviation od "My Compiler". The compiler that we are going to make.
This readme file should contain the details, the pros and cons. Special cases. etc etc.
Provide "How to run your code" here too. 
Be specific about everything.
Code must be thoroughly commented
test your program thoroughly with provided test samples