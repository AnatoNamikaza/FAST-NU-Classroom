#include <iostream>
#include<fstream>
#include <vector>
#include<iostream>
#include<queue>
using namespace std;

class classicTiles {

public:
    unsigned int PuzzleSize;
    vector<vector<unsigned int> > B;
    unsigned int SpaceRow, SpaceCol;

    classicTiles() {
        PuzzleSize = 0;
        SpaceCol = SpaceRow = -1;
    }

    classicTiles(vector<vector<unsigned int> > B) {

        PuzzleSize = B.size();

        this->B = vector< vector<unsigned int> >(PuzzleSize);

        for (unsigned int i = 0; i < PuzzleSize; i++)
            this->B[i] = vector<unsigned int>(PuzzleSize);

        for (unsigned int i = 0; i < PuzzleSize; i++)
            for (unsigned int j = 0; j < PuzzleSize; j++) {
                this->B[i][j] = B[i][j];

                if (!B[i][j]) {
                    this->SpaceRow = i;
                    this->SpaceCol = j;
                }
            }
    }

    void showTiles() {

        for (unsigned int i = 0; i < PuzzleSize; i++) {
            for (unsigned int j = 0; j < PuzzleSize; j++)
                cout << B[i][j] << "\t";
            cout << endl;
        }
    }

    bool isGoalState(classicTiles& Goal) {

        for (unsigned int i = 0; i < PuzzleSize; i++)
            for (unsigned int j = 0; j < PuzzleSize; j++)
                if (this->B[i][j] != Goal.B[i][j])
                    return false;
        return true;
    }

    bool applyMove(char Move, classicTiles& Successor) {
        Successor = *this;

        if (96 < Move && Move < 123)
            Move -= 32;

        if (Move != 'U' && Move != 'D' && Move != 'L' && Move != 'R')
            return false;

        if (SpaceRow == 0 && Move == 'U')
            return false;
        if (SpaceRow == PuzzleSize - 1 && Move == 'D')
            return false;
        if (SpaceCol == 0 && Move == 'L')
            return false;
        if (SpaceCol == PuzzleSize - 1 && Move == 'R')
            return false;

        if (Move == 'U') {
            Successor.B[SpaceRow][SpaceCol] = Successor.B[SpaceRow - 1][SpaceCol];
            Successor.B[SpaceRow - 1][SpaceCol] = 0;
            Successor.SpaceRow--;
        }

        else if (Move == 'D') {
            Successor.B[SpaceRow][SpaceCol] = Successor.B[SpaceRow + 1][SpaceCol];
            Successor.B[SpaceRow + 1][SpaceCol] = 0;
            Successor.SpaceRow++;
        }

        if (Move == 'L') {
            Successor.B[SpaceRow][SpaceCol] = Successor.B[SpaceRow][SpaceCol - 1];
            Successor.B[SpaceRow][SpaceCol - 1] = 0;
            Successor.SpaceCol--;
        }

        else if (Move == 'R') {
            Successor.B[SpaceRow][SpaceCol] = Successor.B[SpaceRow][SpaceCol + 1];
            Successor.B[SpaceRow][SpaceCol + 1] = 0;
            Successor.SpaceCol++;
        }

        return true;
    }

    double getHeuristicValue(classicTiles& GoalState) {
        int out_ = 0;
        for (unsigned int i = 0; i < PuzzleSize; i++)
            for (unsigned int j = 0; j < PuzzleSize; j++)
                if (this->B[i][j] != GoalState.B[i][j])
                    out_++; 
        return out_;
    }

};

class SearchNode {
public:
    classicTiles state;
    double costFromStart;
    double totalCost;
    vector<char> solutionToState;

    SearchNode(classicTiles& initialState) :state(initialState) {
        costFromStart = 0;
        totalCost = 0;
        solutionToState.push_back(' ');
    }

    SearchNode(SearchNode& Parent, char Move) :state(Parent.state) {

        state.applyMove(Move, state);
        costFromStart = Parent.costFromStart + 1;
        solutionToState = Parent.solutionToState;
        solutionToState.push_back(Move);
    }

    void setCost(double cost) {
        totalCost = cost;
    }

    void showNode() {
        state.showTiles();
        cout << "---" << costFromStart << endl;
    }
};


bool operator > (const SearchNode& node1, const SearchNode& node2) {
    return node1.totalCost > node2.totalCost;
}

class TilesSolver {  
    // Default it is BFS
    // You can overwrite just one method to make it some other
    // search algo like AStar

public:
    double SolutionCost;
    unsigned int StatesExpanded;
    unsigned int StatesInQueue;

    virtual void setNodeTotalCost(SearchNode& Node, double cost) {
        Node.setCost(cost);
    }

    virtual SearchNode Solve(SearchNode& Start, classicTiles& GoalState) {

        priority_queue<SearchNode, vector<SearchNode>, greater<vector<SearchNode>::value_type> > openQueue;

        SearchNode Solution(Start);
        openQueue.push(Start);

        while (!openQueue.empty()) {
            SearchNode N = openQueue.top();
            openQueue.pop();

            //            N.showNode();  char x;     cin>>x;

            if (N.state.isGoalState(GoalState)) {
                cout << "Goal Found" << endl;
                SolutionCost = N.costFromStart;
                return N;
            }

            this->StatesExpanded++;

            if (N.state.SpaceRow > 0 && N.solutionToState[N.solutionToState.size() - 1] != 'D') {
                SearchNode CHD(N, 'U');
                this->setNodeTotalCost(CHD, N.costFromStart + 1);
                openQueue.push(CHD);
                this->StatesInQueue++;

            }

            if (N.state.SpaceRow < N.state.PuzzleSize - 1 && N.solutionToState[N.solutionToState.size() - 1] != 'U') {
                SearchNode CHD(N, 'D');
                this->setNodeTotalCost(CHD, N.costFromStart + 1);
                openQueue.push(CHD);
                this->StatesInQueue++;
            }

            if (N.state.SpaceCol > 0 && N.solutionToState[N.solutionToState.size() - 1] != 'R') {
                SearchNode CHD(N, 'L');
                this->setNodeTotalCost(CHD, N.costFromStart + 1);
                openQueue.push(CHD);
                this->StatesInQueue++;
            }

            if (N.state.SpaceRow < N.state.PuzzleSize - 1 && N.solutionToState[N.solutionToState.size() - 1] != 'L') {
                SearchNode CHD(N, 'R');
                this->setNodeTotalCost(CHD, N.costFromStart + 1);
                openQueue.push(CHD);
                this->StatesInQueue++;
            }
        }

        cout << "Goal NOT Found" << endl;
        return Solution;
    }

    TilesSolver() {
        StatesExpanded = StatesInQueue = 0;
        SolutionCost = -1;
    }
};


class AStar : public TilesSolver {
public:
    SearchNode Solve(SearchNode& Start, classicTiles& GoalState) {
        priority_queue<SearchNode, vector<SearchNode>, greater<vector<SearchNode>::value_type> > openQueue;

        SearchNode Solution(Start);
        openQueue.push(Start);

        while (!openQueue.empty()) {
            SearchNode N = openQueue.top();
            openQueue.pop();

            if (N.state.isGoalState(GoalState)) {
                cout << "Goal Found" << endl;
                SolutionCost = N.costFromStart;
                return N;
            }

            this->StatesExpanded++;

            if (N.state.SpaceRow > 0 && N.solutionToState[N.solutionToState.size() - 1] != 'D') {
                SearchNode CHD(N, 'U');
                this->setNodeTotalCost(CHD, N.costFromStart + N.state.getHeuristicValue(GoalState));
                openQueue.push(CHD);
                this->StatesInQueue++;

            }

            if (N.state.SpaceRow < N.state.PuzzleSize - 1 && N.solutionToState[N.solutionToState.size() - 1] != 'U') {
                SearchNode CHD(N, 'D');
                this->setNodeTotalCost(CHD, N.costFromStart + N.state.getHeuristicValue(GoalState));
                openQueue.push(CHD);
                this->StatesInQueue++;
            }

            if (N.state.SpaceCol > 0 && N.solutionToState[N.solutionToState.size() - 1] != 'R') {
                SearchNode CHD(N, 'L');
                this->setNodeTotalCost(CHD, N.costFromStart + N.state.getHeuristicValue(GoalState));
                openQueue.push(CHD);
                this->StatesInQueue++;
            }

            if (N.state.SpaceRow < N.state.PuzzleSize - 1 && N.solutionToState[N.solutionToState.size() - 1] != 'L') {
                SearchNode CHD(N, 'R');
                this->setNodeTotalCost(CHD, N.costFromStart + N.state.getHeuristicValue(GoalState));
                openQueue.push(CHD);
                this->StatesInQueue++;
            }
        }

        cout << "Goal NOT Found" << endl;
        return Solution;
    }

};

class BFS : public TilesSolver {
public:
    // your code in here if needed
};


int main() {

    int puzzleSize = 5;
    
    vector< vector<unsigned int> > s = vector<vector<unsigned int> >(puzzleSize);
    for (int i = 0; i < puzzleSize; i++)
        s[i] = vector<unsigned int>(puzzleSize);

    vector< vector<unsigned int> > g = vector<vector<unsigned int> >(puzzleSize);
    for (int i = 0; i < puzzleSize; i++)
        g[i] = vector<unsigned int>(puzzleSize);

    //----------------------------------------------------------------------------

    //s[0][0] = 1; s[0][1] = 4;  s[0][2] = 2;
    //s[1][0] = 3; s[1][1] = 7;  s[1][2] = 5;
    //s[2][0] = 6; s[2][1] = 8;  s[2][2] = 0;

    //g[0][0] = 0;  g[0][1] = 1;  g[0][2] = 2;
    //g[1][0] = 3;  g[1][1] = 4;  g[1][2] = 5;
    //g[2][0] = 6;  g[2][1] = 7;  g[2][2] = 8;

    //----------------------------------------------------------------------------
    
    //s[0][0] = 1; s[0][1] = 2;  s[0][2] = 6;  s[0][3] = 3;
    //s[1][0] = 4; s[1][1] = 9;  s[1][2] = 5;  s[1][3] = 7;
    //s[2][0] = 8; s[2][1] = 0;  s[2][2] = 10; s[2][3] = 11;
    //s[3][0] = 12; s[3][1] = 13; s[3][2] = 14; s[3][3] = 15;

    //g[0][0] = 0;  g[0][1] = 1;  g[0][2] = 2;  g[0][3] = 3;
    //g[1][0] = 4;  g[1][1] = 5;  g[1][2] = 6;  g[1][3] = 7;
    //g[2][0] = 8;  g[2][1] = 9;  g[2][2] = 10; g[2][3] = 11;
    //g[3][0] = 12; g[3][1] = 13; g[3][2] = 14; g[3][3] = 15;
    
    //----------------------------------------------------------------------------

    s[0][0] = 5; s[0][1] = 1;  s[0][2] = 2;  s[0][3] = 3; s[0][4] = 4;
    s[1][0] = 6; s[1][1] = 11;  s[1][2] = 7;  s[1][3] = 8; s[1][4] = 9;
    s[2][0] = 10; s[2][1] = 16;  s[2][2] = 12; s[2][3] = 13; s[2][4] = 14;
    s[3][0] = 15; s[3][1] = 17; s[3][2] = 22; s[3][3] = 18; s[3][4] = 19;
    s[4][0] = 20; s[4][1] = 0; s[4][2] = 21; s[4][3] = 23; s[4][4] = 24;


    g[0][0] = 0;  g[0][1] = 1;  g[0][2] = 2;  g[0][3] = 3;  g[0][4] = 4;
    g[1][0] = 5;  g[1][1] = 6;  g[1][2] = 7;  g[1][3] = 8;  g[1][4] = 9;
    g[2][0] = 10;  g[2][1] = 11;  g[2][2] = 12; g[2][3] = 13;  g[2][4] = 14;
    g[3][0] = 15; g[3][1] = 16; g[3][2] = 17; g[3][3] = 18;  g[3][4] = 19;
    g[4][0] = 20; g[4][1] = 21; g[4][2] = 22; g[4][3] = 23;  g[4][4] = 24;
    
    //----------------------------------------------------------------------------




    classicTiles IS(s), GS(g);

    cout << "Start " << endl;
    IS.showTiles();
    cout << "Goal " << endl;
    GS.showTiles();


    TilesSolver* P;
    BFS bfs;
    AStar astar;
    
    {
        cout << "=================" << endl;
        cout << "Solution with BFS" << endl;
        cout << "=================" << endl;
        P = &bfs;
        SearchNode initialNode(IS);
        SearchNode Sol = P->Solve(initialNode, GS);

        cout << "Solution" << endl;
        cout << "\tSolution Size ";
        cout << Sol.solutionToState.size() - 1 << endl;
        cout << "\t";
        for (unsigned int i = 0; i < Sol.solutionToState.size(); i++)
            cout << Sol.solutionToState[i];

        cout << endl << "Summary " << endl
            << P->SolutionCost << " Cost" << endl
            << P->StatesExpanded << " States Expanded" << endl
            << P->StatesInQueue << " States In Queue" << endl;
    }

    {
        cout << "=================" << endl;
        cout << "Solution with A*" << endl;
        cout << "=================" << endl;
        P = &astar;
        SearchNode initialNode(IS);
        SearchNode Sol = P->Solve(initialNode, GS);

        cout << "Solution" << endl;
        cout << "\tSolution Size ";
        cout << Sol.solutionToState.size() - 1 << endl;
        cout << "\t";
        for (unsigned int i = 0; i < Sol.solutionToState.size(); i++)
            cout << Sol.solutionToState[i];

        cout << endl << "Summary " << endl
            << P->SolutionCost << " Cost" << endl
            << P->StatesExpanded << " States Expanded" << endl
            << P->StatesInQueue << " States In Queue" << endl;

    }

    return 0;
}
