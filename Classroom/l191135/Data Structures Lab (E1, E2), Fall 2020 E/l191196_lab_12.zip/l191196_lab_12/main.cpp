#include <iostream>
#include "graph.h"
using namespace std;
    
int main(){
  Graph g;
  g.TakeInput("AdjacencyList.");
    g.print();
  g.ExploreFunction("0"); 
}
