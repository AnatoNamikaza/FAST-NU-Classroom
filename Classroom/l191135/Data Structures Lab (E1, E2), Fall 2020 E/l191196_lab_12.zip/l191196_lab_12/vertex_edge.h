#ifndef _V_H
#define _V_H

#include <iostream>
#include<list>
#include<stack>
using namespace std;
struct Edge; // forward declaration

struct Vertex{
  string label;
  //  Vertex *next;
  list<Edge*> *edge_list;

  Vertex(){
    edge_list = new list<Edge*>();
    //next = NULL;
  }

  Vertex(string _label){
    label = _label;
    edge_list = new list<Edge*>();    
  }

  ~Vertex(){
    if(edge_list != NULL){
      delete edge_list;
    }
    edge_list = NULL;
  }
};

struct Edge{
  string label; // A to B is AB
  Vertex *vertex; // vertex to which it is connected
  //Edge *next; // next adjacent edge

  Edge(){
    vertex = NULL;
    //next = NULL;
  }

  Edge(string label, Vertex *_vertex){
    this->label = label;
    vertex = _vertex;
    //next = NULL;
  }

};
#endif
