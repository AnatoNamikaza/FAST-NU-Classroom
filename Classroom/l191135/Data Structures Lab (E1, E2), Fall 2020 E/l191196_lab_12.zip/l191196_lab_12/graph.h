#include "vertex_edge.h"
class Graph{
private:
  list<Vertex*> *vertex_list;
  int v; // though it is not required
  // but to meet the critaria of main file
  bool is_visited(list<string> *visited, string label){
    bool found = false;
    list<string>::iterator it = visited->begin();
    while(it != visited->end()){
      if(*it == label){
	found = true;
	break;
      }
      it++;
    }
    return found;
  }
public:
  Graph(){
    vertex_list = NULL;
  }

  void set_vertex_list(list<Vertex*> *v_list){
    vertex_list = v_list;
  }

    list<Vertex*>* get_vertex_list(){
    return vertex_list;
    }

  void addVertex(string v1){
    Vertex *new_vertex = new Vertex(v1);
    //cout << new_vertex->label << endl;
    if(vertex_list == NULL){
      vertex_list = new list<Vertex*>();
      vertex_list->push_back(new_vertex);
    }
    else{
      // cout << "adding node after \n" << vertex_list->back()->label << endl;
      vertex_list->push_back(new_vertex);
    }
  }


  void addEdge(string l1, string l2){
    // connecting label_1 and label_2
    bool l1_found=false;
    bool l2_found=false;
    Vertex *v1, *v2;
    
    list<Vertex*>::iterator it = vertex_list->begin();
    while(it != vertex_list->end()){
      if(l1 == (*it)->label) {l1_found = true; v1 = *it;}
      if(l2 == (*it)->label) {l2_found = true; v2 = *it;}
      it++;
    }
    
    if(l1_found && l2_found){
      // such vertices exist
      // undirected graph
      string edge_label = l1+l2; // concatenation
      // AB
      Edge *new_edge = new Edge(edge_label,v2);
      v1->edge_list->push_back(new_edge);

      // edge_label = l2+l1; // concatenation
      // //cout << edge_label << "-----" << endl;
      // new_edge = new Edge(edge_label,v1);
      // v2->edge_list->push_back(new_edge);
    }
    else{
      cout << "This pair does not exist\n";
    }
  }
  void ExploreFunction(string label){
    list<Vertex*>::iterator start = vertex_list->begin();
    // go to a start vertex label
    while(start != vertex_list->end()){
      if((*start)->label == label) {
	break;
      }
      start++;
    }
    
    list<string> *visited = new list<string>();
    stack<Vertex*> adjacent;
    if(start != vertex_list->end()){
      adjacent.push(*start);
      visited->push_back((*start)->label);
      cout << "DFS traversal starting from " << label << endl;
      while(! adjacent.empty()){
    	Vertex *v = adjacent.top();
    	adjacent.pop();
    	list<Edge*>::iterator eit = v->edge_list->begin();
    	while(eit != v->edge_list->end()){
    	  // push all adjacent vertices
    	  if(! is_visited(visited,(*eit)->vertex->label)){
    	    adjacent.push((*eit)->vertex);
	    visited->push_back((*eit)->vertex->label);
	    //--------------- print visited list
	    list<string>::iterator it = visited->begin();
	    while(it != visited->end()){
	      cout << *it << " ";
	      it++;
	    }
	    cout << endl;

	    //---------------
	  }
    	  eit++;    	
	}	
      }
    }
  }

  void TakeInput(const char *fileName){
    Graph *g = new Graph();
    g->addVertex("0");
    g->addVertex("1");
    g->addVertex("2");
    g->addVertex("3");
    g->addVertex("4");
    g->addVertex("5");
    g->addVertex("6");
    g->addVertex("7");
    g->addVertex("8");

    int adjacency_list[9][9] =
      {{ 0, 1, 0, 1, 0, 0, 0, 0, 1 },
       { 1, 0, 0, 0, 0, 0, 0, 1, 0 },
       { 0, 0, 0, 1, 0, 1, 0, 1, 0 },
       { 1, 0, 1, 0, 1, 0, 0, 0, 0 },
       { 0, 0, 0, 1, 0, 0, 0, 0, 1 },
       { 0, 0, 1, 0, 0, 0, 1, 0, 0 },
       { 0, 0, 0, 0, 0, 1, 0, 0, 0 },
       { 0, 1, 1, 0, 0, 0, 0, 0, 0 },
       { 1, 0, 0, 0, 1, 0, 0, 0, 0 } };

    for(int i=0; i< 9; i++){
      for(int j=0; j< 9; j++){
	//cout << adjacency_list[i][j] << " ";
	char _v1[2] ;
	_v1[0]= i+'0';
	_v1[1]= '\0';
	char _v2[2] ;
	_v2[0]= j+'0';
	_v2[1] = '\0';
     
	string v1(_v1);
	string v2(_v2);
	if(adjacency_list[i][j] == 1){
	  g->addEdge(v1,v2);
	}
      }
    }

    this->set_vertex_list(g->get_vertex_list());
    // g->printVertices();
    // g->print();
  }
  void printVertices(){
    list<Vertex*>::iterator it = vertex_list->begin();
    cout << "list of vertices\n";
    while(it != vertex_list->end()){
      cout << (*it)->label << endl;
      it++;
    }
    cout << endl;
  }

  void print(){
    list<Vertex*>::iterator it = vertex_list->begin();
    cout << "vertices | Edges\n";
    cout << "-------------------------\n";
    while(it != vertex_list->end()){
      cout << (*it)->label << "| ";
      //-------------- print edges
      list<Edge*>::iterator eit = (*it)->edge_list->begin();
      while(eit != (*it)->edge_list->end()){
	cout << (*eit)->label << " ";
	eit++;
      }
      cout << " total edges: " << (*it)->edge_list->size();
      cout << endl;
      
      //-------------
      it++;
    }
    cout << endl;
  }

  void printAdjacency(){
    list<Vertex*>::iterator it = vertex_list->begin();
    cout << "\t";
    while(it != vertex_list->end()){
      cout << (*it)->label << " \t";
      it++;
    }

    it = vertex_list->begin();
    while(it != vertex_list->end()){
      cout << (*it)->label << " | ";
      it++;
    }
    cout << endl;
  }

  ~Graph(){
    if(vertex_list != NULL){    
      while(!vertex_list->empty()) vertex_list->pop_back();
    }
  }
};
