#include<omp.h>
#include<iostream>

using namespace std;
void merge(int arr[], int left, int mid, int right);
void merge_sort(int a[], int left, int right);

int main()
{
    int number_of_rows;
    cout << "Please enter the number of number_of_rows: ";
    cin >> number_of_rows;
    cout << "Please enter the number of columns: ";
    int number_of_cols;
    cin >> number_of_cols;
    
    int** matrix = new int* [number_of_rows];
    for (int i = 0; i < number_of_rows; i++)
        matrix[i] = new int[number_of_cols];

    int* sum = new int[number_of_rows];
    for (int i = 0; i < number_of_rows; i++)
        sum[i] = 0;

    for (int i = 0; i < number_of_rows; i++)
        for (int j = 0; j < number_of_cols; j++)
            matrix[i][j] = rand() % 100;

    for (int i = 0; i < number_of_rows; i++)
    {
        for (int j = 0; j < number_of_cols; j++)
            cout << matrix[i][j] << " ";
        cout << endl;
    }

    int rank;
    int data = 0;
    int oneRow[4];
    int sums[4];
    MPI_Init(NULL,NULL);
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    MPI_Scatter(matrix, cols, MPI_INT, oneRow, cols, MPI_INT, 0, MPI_COMM_WORLD);
    mergeSort(oneRow, 0, cols - 1);
   /* printf("%d: %d %d %d\n", rank, oneRow[0], oneRow[1], oneRow[2]);*/
    
    MPI_Barrier(MPI_COMM_WORLD);
    int sum = 0;
    for (int i = 0; i < cols; i++)
    {
        sum += oneRow[i];
    }
    //cout << sum << endl;
    MPI_Gather(oneRow, cols, MPI_INT, matrix, cols, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Gather(&sum, 1, MPI_INT, sums, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Finalize();


    if (rank == 0)
    {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++)
                cout << matrix[i][j] << " ";
            cout << endl;
        }
        int final = 0;
        for (int i = 0; i < rows; i++)
        {
            final += sums[i];
        }
        cout << final << endl;
    }

}

}

void merge(int arr[], int left, int mid, int right)
{
    int i, j, k;
    int n1 = mid - left + 1;
    int n2 = right - mid;

    int* left_array = new int[n1], * right_array = new int[n2];

    for (i = 0; i < n1; i++)
        left_array[i] = arr[left + i];
    for (j = 0; j < n2; j++)
        right_array[j] = arr[mid + 1 + j];


    i = 0;
    j = 0;
    k = left;

    while (i < n1 && j < n2)
    {

        if (left_array[i] <= right_array[j]) {
            arr[k] = left_array[i];
            i++;
        }
        else {
            arr[k] = right_array[j];
            j++;
        }
        k++;
    }

    while (i < n1) {
        arr[k] = left_array[i];
        i++;
        k++;
    }

    while (j < n2) {
        arr[k] = right_array[j];
        j++;
        k++;
    }
}


void merge_sort(int a[], int left, int right)
{
    int mid;
    if (left < right)
    {
        mid = (left + right) / 2;

#pragma omp parallel num_threads(2)
        {
#pragma omp sections
            {
#pragma omp section
                merge_sort(a, left, mid);
#pragma omp section
                merge_sort(a, mid + 1, right);
            }

        }
        merge(a, left, mid, right);
    }
}
