public class GlobalMembers
{
	public static void main(String[] args)
	{
		Bank_Account[] Accounts = new Bank_Account[4];

		Accounts[0] = new Current_Account(1234,"Ahmed",(float) 500);
		Accounts[1] = new Basic_Account(1234,"Hasan",(float) 5000);
		Accounts[2] = new Basic_Account(73,"Kate",(float) 123.3);
		Accounts[3] = new Current_Account(86,"Max",(float) 1124.3);

		for(int i = 0; i < 4; i++){
			Accounts[i].View_profile();
			System.out.print("-----------------------\n");		
			Accounts[i].Withdraw_credits();
			System.out.print("+++++++++++++++++++++++\n");		
			Accounts[i].View_profile();
			System.out.print("-----------------------\n");		
		}

		System.out.print("\n=========================\n");		

		for(int i = 0; i < 4; i++){
			Accounts[i].Deposit_credits();
			System.out.print("+++++++++++++++++++++++\n");		
			Accounts[i].View_profile();
			System.out.print("-----------------------\n");		
		}
	}
}