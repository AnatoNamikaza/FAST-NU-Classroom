import java.util.*; 

abstract public class Bank_Account
{
	private int account_ID;
	private String account_holder_name;
	private float account_balance;

	public Bank_Account(int id, String name, float bal)
	{
		account_ID = id;
		account_holder_name = name;
		account_balance = bal;
	}

	public final void set_ID(int id)
	{
		account_ID = id;
	}

	public final void set_balance(float bal)
	{
		account_balance = bal;
	}

	public final void set_holder_name(String name)
	{
		account_holder_name = name;
	}

	public final int get_ID()
	{
		return account_ID;
	}

	public final float get_balance()
	{
		return account_balance;
	}

	public final String get_holder_name()
	{
		return account_holder_name;
	}

	public void Deposit_credits()
	{
		var sc= new Scanner(System.in);
		float money = 0;
		System.out.print("Enter the amount to deposit:\n");
		money = sc.nextFloat();
		account_balance += money;
		System.out.print("\nAmount has been deposit (^_^)\n");
	}

	public void Withdraw_credits(){	}

	public void View_credits()
	{
		System.out.print("Your current balance is: ");
		System.out.print(get_balance());
		System.out.print('\n');
	}
	
	public void View_profile(){	}
}