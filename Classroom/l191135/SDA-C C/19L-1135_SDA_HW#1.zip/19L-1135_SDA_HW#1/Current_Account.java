import java.util.*; 

public class Current_Account extends Bank_Account
{
	public Current_Account(int id, String name, float bal)
	{
		super( id, name, bal);
		// System.out.print("\n\nYour Account has been created (^_^)\n");
	}

	public Current_Account(Bank_Account accounts)
	{
		super(accounts.get_ID(), accounts.get_holder_name(), accounts.get_balance());
	}

	@Override
	public void Withdraw_credits()
	{
		Scanner sc= new Scanner(System.in);
		float money = 0;
		
		while (true)
		{
			System.out.print("Enter the amount to withdraw:\n");
			money = sc.nextFloat();
			if (money <= get_balance() && money >= 0F)
			{
				break;
			}
			System.out.print("Insufficient balance (-_-)\nPlease try again.\n");
		}
		set_balance(get_balance() - money);
		
		System.out.print("\nAmount has been withdrawn (^_^)\n");
	}

	@Override
	public void View_profile()
	{
		System.out.print("Your Account Type is Current Account.");
		System.out.print('\n');
		System.out.print("Your Account ID is: ");
		System.out.print(get_ID());
		System.out.print('\n');
		System.out.print("Your Account name is: ");
		System.out.print(get_holder_name());
		System.out.print('\n');
		System.out.print("Your current balance is: ");
		System.out.print(get_balance());
		System.out.print('\n');
	}
}