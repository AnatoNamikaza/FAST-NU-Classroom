#include <iostream>
#include "Circle.h"
#include "Triangle.h"
#include "Style.h"

using namespace std;

void main() {
	Circle c(3, 4, 2.5);
	c.print();				//Displays: Point(3,4) Called Circle() Called ((3,4),2.5)
	triangle obj(1, 0, 0, 1, 0, 0);
	obj.print();			//Displays: Point(1,0) Called Point(0,1) Called Point(0,0) Called Triangle() Called ((1,0),(0,1),(0,0))
	char *arr{ new char[10] {'b', 'l', 'u', 'e'} };
	Style Style1(arr,true);
	Circle circle1(3, 4, 2.5, &Style1);
	circle1.print();		//Displays: Style() Called Point(3,4) Called Circle() Called ((3,4),2.5)
							//			Color: blue, isFilled : 1
	triangle triangle1(1, 0, 0, 1, 0, 0, &Style1);
	triangle1.print();		//Displays: Style() Called Point(3,4) Called Circle() Called ((3,4),2.5)
							//			Color: blue, isFilled : 1
	char *arra{ new char[10] {'r', 'e', 'd' } };
	circle1.GetStyle()->SetColor(arra);		//Changes circle1's color from "blue" to "red".
	circle1.GetStyle()->SetFilled(1);
	triangle1.print();		//Displays: ((1,0),(0,1),(0,0))
							//			Color: red , isFilled: 1
	circle1.print();		//Displays: ((3,4),2.5)
							//			Color: red , isFilled: 1


	//system("pause");
	//return 0;
}

//Result#1:
//Point(3,4) Called Circle() Called ((3,4),2.5)
//~Circle() Called Destorying Circle
//~Point(3,4) Called Destorying Points
//~Point(0,0) Called Destorying Points

//Result#2:
//Point(3,4) Called Circle() Called ((3,4),2.5)
//Point(1,0) Called Point(0,1) Called Point(0,0) Called Triangle() Called ((1,0)(0,1),(0,0))
//~Triangle() Called Destorying Triangle
//~Point(1,0) Called Destorying Points
//~Point(0,1) Called Destorying Points
//~Point(0,0) Called Destorying Points
//~Point(0,0) Called Destorying Points
//~Point(0,0) Called Destorying Points
//~Point(0,0) Called Destorying Points
//~Circle() Called Destorying Circle
//~Point(3,4) Called Destorying Points
//~Point(0,0) Called Destorying Points

//Result#3:
//Point(1, 0) Called Point(0, 1) Called Point(0, 0) Called Triangle() Called((1, 0), (0, 1), (0, 0))
//Style() Called Point(3, 4) Called Circle() Called((3, 4), 2.5)

//Result#4:
//Point(1, 0) Called Point(0, 1) Called Point(0, 0) Called Triangle() Called((1, 0), (0, 1), (0, 0))
//Style() Called Point(3, 4) Called Circle() Called((3, 4), 2.5)
//Color : blue, isFilled : 1
//	~Circle() Called Destorying Circle
//	~Point(3, 4) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Style() Called Destorying Style
//	~Triangle() Called Destorying Triangle
//	~Point(1, 0) Called Destorying Points
//	~Point(0, 1) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Point(0, 0) Called Destorying Points

//Result#5:
//Point(1, 0) Called Point(0, 1) Called Point(0, 0) Called Triangle() Called((1, 0), (0, 1), (0, 0))
//Style() Called Point(3, 4) Called Circle() Called((3, 4), 2.5)
//Color : blue, isFilled : 1
//	Point(1, 0) Called Point(0, 1) Called Point(0, 0) Called Triangle() Called((1, 0), (0, 1), (0, 0))
//	Color : blue, isFilled : 1
//	~Triangle() Called Destorying Triangle
//	~Point(1, 0) Called Destorying Points
//	~Point(0, 1) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Circle() Called Destorying Circle
//	~Point(3, 4) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Style() Called Destorying Style
//	~Triangle() Called Destorying Triangle
//	~Point(1, 0) Called Destorying Points
//	~Point(0, 1) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Point(0, 0) Called Destorying Points

//Result#6:
//Point(1, 0) Called Point(0, 1) Called Point(0, 0) Called Triangle() Called((1, 0), (0, 1), (0, 0))
//Style() Called Point(3, 4) Called Circle() Called((3, 4), 2.5)
//Color: blue, isFilled : 1
//	Point(1, 0) Called Point(0, 1) Called Point(0, 0) Called Triangle() Called((1, 0), (0, 1), (0, 0))
//	Color : blue, isFilled : 1
//	((3, 4), 2.5)
//	Color : red, isFilled : 1
//	((1, 0), (0, 1), (0, 0))
//	Color : red, isFilled : 1
//	~Triangle() Called Destorying Triangle
//	~Point(1, 0) Called Destorying Points
//	~Point(0, 1) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Circle() Called Destorying Circle
//	~Point(3, 4) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Style() Called Destorying Style
//	~Triangle() Called Destorying Triangle
//	~Point(1, 0) Called Destorying Points
//	~Point(0, 1) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Point(0, 0) Called Destorying Points
//	~Point(0, 0) Called Destorying Points

