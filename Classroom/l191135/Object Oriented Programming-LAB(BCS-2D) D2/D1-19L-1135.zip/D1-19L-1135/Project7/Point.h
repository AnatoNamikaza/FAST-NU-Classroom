#pragma once
class Point {
	int x,y;
public:
	Point();
	Point(int x, int y);
	void print();
	~Point();
};