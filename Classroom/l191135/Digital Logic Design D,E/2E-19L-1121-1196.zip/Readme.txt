DLD project 2020
Section 2E
Project Name: Car parking controller

Roll No 1: 19L-1121
Roll No 2: 19L-1196

=========================
How to use:

There is input for car parking and in response there is probes that will indicate that specific car parking areas are under use.