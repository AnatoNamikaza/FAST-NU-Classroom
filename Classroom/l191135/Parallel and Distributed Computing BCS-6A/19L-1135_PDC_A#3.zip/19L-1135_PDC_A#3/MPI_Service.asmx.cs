using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace Assignment3PDC
{
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    public class Myservice : System.Web.Services.WebService
    {
        [WebMethod]
        public int sizeofData(int size)
        {
            return size;
        }
        [WebMethod]
        public int Data(int num)
        {
            return num;
        }
        [WebMethod]
        public int TotalPrime(int c)
        {
            return c;
        }
        [WebMethod]
        public int maxNum(int m)
        {
            return m;
        }
    }
}

