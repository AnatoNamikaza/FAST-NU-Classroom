using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Xml.Linq;
using ConsoleApp1.localhost;
namespace Assignment3
{
    class Program
    {
        public static bool IsPrime(int number)
        {
            if (number <= 1) return false;
            if (number == 2) return true;
            if (number % 2 == 0) return false;

            var boundary = (int)Math.Floor(Math.Sqrt(number));

            for (int i = 3; i <= boundary; i += 2)
                if (number % i == 0)
                    return false;
            return true;
        }
        static void Main(string[] args)
        {
            Myservice Myapp = new Myservice();
            int i;
            int size;
            Console.Write("\nEnter Size of Array : ");
            size = Convert.ToInt32(Console.ReadLine());
            Console.Write("\nSize of Array : ");
            int s = Myapp.sizeofData(size);
            Console.Write(s);
            Console.Write("\n");
            int[] arr = new int[size];
            int[] temp = new int[size];
            int count = 0;
            bool isPrime = false;
            Console.Write("\nInput array elements\n");
            for (i = 0; i < arr.Length; i++)
            {
                Console.Write("i : ");
                arr[i] = Convert.ToInt32(Console.ReadLine());
                temp[i] = Myapp.Data(arr[i]);
            }
            for (i = 0; i < arr.Length; i++)
            {
                isPrime = IsPrime(temp[i]);
                if (isPrime == true)
                {
                    count++;
                }
            }
            Console.Write("\nTotal Prime Number : ");
            int COUNT = Myapp.TotalPrime(count);
            Console.Write(COUNT);
            int max = 0;
            for (i = 0; i < arr.Length; i++)
            {
                if (max < arr[i])
                {
                    max = arr[i];
                }
            }
            int maxno = Myapp.maxNum(max);
            Console.Write("\nbiggest number in matrix is :  ");
            Console.Write(max);
            Console.ReadLine();
        }

    }
}
