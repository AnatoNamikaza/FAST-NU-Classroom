# include <iostream>
# include <string>
# include <ctime>
# include <stdlib.h>
# include "mpi.h"
# include <sstream>
# include <omp.h>

using namespace std;

void merge(int* Array1, int* Array2, int l, int m, int r)
{
	int i, j, k, dummy;	i = l; dummy = l; j = m + 1;
	//m=l+i/2
	while ((dummy <= m) && (j <= r))
	{
		if (Array1[dummy] <= Array1[j]) { Array2[i] = Array1[dummy]; dummy++; }
		else { Array2[i] = Array1[j]; j++; }
		i++;
	}

	if (m < dummy) for (k = j; k <= r; k++) { Array2[i] = Array1[k]; i++; }
	else for (k = dummy; k <= m; k++) { Array2[i] = Array1[k]; i++; }

	for (k = l; k <= r; k++)
		Array1[k] = Array2[k];
}

void mergeSort(int* Array1, int* Array2, int l, int r)
{
	int m;
	if (l < r)
	{
		m = (l + r) / 2;
#pragma omp parallel num_threads(6)
		{
#pragma omp sections
			{
#pragma omp section
				{mergeSort(Array1, Array2, l, m); }
#pragma omp section
				{mergeSort(Array1, Array2, (m + 1), r); }
#pragma omp section
				{merge(Array1, Array2, l, m, r); }
			}
		}
	}
}

int main(int argc, char* argv[])
{
	int rows; int columns;

	cout << "Input rows:";	cin >> rows; cout << endl;
	cout << "Input columns:"; cin >> columns; cout << endl;

	int* arr_1d = new int[rows * columns];	int** arr_2d = new int* [rows];

	for (int i = 0; i < rows; i++) arr_2d[i] = new int[columns];

	int i, j;

	srand(time(NULL));
	for (i = 0; i < rows; i++) for (j = 0; j < columns; j++) arr_2d[i][j] = rand() % 200;

	cout << "Matrix: " << endl;
	for (i = 0; i < rows; i++)
	{
		for (j = 0; j < columns; j++) cout << arr_2d[i][j] << " ";
		cout << endl;
	}

	int lim = rows * columns;
	for (int i = 0; i < lim; ++i) arr_1d[i] = arr_2d[i / columns][i % columns];

	int world_rank; int world_size;	int sum = 0;
	MPI_Init(&argc, &argv); MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
	MPI_Comm_size(MPI_COMM_WORLD, &world_size); int size = (rows * columns) / world_size;

#pragma omp parallel
	{
		int* sub_array = new int[lim];
		MPI_Scatter(arr_1d, size, MPI_INT, sub_array, size, MPI_INT, 0, MPI_COMM_WORLD);
		int* temp_array = new int[lim];
		mergeSort(sub_array, temp_array, 0, (lim - 1));
		cout << "\n";
		int* sorted_array = NULL;
		if (world_rank == 0)
			sorted_array = new int[lim];
		MPI_Gather(sub_array, size, MPI_INT, sorted_array, size, MPI_INT, 0, MPI_COMM_WORLD);
		if (world_rank == 0)
		{
			int* other_array = new int[lim];
			mergeSort(sorted_array, other_array, 0, (lim - 1));
			cout << "Sorted Array in decsending order: \n" << endl;
			for (int c = (lim - 1); c >= 0; --c) { cout << sorted_array[c] << " ";	sum += sorted_array[c]; }
			for (int v = 0; v < 2; v++) cout << endl;
			cout << "Total Sum = " << sum << endl; cout << endl;
			delete[]other_array; delete[]sorted_array;
		}

		delete[]arr_1d; delete[]sub_array; delete[]temp_array;
		for (int i = 0; i < rows; i++)delete[]arr_2d[i];

		delete[]arr_2d;
		MPI_Barrier(MPI_COMM_WORLD);
		MPI_Finalize();
	}
	return 0;
}