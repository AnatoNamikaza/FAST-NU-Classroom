Name:       Abdul-Rehman
Rollno:     19L-1135
Section:    CS_4A
---------------------------------------------

For task#1, use command: 

        g++ Q1.cpp -o 1out
	./1out

For task#2, use command: 

	g++ Q2.cpp -o 2out
	./2out in.txt out.txt

	or

	man ls > in.txt 
        make

	Thank you :)