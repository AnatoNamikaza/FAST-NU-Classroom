Name:       Abdul-Rehman
Rollno:     19L-1135
Section:    CS_4A
---------------------------------------------

For task#1, use command: 

	gcc Q1.c -o Q1
	./Q1

For task#2, use command: 
    
	gcc Q2.c -o Q2
	./Q2 15 45 87 65 98 54 100

For task#3, use command: 
	g++ Q3.cpp -o Q3
	./Q3

        Thank you :)