
For task#1, use command: 

        ./task#1.out  testfile.txt

For task#2, use command: 
    
        ./task#2.out 3 2 9 7 1 15 31 22 44

        Thank you :)