import intro2java.Person;

public class Student implements Person{

    private String email,name;
    private char grade;
    
    Student(String n,String e, char g){
	name = n;
	email = e;
	grade = g;
    }
    public String getEmail(){return email;}

    /**
     * Returns the name of the person
     */
    public String getName(){return name;}

    /**
     * Returns a description of the person.
     */
    public String getDescription(){
	String des = "a " + grade + " grade Student";
	return des;
    }
    // returs the grade
    public char getGrade(){return grade;}

    // public static void main(String args[]){
    // Student s1 = new Student("Zaeem","quaidzaeem@gmail.com",'B');
    // System.out.println(s1.getDescription());
    // }
}
