import intro2java.PersonViewer;

public class EnhancedPersonViewer extends PersonViewer{

    public void viewPerson(Employee e){
	System.out.println(e.getDescription());
    }
    public void viewPerson(Lecturer l){
	System.out.println(l.getDescription());
	
    }
    public void viewPerson(Student s){
	System.out.println(s.getDescription());
	
    }
ppp
    public void view(Object o){
	if(o instanceof Employee){
	    Employee e1 = (Employee) o; // cast
	    viewPerson(e1);
	}
	else if(o instanceof Lecturer){
	    Lecturer l1 = (Lecturer) o; // cast
	    viewPerson(l1);
	}
	else if(o instanceof Student){
	    Student s1 = (Student) o; // cast
	    viewPerson(s1);
	}
	else{
	    System.out.println("error: wrong type\n");
	}

    }
    public static void main(String argv[]){
	Student s1 = new Student("Zaeem","zaeemyousaf@live.com",'D');
	Lecturer l1 = new Lecturer("Ms Hira","hira@live.com","Adavanced Programming");
	Employee e1 = new Employee("Sir haroon","haroon@gmail.com","CS");
	EnhancedPersonViewer enhancedpersonViewer = new EnhancedPersonViewer();
	enhancedpersonViewer.view(s1);
        enhancedpersonViewer.view(l1);
	enhancedpersonViewer.view(e1);
    }
}
