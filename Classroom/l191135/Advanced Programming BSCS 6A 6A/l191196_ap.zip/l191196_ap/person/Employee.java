import intro2java.Person;

public class Employee implements Person{

    private String email,name, department;
    
    Employee(String n,String e, String d){
	name = n;
	email = e;
	department = d;
    }
    public String getEmail(){return email;}

    /**
     * Returns the name of the person
     */
    public String getName(){return name;}

    /**
     * Returns a description of the person.
     */
    public String getDescription(){
	String des = name + " works in " + department + " department";
	return des;
    }

    public String getDepartment(){return department;}
    
    // public static void main(String args[]){
    // Employee l1 = new Employee("Zaeem","quaidzaeem@gmail.com","HR");
    // System.out.println(l1.getDescription());
    // }
}
