import intro2java.Person;

public class Lecturer implements Person{

    private String email,name, subject;
    
    Lecturer(String n,String e, String s){
	name = n;
	email = e;
	subject = s;
    }
    public String getEmail(){return email;}

    /**
     * Returns the name of the person
     */
    public String getName(){return name;}

    /**
     * Returns a description of the person.
     */
    public String getDescription(){
	String des = "teaches "+ subject;
	return des;
    }

    // public String getSubject(){return subject;}
    // public static void main(String args[]){
    // Lecturer l1 = new Lecturer("Zaeem","quaidzaeem@gmail.com","biology");
    // System.out.println(l1.getDescription());
    // }
}
