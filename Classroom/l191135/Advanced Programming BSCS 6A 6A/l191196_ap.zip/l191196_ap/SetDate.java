import java.util.Date;
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.ZoneOffset;

public class SetDate{
    public static void setDate(String date, String time, String fileName) throws
IllegalArgumentException {
//your code here
	//System.out.println(date+time+fileName);
	String [] date_array = date.split("/");
	String [] time_array = time.split(":");
	//Date dt = new Date();

	// year, month, dayOfMonth, hour, minute, second
	LocalDateTime newLocalDateTime = LocalDateTime.of(
							  Integer.parseInt(date_array[2]),
							  Integer.parseInt(date_array[1]),
							  Integer.parseInt(date_array[0]),
							  Integer.parseInt(time_array[0]),
							  Integer.parseInt(time_array[1]),
							  Integer.parseInt(time_array[2]));
  
	// convert LocalDateTime to Instant
	Instant instant = newLocalDateTime.toInstant(ZoneOffset.UTC);

	// convert instant to filetime
	// update last modified time of a file
	File file = new File(fileName);
	file.setLastModified(instant.toEpochMilli());
    }
    public static void main(String[] argv){
	int argc = argv.length;
	if(argc < 3){
	    System.out.println("usage: java Setdate 1/7/2020 13:05:55 filename");
	    System.exit(1);
	}
	else{
	    try{
	    setDate(argv[0],argv[1],argv[2]);
	    System.out.println("last modified date has been changed...");
	    System.out.println("use stat fileName in linux shell to see");
	    }
	    catch(Exception e){
		System.out.println(e);		
	    }
	}
    }
}
