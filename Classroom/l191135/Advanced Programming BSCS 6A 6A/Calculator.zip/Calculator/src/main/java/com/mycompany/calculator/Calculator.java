package com.mycompany.calculator;

/**
 *
 * @author darkn
 */
public class Calculator extends SimpleCalculator {
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SimpleCalculator().setVisible(true);
            }
        });
    }   
}