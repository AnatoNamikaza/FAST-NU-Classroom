
/**
 *
 * @author Zaeem
 */
public class calculator extends javax.swing.JFrame {
        // Variables declaration - do not modify                     
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton12;
    private javax.swing.JButton jButton13;
    private javax.swing.JButton jButton14;
    private javax.swing.JButton jButton15;
    private javax.swing.JButton jButton16;
    private javax.swing.JButton jButton17;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton20;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton22;
    private javax.swing.JButton jButton23;
    private javax.swing.JButton jButton24;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration                   

    public calculator() {
        initComponents();
    }

    double num1, num2, result;
    String opr;
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jButton12 = new javax.swing.JButton();
        jButton13 = new javax.swing.JButton();
        jButton14 = new javax.swing.JButton();
        jButton15 = new javax.swing.JButton();
        jButton16 = new javax.swing.JButton();
        jButton17 = new javax.swing.JButton();
        jButton18 = new javax.swing.JButton();
        jButton19 = new javax.swing.JButton();
        jButton20 = new javax.swing.JButton();
        jButton21 = new javax.swing.JButton();
        jButton22 = new javax.swing.JButton();
        jButton23 = new javax.swing.JButton();
        jButton24 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Simple Calculator");
        setBackground(new java.awt.Color(51, 51, 255));
        setResizable(false);
        setType(java.awt.Window.Type.UTILITY);

        jTextField1.setBackground(new java.awt.Color(200, 200, 200));
        jTextField1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        jTextField1.setForeground(new java.awt.Color(255, 255, 255));
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextField1.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jTextField1ActTriggered(evt);
		}
	    });

        jButton1.setBackground(new java.awt.Color(200, 200, 200));
        jButton1.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton1.setText("X²");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton1ActTriggered(evt);
		}
	    });

        jButton2.setBackground(new java.awt.Color(200, 200, 200));
        jButton2.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton2.setText("√");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton2ActTriggered(evt);
		}
	    });

        jButton3.setBackground(new java.awt.Color(200, 200, 200));
        jButton3.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton3.setText("1/x");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton3ActTriggered(evt);
		}
	    });

        jButton4.setBackground(new java.awt.Color(200, 200, 200));
        jButton4.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton4.setText("%");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton4ActTriggered(evt);
		}
	    });

        jButton5.setBackground(new java.awt.Color(200, 200, 200));
        jButton5.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton5.setText("CE");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton5ActTriggered(evt);
		}
	    });

        jButton6.setBackground(new java.awt.Color(200, 200, 200));
        jButton6.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton6.setText("C");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton6ActTriggered(evt);
		}
	    });

        jButton7.setBackground(new java.awt.Color(200, 200, 200));
        jButton7.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton7.setText("B");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton7ActTriggered(evt);
		}
	    });

        jButton8.setBackground(new java.awt.Color(200, 200, 200));
        jButton8.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton8.setText("/");
        jButton8.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton8ActTriggered(evt);
		}
	    });

        jButton9.setBackground(new java.awt.Color(200, 200, 200));
        jButton9.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton9.setText("4");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton9ActTriggered(evt);
		}
	    });

        jButton10.setBackground(new java.awt.Color(200, 200, 200));
        jButton10.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton10.setText("5");
        jButton10.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton10ActTriggered(evt);
		}
	    });

        jButton11.setBackground(new java.awt.Color(200, 200, 200));
        jButton11.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton11.setText("6");
        jButton11.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton11ActTriggered(evt);
		}
	    });

        jButton12.setBackground(new java.awt.Color(200, 200, 200));
        jButton12.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton12.setText("-");
        jButton12.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton12ActTriggered(evt);
		}
	    });

        jButton13.setBackground(new java.awt.Color(200, 200, 200));
        jButton13.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton13.setText("9");
        jButton13.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton13ActTriggered(evt);
		}
	    });

        jButton14.setBackground(new java.awt.Color(200, 200, 200));
        jButton14.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton14.setText("8");
        jButton14.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton14ActTriggered(evt);
		}
	    });

        jButton15.setBackground(new java.awt.Color(200, 200, 200));
        jButton15.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton15.setText("*");
        jButton15.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton15ActTriggered(evt);
		}
	    });

        jButton16.setBackground(new java.awt.Color(200, 200, 200));
        jButton16.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton16.setText("7");
        jButton16.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton16ActTriggered(evt);
		}
	    });

        jButton17.setBackground(new java.awt.Color(200, 200, 200));
        jButton17.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton17.setText("1");
        jButton17.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton17ActTriggered(evt);
		}
	    });

        jButton18.setBackground(new java.awt.Color(200, 200, 200));
        jButton18.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton18.setText("2");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton18ActTriggered(evt);
		}
	    });

        jButton19.setBackground(new java.awt.Color(200, 200, 200));
        jButton19.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton19.setText("3");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton19ActTriggered(evt);
		}
	    });

        jButton20.setBackground(new java.awt.Color(200, 200, 200));
        jButton20.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton20.setText("+");
        jButton20.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton20ActTriggered(evt);
		}
	    });

        jButton21.setBackground(new java.awt.Color(200, 200, 200));
        jButton21.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton21.setText("=");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton21ActTriggered(evt);
		}
	    });

        jButton22.setBackground(new java.awt.Color(200, 200, 200));
        jButton22.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton22.setText(".");
        jButton22.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton22ActTriggered(evt);
		}
	    });

        jButton23.setBackground(new java.awt.Color(200, 200, 200));
        jButton23.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton23.setText("0");
        jButton23.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton23ActTriggered(evt);
		}
	    });

        jButton24.setBackground(new java.awt.Color(200, 200, 200));
        jButton24.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jButton24.setText("±");
        jButton24.addActionListener(new java.awt.event.ActionListener() {
		public void actionPerformed(java.awt.event.ActionEvent evt) {
		    jButton24ActTriggered(evt);
		}
	    });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
				  layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				  .addGroup(layout.createSequentialGroup()
					    .addContainerGap()
					    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
						      .addComponent(jTextField1)
						      .addGroup(layout.createSequentialGroup()
								.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
									  .addGroup(layout.createSequentialGroup()
										    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
											      .addGroup(layout.createSequentialGroup()
													.addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
													.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
													.addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
											      .addGroup(layout.createSequentialGroup()
													.addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
													.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
													.addComponent(jButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)))
										    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
											      .addComponent(jButton21, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
											      .addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)))
									  .addGroup(layout.createSequentialGroup()
										    .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
										    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
										    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
									  .addGroup(layout.createSequentialGroup()
										    .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
										    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										    .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
										    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										    .addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)))
								.addGap(18, 18, 18)
								.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
									  .addGroup(layout.createSequentialGroup()
										    .addComponent(jButton24, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
										    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										    .addComponent(jButton23, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
										    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
										    .addComponent(jButton22, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
									  .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
										    .addGroup(layout.createSequentialGroup()
											      .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
											      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
											      .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
											      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
											      .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
										    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
											      .addGroup(layout.createSequentialGroup()
													.addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
													.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
													.addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
													.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
													.addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE))
											      .addGroup(layout.createSequentialGroup()
													.addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
													.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
													.addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
													.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
													.addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)))))))
					    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
				  );
        layout.setVerticalGroup(
				layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
					  .addGap(19, 19, 19)
					  .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
					  .addGap(18, 18, 18)
					  .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						    .addGroup(layout.createSequentialGroup()
							      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
									.addComponent(jButton7, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
									.addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
									.addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
							      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
							      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
									.addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
									.addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
									.addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
									.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										  .addComponent(jButton11, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
										  .addComponent(jButton10, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
										  .addComponent(jButton9, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)))
							      .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
							      .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
									.addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
									.addComponent(jButton15, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
									.addComponent(jButton12, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
									.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
										  .addComponent(jButton19, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
										  .addComponent(jButton18, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
										  .addComponent(jButton17, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))))
						    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
							      .addComponent(jButton13, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
							      .addComponent(jButton14, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
							      .addComponent(jButton16, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)))
					  .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
					  .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
						    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
							      .addComponent(jButton22, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
							      .addComponent(jButton23, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
							      .addComponent(jButton24, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
						    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
							      .addComponent(jButton21, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
							      .addComponent(jButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
							      .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)))
					  .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
				);

        pack();
    }// </editor-fold>                        

    private void jButton7ActTriggered(java.awt.event.ActionEvent evt) {                                         
        if (jTextField1.toString().length()!= 0)
	    {
		jTextField1.setText(jTextField1.getText().substring(0, jTextField1.getText().length()-1));
	    }
    }                                        

    private void jTextField1ActTriggered(java.awt.event.ActionEvent evt) {                                            
    }                                           

    private void jButton13ActTriggered(java.awt.event.ActionEvent evt) {                                          
        jTextField1.setText(jTextField1.getText() + "9");
    }                                         

    private void jButton6ActTriggered(java.awt.event.ActionEvent evt) {                                         
        jTextField1.setText("");
    }                                        

    private void jButton14ActTriggered(java.awt.event.ActionEvent evt) {                                          
        jTextField1.setText(jTextField1.getText() + "8");
    }                                         

    private void jButton16ActTriggered(java.awt.event.ActionEvent evt) {                                          
        jTextField1.setText(jTextField1.getText() + "7");
    }                                         

    private void jButton11ActTriggered(java.awt.event.ActionEvent evt) {                                          
        jTextField1.setText(jTextField1.getText() + "6");
    }                                         

    private void jButton10ActTriggered(java.awt.event.ActionEvent evt) {                                          
        jTextField1.setText(jTextField1.getText() + "5");
    }                                         

    private void jButton9ActTriggered(java.awt.event.ActionEvent evt) {                                         
        jTextField1.setText(jTextField1.getText() + "4");
    }                                        

    private void jButton19ActTriggered(java.awt.event.ActionEvent evt) {                                          
        jTextField1.setText(jTextField1.getText() + "3");
    }                                         

    private void jButton18ActTriggered(java.awt.event.ActionEvent evt) {                                          
        jTextField1.setText(jTextField1.getText() + "2");
    }                                         

    private void jButton17ActTriggered(java.awt.event.ActionEvent evt) {                                          
        jTextField1.setText(jTextField1.getText() + "1");
    }                                         

    private void jButton23ActTriggered(java.awt.event.ActionEvent evt) {                                          
        jTextField1.setText(jTextField1.getText() + "0");
    }                                         

    private void jButton22ActTriggered(java.awt.event.ActionEvent evt) {                                          
        jTextField1.setText(jTextField1.getText() + ".");
    }                                         

    private void jButton20ActTriggered(java.awt.event.ActionEvent evt) {                                          
        num1 = Double.parseDouble((jTextField1.getText()));
        jTextField1.setText("");
        opr = "+";
    }                                         

    private void jButton12ActTriggered(java.awt.event.ActionEvent evt) {                                          
        num1 = Double.parseDouble((jTextField1.getText()));
        jTextField1.setText("");
        opr = "-";
    }                                         

    private void jButton15ActTriggered(java.awt.event.ActionEvent evt) {                                          
        num1 = Double.parseDouble((jTextField1.getText()));
        jTextField1.setText("");
        opr = "*";
    }                                         

    private void jButton8ActTriggered(java.awt.event.ActionEvent evt) {                                         
        num1 = Double.parseDouble((jTextField1.getText()));
        jTextField1.setText("");
        opr = "/";
    }                                        

    private void jButton4ActTriggered(java.awt.event.ActionEvent evt) {                                         
        num1 = Double.parseDouble((jTextField1.getText()));
        jTextField1.setText("");
        opr = "%";
    }                                        

    private void jButton2ActTriggered(java.awt.event.ActionEvent evt) {                                         
        num1 = Double.parseDouble((jTextField1.getText()));
        jTextField1.setText(Double.toString(Math.sqrt(num1)));
    }                                        

    private void jButton1ActTriggered(java.awt.event.ActionEvent evt) {                                         
        num1 = Double.parseDouble((jTextField1.getText()));
        jTextField1.setText(Double.toString(num1*num1));
    }                                        

    private void jButton3ActTriggered(java.awt.event.ActionEvent evt) {                                         
        num1 = Double.parseDouble((jTextField1.getText()));
        jTextField1.setText(Double.toString(1/num1));
    }                                        

    private void jButton5ActTriggered(java.awt.event.ActionEvent evt) {                                         
        num1 = num2 = 0;
        jTextField1.setText("");
        opr = "";
    }                                        

    private void jButton21ActTriggered(java.awt.event.ActionEvent evt) {                                          
        result = num1;
        num2 = Double.parseDouble((jTextField1.getText()));
        
        if (opr == "+")
	    {
		result = num1 + num2;
	    }
        else if(opr == "-")
	    {
		result = num1 - num2;
	    }
        else if(opr == "*")
	    {
		result = num1 * num2;
	    }
        else if(opr == "/")
	    {
		result = num1 / num2;            
	    }
        else if(opr == "%")
	    {
		result = num1 % num2;
	    }
        
        jTextField1.setText(Double.toString(result));
    }                                         

    private void jButton24ActTriggered(java.awt.event.ActionEvent evt) {                                          
        jTextField1.setText(Double.toString(-1*(Double.parseDouble(jTextField1.getText()))));
    }                                         
    
}
