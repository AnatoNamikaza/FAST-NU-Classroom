#ifndef _HASH_H
#define _HASH_H
#include<bits/stdc++.h> 
using namespace std; 

class HashNode 
{ 
public:
  string var_type; // int, float, etc
  string var_name; // x,y etc
  string var_value; // 20,20.5
  string mode; // const etc
  
  HashNode(string _mode,string _type, string _name, string _value) 
  {
    mode = _mode;
    var_type = _type;
    var_name = _name;
    var_value = _value;
  } 
}; 

class HashMap 
{ 
  HashNode **arr; 
  int capacity; 
  int size; 
  HashNode *dummy; 
public: 
  HashMap(int _capacity) 
  { 
    capacity = _capacity; 
    size=0; 
    arr = new HashNode *[capacity]; 
    for(int i=0 ; i < capacity ; i++) 
      arr[i] = NULL; 
    dummy = new HashNode("","","",""); 
  } 
  int hashCode(string _var) 
  {
    // sum of ascii code of string 
    int key =0;
    for(int i=0; i< _var.length(); i++){
      key = key + _var[i];
    }
    return key % capacity; 
  } 	
  void insertNode(string _mode,string _type, string _name, string _value)
  { 
    HashNode *temp = new HashNode(_mode,_type,  _name,  _value); 
    int hashIndex = hashCode(_name); 
		
    //cout << "HashIndex=" << hashIndex << endl;
	
    int probe_counter=1;
    while(arr[hashIndex] != NULL && (arr[hashIndex]->var_name != _name 
				     || arr[hashIndex]->var_name != "")) 
      {   
	hashIndex += probe_counter*probe_counter;
	probe_counter++;            
	hashIndex %= capacity;          
      } 
		
    if(arr[hashIndex] == NULL || arr[hashIndex]->var_name == "") {
      size++;
        
    }
      
    arr[hashIndex] = temp; 
  } 

  string deleteNode(string _name) 
  { 
    int hashIndex = hashCode(_name); 
    int probe_counter = 1;
    while(arr[hashIndex] != NULL) 
      { 
	if(arr[hashIndex]->var_name == _name) 
	  { 
	    HashNode*temp = arr[hashIndex]; 
				
	    arr[hashIndex] = dummy; 
				
	    size--; 
	    return temp->var_value; 
	  } 
	//hashIndex++;
	hashIndex += probe_counter*probe_counter;
	probe_counter++;
	hashIndex %= capacity; 
      } 
		
    //cout << "Key not found";	
    return 0; 
  } 

  bool set_var_value(string _name,string _value){
    int hashIndex = hashCode(_name); //name of variable
    int counter=0;
    int probe_counter = 1;
    while(arr[hashIndex] != NULL) 
      { 
	  
	if(arr[hashIndex]->var_name == _name){
	  if(arr[hashIndex]->mode != "const"){
	  arr[hashIndex]->var_value = _value;
	  return true;
	  }
	  else{
	    return false;
	  }
	}
	hashIndex += probe_counter*probe_counter;
	probe_counter++;
	hashIndex %= capacity; 
      } 

  }
  string get(string _name) 
  { 
    int hashIndex = hashCode(_name); //name of variable
        int counter=0;
    int probe_counter = 1;
    while(arr[hashIndex] != NULL) 
      { 
	  
	if(arr[hashIndex]->var_name == _name) 
	  return arr[hashIndex]->var_value; 
	//hashIndex++;
	hashIndex += probe_counter*probe_counter;
	probe_counter++;
	hashIndex %= capacity; 
      } 
		
    return ""; 
  } 
	
  int sizeofMap() 
  { 
    return size; 
  } 
	
  bool isEmpty() 
  { 
    return size == 0; 
  } 
	
  void display() 
  { 
    for(int i=0 ; i<capacity ; i++) 
      { 
	if(arr[i] != NULL && arr[i]->var_name != "") 
	  cout << "key = " << arr[i]->var_name 
	       <<" value = "<< arr[i]->var_value << endl; 
      } 
  } 
};

#endif

// int main() 
// { 
//   HashMap *h = new HashMap(20); 
//   h->insertNode("const","int","what","20");
//   h->insertNode("const","float","are","21.5");
//   h->insertNode("const","int","you","22");
//   h->display(); 
    
//   cout<< h->sizeofMap() <<endl;
	
//   cout << h->deleteNode("you") << endl;
//   cout << h->sizeofMap() <<endl;
//   cout << h->sizeofMap() <<endl;
//   cout << h->set_var_value("are","29") << "-----------\n";
//   h->display();
//   cout << h->isEmpty() << endl;


//   return 0; 
// } 
