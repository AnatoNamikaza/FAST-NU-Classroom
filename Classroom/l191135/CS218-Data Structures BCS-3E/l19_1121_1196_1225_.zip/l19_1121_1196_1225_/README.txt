Compile program on linux:
Requirement:
	1): g++
	2): ncurses liberary installed
	3):  make tool or copy pate command from Mafefile
	
Compile program on Windows:
	1): MinGW
	2): ncurses liberary (not sure how to install)
	3): g++ -std=c++11 main.cpp -o main.exe -lncurses

===============================key board
Functionality:
	1): LEFT ARROW moves cursor left in doubly linklist
	2): RIGHT ARROW moves cursor right in doubly linklist
	3): ARROW UP and ARROW DOWN travers the history
	4): user input is always taken in doubly linklist
	
=============================== commands 
run main and new window will pop up
c++> help()
c++> 2+3*(1+2)
11
c++> clear() // clears the screen
c++> int x;
declaration // hashtable will contain x
c++> int x=10;
initialization
c++> x=20 // value of x will be updated in hashtable node
assignment
c++> exit() // exits the screen
