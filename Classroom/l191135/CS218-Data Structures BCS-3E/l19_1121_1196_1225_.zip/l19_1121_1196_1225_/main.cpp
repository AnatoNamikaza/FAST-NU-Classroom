// make; gnome-terminal -x make run
#include <iostream>
#include <string>
#include "containers.h" //self written data structures
#include <curses.h>
#include "calculator.h"
#include "hash.h" // quadratic probing
#include <ctype.h> // isalpha
// #include "./cparse/builtin-features.inc"

#define EXIT "exit()"
#define PROMPT "c++> "
#define CLEAR "clear()"
#define HELP "help()"
string datatypes[] = {"int","float","char"};
int ntypes=3;

void clear_buffer(char *array,int size);
void copy(char *array, string str);
string parser(string command);
bool substitution(string result, string command, HashMap _symbolTable);
void removeEmpty(string &token);
bool isType(string _type,int size);
string help();

using namespace std;
int main(){
  initscr();
  cbreak();
  keypad(stdscr,true);
  noecho();
  
  int ch; // for user input
  string command;
  bool insert = false; // left and right arrow sets it true
  int line,col; // for cursor movement
  int prev_line,prev_col; // for cursor movement
  char buffer[1000];
  char his_buffer[100]; // last 100 commands history buffer
  int cursor_movement =0; // left arrow: -- right arrow ++
  char empty_buffer[100];
  HashMap symbolTable(100); // 100 symbols can be saved
  
  DoublyLinkList<string> *history = new DoublyLinkList<string>();
  Node<string> *his_cursor = NULL;

  do{
    printw(PROMPT);
    refresh();
    DoublyLinkList<char> *l1 = new DoublyLinkList<char>();
    Node<char> *cursor = NULL;
    do{
      ch = getch();
      if(ch >=32 && ch <= 126){
	if(insert){
	  clear_buffer(empty_buffer,l1->getLength());
	  mvprintw(line,5,empty_buffer);	
	  //printw("%c",ch);
	  l1->insertAfterNode(cursor,ch); // cursor will be updated automatically
	  l1->intoArray(buffer);
	  mvprintw(line,5,buffer);
	  move(line,l1->getLength()+cursor_movement+5);
	  //cout << cursor_movement << endl;
	  refresh();
	}
	else{
	  printw("%c",ch);
	  l1->insertAfterNode(cursor,ch); // cursor will be updated automatically
	}
      }
      else if(ch == '\n'){
	insert = false;
	cursor_movement = 0;
	getyx(stdscr,line,col);
	if(line == LINES-1) clear();
	// if lines have reached till end then come back to first line
	if(! l1->isEmpty()){
	  // if line is non empty
	  printw("\n");

	  l1->intoArray(buffer);
	  command = string(buffer); // will be used for parsing
	  if(parser(command) == "evaluation" && command != HELP){
	    string result;
	    //substitution(result, command,symbolTable);
	    //command = result;
	    result = evaluate(command);
	    copy(buffer,result);
	    printw(buffer);
	    refresh();
	  }
	  else if(parser(command) == "assignment"){
	    string result = "assignment";
	    copy(buffer,result);
	    printw(buffer);
	    refresh();
	    }
	    else if(parser(command) == "initialization"){
	    string result = "initialization";
	    copy(buffer,result);
	    printw(buffer);
	    refresh();

	    }
	    else if(parser(command) == "declaration"){
	    string result = "declaration";
	    //insertSymbol(command,symbolsTable);
	    copy(buffer,result);
	    printw(buffer);
	    refresh();
	    }

	  //evaluate(ifix_to_pfix(command));
	  //string result = evaluate(command);
	  //copy(buffer,result);
	  //printw(buffer);	  
	  //refresh();
	}
	printw("\n"); // otherwise line is empty
      }
      else if(ch == KEY_BACKSPACE){
	// backspace
	if(!l1->isEmpty()){
	  if(insert){
	    // if there is cursor movement detected
	    clear_buffer(empty_buffer,l1->getLength());
	    mvprintw(line,5,empty_buffer);
	    //printw("%c",ch);
	    l1->deleteUnderCursor(cursor); // cursor will be updated automatically
	    l1->intoArray(buffer);
	    mvprintw(line,5,buffer);
	    move(line,l1->getLength()+cursor_movement+5);
	    //cout << cursor_movement << endl;
	    refresh();

	  }
	  else{
	    int line,col;
	    getyx(stdscr,line,col);
	    clear_buffer(empty_buffer,col-1);
	    mvprintw(line,col-1,empty_buffer);
	    mvprintw(line,col-1," "); // come back and overwrite space
	    move(line,col-1); /// set cursor
	    //buffer[--buffer_index] = '\0';
	    l1->deleteUnderCursor(cursor);
	  }
	}
      }

      else if(ch == KEY_LEFT){
	//cout << "left key\n";
	if(cursor != NULL && cursor->prev !=NULL){
	  
	  getyx(stdscr,line,col);
	  move(line,col-1); /// set cursor
	  l1->moveCursorLeft(cursor);
	  insert = true;
	  cursor_movement--;
	}
      }


      else if(ch == KEY_RIGHT){
	if(cursor != NULL && cursor->next != NULL){
	  getyx(stdscr,line,col);
	  move(line,col+1); /// set cursor
	  
	  //cout << "right key\n";
	  l1->moveCursorRight(cursor);
	  insert = true;
	  cursor_movement++;
	}
      }

      else if(ch == KEY_UP){
	if(!history->isEmpty()){
	  clear_buffer(empty_buffer,l1->getLength());
	  delete l1; // clear l1	  
	  DoublyLinkList<char> *l1 = new DoublyLinkList<char>();
	  cursor = NULL;
	  int len = his_cursor->data.length();
	  for(int i=0; i< len; i++){

	    l1->insertAfterNode(cursor,his_cursor->data[i]);
	  }
	  mvprintw(line+2,5,empty_buffer);
	  l1->intoArray(buffer);
	  mvprintw(line+2,5,buffer);
	  refresh();
	  history->moveCursorLeft(his_cursor);
	
	}
	//cout << calculator::calculate("2**3-2+3*9-2*(1-2*3)");
      }

      else if(ch == KEY_DOWN){
	if(his_cursor != NULL && his_cursor->next != NULL){
	  clear_buffer(empty_buffer,l1->getLength());
	  delete l1; // clear l1	  
	  DoublyLinkList<char> *l1 = new DoublyLinkList<char>();
	  cursor = NULL;
	  int len = his_cursor->data.length();
	  for(int i=0; i< len; i++){
	    l1->insertAfterNode(cursor,his_cursor->data[i]);
	  }
	  mvprintw(line+2,5,empty_buffer);
	  l1->intoArray(buffer);
	  mvprintw(line+2,5,buffer);
	  refresh();

	  history->moveCursorRight(his_cursor);
	}
      }
    }
    while(ch != '\n');
    if(command == CLEAR) clear();
    else if(command == HELP) {
      copy(buffer,help());
      printw(buffer);
      refresh();
    }
    // else if(parser(command) == "evaluation"){
    //   string result = evaluate(command);
    //   copy(buffer,result);
    //   printw(buffer);
    //   refresh();
    // }
    
    history->insertAfterNode(his_cursor,command);
  }
  while(command != EXIT);
  endwin();
}

//-----------------------------------------
void clear_buffer(char *array,int size){
  for(int i=0; i< size; i++) array[i] = ' ';
  array[size] = '\0';
}

void copy(char *array, string str){
  for(int i=0; i< str.length(); i++) array[i] = str[i];
  array[str.length()] = '\0';
}

string help(){
  string help_command;
  help_command = help_command + string("help() for help\n");
  help_command = help_command + string("exit() for exit\n");
  help_command = help_command + string("toPostFix(exp) infix to postfix \n");
  help_command = help_command + string("clear() clears the screen \n");
  help_command = help_command + string("var() prints the value if defined \n");
  return help_command;
}

string parser(string s){
  string token_list[4];
  int size;
  string os = s; // original s
  // size of token
  size=0;
  string delimiter = "=";
  size_t pos = 0;
  string token;
  while ((pos = s.find(delimiter)) != string::npos) {
    token = s.substr(0, pos);
    //cout << token << endl;
    token_list[size++] = (token);
    s.erase(0, pos + delimiter.length());
  }
  //cout << s << endl;
  token_list[size++] = (s);
if(size == 1){
  // no no assignment and not initialization
  // size of token
  s = token_list[0]; // because there was only one token
  int size=0;
  string delimiter = " ";
  size_t pos = 0;
  string token;
  while ((pos = s.find(delimiter)) != string::npos) {
    token = s.substr(0, pos);
    //cout << token << endl;
    
    token_list[size++] = (token);
    s.erase(0, pos + delimiter.length());
  }
  token_list[size++] = (s);
  // if first token is type and second is var
  // then it is declaration
  //cout << token_list[1] << "------";
  //if(token_list[0] == "int" && isalpha(token_list[1][0])){
  if(isType(token_list[0],ntypes) && isalpha(token_list[1][0])){
    size=0;
    string delimiter = " ";
    size_t pos = 0;
    string token;
    while ((pos = os.find(delimiter)) != string::npos) {
    token = os.substr(0, pos);
    //cout << token << endl;
    token_list[size++] = (token);
    os.erase(0, pos + delimiter.length());
  }
  //cout << s << endl;
    token_list[size++] = (os);
    
    return "declaration";
  }
 else{
    return "evaluation";
  }
  
 }
 else if(size == 2){
   //   there may be assignment or initialization
   s = token_list[0]; // because there was only one token

   size=0;
  string delimiter = " ";
  size_t pos = 0;
  string token;

  while ((pos = s.find(delimiter)) != string::npos) {
    token = s.substr(0, pos);
    //cout << toeken << endl;
    if(token != " ")
      token_list[size++] = (token);
    s.erase(0, pos + delimiter.length());
  }
  if(s != " ")
    token_list[size++] = (s);
   //if first token is type and second is var
   //then it is declaration
   if(size == 2){
     //if(token_list[0] == "int" && isalpha(token_list[1][0])){
     if(isType(token_list[0],ntypes) && isalpha(token_list[1][0])){
       return "initialization";
     }
   }
   else if(size == 1){
     return "assignment";
   }
   
 }
}

string removeEmpty(string token){
  char new_token[token.length()];
  int n_i=0;
  for(int i=0; i<token.length(); i++){
    if(token[i] != ' ') new_token[n_i++] = token[i];
  }
  string final_token;
  for(int i=0; i < n_i; i++){
    final_token=final_token+(new_token[i]);
  }

  //token = final_token;
  return final_token;
}

bool substitution(string result,string command, HashMap _symbolTable){
  string token="";
  for(int i=0; i< command.length(); i++){
    if(command[i] != ' ' && command[i] != '+'
       && command[i] != '-' && command[i] != '*'
       && command[i] != '/'){
    token = token+command[i];
    }
    else {
      if(token != ""){
      // search in hashtable and substitue its value
	if(_symbolTable.get(token) != ""){
	result = result + _symbolTable.get(token) + command[i];
	}
	else{
	  result = "";
	  return false;
	}
    }
    }
  }
  return true;
}

bool isType(string _type,int ntypes){
  for(int i=0; i < ntypes; i++){
    if(_type == datatypes[i]) return true;
  }
  return false;
}
