#ifndef _CONTAINERS_H
#define _CONTAINERS_H
#include <iostream>
using namespace std;

int bigger(int a, int b){
  if (a > b) return a;
  else return b;
}

template <typename TYPE> 
class sNode{
  // node for singly link list
public:
  TYPE data;
  sNode* next;

  sNode();
  sNode(int data);
  void print();
  ~sNode();
};
template <typename TYPE> 
class LinkList{
private:
  sNode<TYPE>* head;
  sNode<TYPE>* tail;
public:
  LinkList();
  void setHead(sNode<TYPE>*ptr);
  sNode<TYPE> * getHead();
  sNode<TYPE> * getTail();
  sNode<TYPE> * getNthsNode(int n); // returns nth node
  int getLength();
  void insertAtStart(TYPE const element);
  void insertAtEnd(TYPE const element);
  bool search(TYPE const& element) const;
  void insertAfter(TYPE const v1, TYPE const v2);
  void deleteFromFront();
  void deleteAtEnd();
  void deleteAllOccurrences(TYPE v1);
  void print() const;
  //------------------------------ miscellenous functions 
  ~LinkList();
};

template <typename TYPE>
class Stack{
protected:
  LinkList<TYPE>* stack;
public:
  Stack();
  void push(TYPE element);
  TYPE pop();
  TYPE peek();
  bool isEmpty();
  int getLength();
  ~Stack();
};

template <typename TYPE>
class Queue: public Stack<TYPE>{
  // Queue is almost stack with minor differnce
  // only functions will be overridden
public:
  Queue();
  TYPE pop();
  TYPE peek();
};

// //-------------------------------------
// template <typename TYPE>
// void reverseLinkList(LinkList<TYPE> & linked_list);
// //======================== end of prototype


// template <typename TYPE>
// void reverseLinkList(LinkList<TYPE> &linked_list){
//   // count the elements
//   // make a list of addresses of nodes in a linked list
//   // then point nodes to address in reverse orders
//   int total_nodes =0;
//   sNode<TYPE>* current_ptr = linked_list.getHead();
//   while(current_ptr != NULL) {
//     current_ptr = current_ptr->next;
//     total_nodes++;
//   }

//   // total nodes have been calculated
//   sNode<TYPE>**nodes = new sNode<TYPE>*[total_nodes];
//   //now copy addresses into array
//   current_ptr = linked_list.getHead(); // reset current ptr
//   for(int i=0; i< total_nodes; i++){
//     nodes[i] = current_ptr;
//     current_ptr = current_ptr->next;
//   }
//   for(int i=total_nodes-1; i > 0; i--){
//     nodes[i]->next = nodes[i-1];
//   };
//   nodes[0]->next = NULL;
//   linked_list.setHead(nodes[total_nodes-1]);
// }

//=================== BinaryTree
template <typename TYPE>
class TreesNode{
public:
  TYPE data;
  int height;
  TreesNode<TYPE>* lChild;
  TreesNode<TYPE>* rChild;
  TreesNode();
  TreesNode(TYPE data);
  void print();
  ~TreesNode(); // making base class polymorphic
};

template <typename TYPE>
class BinaryTree: public TreesNode<TYPE>{
protected:
  TreesNode<TYPE>* root;
  void inorder(TreesNode<TYPE>* root);
  TreesNode<TYPE>* preorder(TreesNode<TYPE>* root);
  void destroy_all_nodes(TreesNode<TYPE>* root);
public:
  BinaryTree();
  BinaryTree(TreesNode<TYPE>* root);
  TreesNode<TYPE>* getRoot();
  void setRoot(TreesNode<TYPE>*);
  void swap_children(TreesNode<TYPE>* parent);
  // will swap two child, left goes right and vice versa
  bool find(TYPE element);
  void insert(TYPE _data);
  void inorderPrint();
  ~BinaryTree();
};


//================== class sNode
template <typename TYPE>
sNode<TYPE>::sNode(){
  next = NULL;
}
//-------------------------------------
template <typename TYPE>
sNode<TYPE>::sNode(int data){
  this->data = data;
  this->next=NULL;
    
}
//-------------------------------------
template <typename TYPE>
void sNode<TYPE>::print(){
  cout << "data: " << data << endl;
  if(next !=NULL){
    cout << "next: " << next << endl;
  }
  else{
    cout << "next: " << endl;
  }
}
template <typename TYPE>
sNode<TYPE>::~sNode(){
}
//======================= class LinkList
template <typename TYPE>
LinkList<TYPE>::LinkList(){
  // make one node
  head = NULL;
  tail = NULL;

}

template <typename TYPE>
bool LinkList<TYPE>::search(TYPE const& v) const{
  sNode<TYPE>* current_ptr = head;
  bool found=false;
  while(current_ptr != NULL && found !=true){
    if(current_ptr->data == v) found=true;
    current_ptr = current_ptr->next;
  }
  return found;
}

template <typename TYPE>
void LinkList<TYPE>::setHead(sNode<TYPE> *ptr){
  head = ptr;
}

//----------------------------------------
template <typename TYPE>
sNode<TYPE> * LinkList<TYPE>::getHead(){
  return head;
}

template <typename TYPE>
sNode<TYPE> * LinkList<TYPE>::getTail(){
  return tail;
}

//----------------------------------------
template <typename TYPE>
sNode<TYPE> * LinkList<TYPE>::getNthsNode(int n){
  sNode<TYPE> * current = NULL;
  if(n > 0){
    current = head;
    int counter=1;
    while(current != NULL && counter < n){
      current = current->next;
      counter++;
    }
    return current;
  }
  else{
    return current;
  }
}

template <typename TYPE>
int LinkList<TYPE>::getLength(){
  if(head != NULL){
    int counter=0;
    // traverse the list
    sNode<TYPE>* current = head;
    while(current != NULL){
      current = current->next;
      counter++;
    }
    return counter;
  }
  else{return 0;}
}
//----------------------------------------
template <typename TYPE>
void LinkList<TYPE>::insertAtStart(TYPE const element){
  sNode<TYPE> *temp_node = new sNode<TYPE>();
  temp_node->data = element;
  temp_node->next = head;
  head = temp_node;
}

template <typename TYPE>
void LinkList<TYPE>::insertAtEnd(TYPE const element){
  sNode<TYPE>*temp_node = new sNode<TYPE>();
  temp_node->data = element;
  temp_node->next = NULL;
  if(head != NULL){
    // traverse the list
    sNode<TYPE>* current = head;
    while(current->next != NULL){
      current = current->next;
    }
    current->next = temp_node;
    tail = temp_node;
  }
  else{
    head = temp_node;
    tail = temp_node;
  }
}

template <typename TYPE>
void LinkList<TYPE>::deleteFromFront(){
  if(head != NULL){
    sNode<TYPE>* toBeDeleted = head;
    head = head->next;
    delete toBeDeleted;
    toBeDeleted = NULL;
  }
}

template <typename TYPE>
void LinkList<TYPE>::deleteAtEnd(){
  if(head == NULL){
    // do nothing
  }
  else if(head->next == NULL){
    // only one node
    delete head;
    head = NULL;
    tail = NULL;
  }
  else{
    sNode<TYPE>* toBeDeleted = head;
    sNode<TYPE>* previous_node;
    while(toBeDeleted->next !=NULL){
      previous_node = toBeDeleted;
      toBeDeleted = toBeDeleted->next;
    }
    delete toBeDeleted;
    previous_node->next = NULL;
    tail = previous_node;
  }
}

template <typename TYPE>
void LinkList<TYPE>::print() const{
  sNode<TYPE>* current_ptr = head;
  while(current_ptr != NULL){
    cout << current_ptr->data << "->";
    current_ptr= current_ptr->next;
  }
  cout << endl;
}

template <typename TYPE>
LinkList<TYPE>::~LinkList(){
  sNode<TYPE>* current_ptr = head;
  sNode<TYPE>* temp_ptr;
  while(current_ptr != NULL){
    temp_ptr = current_ptr->next;
    delete current_ptr;
    current_ptr= temp_ptr;
  }
}
//======================= class Stack
template <class TYPE>
Stack<TYPE>::Stack(){
  stack = NULL;
  stack = new LinkList<TYPE>();
}

template <class TYPE>
void Stack<TYPE>::push(TYPE element){
  stack->insertAtEnd(element);
}

template <class TYPE>
TYPE Stack<TYPE>::pop(){
  if(!isEmpty()){
    TYPE value = peek();
    stack->deleteAtEnd();
    return value;
  }
}

template <class TYPE>
bool Stack<TYPE>::isEmpty(){
  if(stack->getHead()){
    return false;
  }
  else {return true;}
}
template <class TYPE>
TYPE Stack<TYPE>::peek(){
  if(!isEmpty())
    return (stack->getTail())->data;
  else{
    cout << "\nerror: stack underflow";
  }
}

template <class TYPE>
int Stack<TYPE>::getLength(){
  return stack->getLength();
}
template <class TYPE>
Stack<TYPE>::~Stack(){
  while(stack->getHead()) stack->deleteAtEnd();
}
//-------------------------------------

template <class TYPE>
Queue<TYPE>::Queue(): Stack<TYPE>(){}


template <class TYPE>
TYPE Queue<TYPE>::pop(){
  if(! Stack<TYPE>::isEmpty()){
    TYPE value = peek();
    Stack<TYPE>::stack->deleteFromFront();
    return value;
  }
}

template <class TYPE>
TYPE Queue<TYPE>::peek(){
  if(! Stack<TYPE>::isEmpty())
    return (Stack<TYPE>::stack->getHead())->data;
  else{
    cout << "\nerror: stack underflow";
  }
}
//===================== class TreesNode
template <typename TYPE>
TreesNode<TYPE>::TreesNode(){
  height=0;
  lChild = NULL;
  rChild = NULL;
}
template <typename TYPE>
TreesNode<TYPE>::TreesNode(TYPE data){
  height=0;
  this->data = data;
  lChild = NULL;
  rChild = NULL;
}

template <class TYPE>
int get_height(TreesNode<TYPE>* node){
  if(node != NULL){
    return 1 + bigger(get_height(node->lChild), get_height(node->rChild)); 
  }
  else return 0;
}

template <typename TYPE>
void TreesNode<TYPE>::print(){
  // will be helpful as polymorphic
  cout << data << "->";
}

template <typename TYPE>
TreesNode<TYPE>::~TreesNode(){
  // nothing to do
}
//================== class BinaryTree
template <class TYPE>
BinaryTree<TYPE>::BinaryTree(){
  root = NULL;
}

template <class TYPE>
BinaryTree<TYPE>::BinaryTree(TreesNode<TYPE>* _root){
  root = _root;
}

template <class TYPE>
TreesNode<TYPE>* BinaryTree<TYPE>::getRoot(){
  return root;
}
template <class TYPE>
void BinaryTree<TYPE>::setRoot(TreesNode<TYPE>* _root){
  root = _root;
}

template <class TYPE>
void swap_children(TreesNode<TYPE>* parent){
  
  if(parent->lChild != NULL || parent->rChild != NULL){
    // has at least one child
    TreesNode<TYPE>* temp = parent->lChild;
    parent->lChild = parent->rChild;
    parent->rChild = temp;
  }
  // else no need to swap null child
}

template <class TYPE>
void BinaryTree<TYPE>::insert(TYPE element){
  TreesNode<TYPE> *node= new TreesNode<TYPE>();
  node->data = element;
  node->lChild = NULL;
  node->rChild = NULL;
  
  if(root == NULL){
    root = node;
  }
  else{
    TreesNode<TYPE> *node_index = root;
    TreesNode<TYPE> *leaf_node = root;
    while(node_index != NULL){
      
      if(element > node_index->data){
	// follow right
	//cout << "following right \n";
	leaf_node = node_index;
	node_index = node_index->rChild;
      }
      else{
	// follow left
	//cout << "following left\n";
	leaf_node = node_index;
	node_index = node_index->lChild;
      }
    }
    //insert node_index here
    if(element > leaf_node->data){
      leaf_node->rChild = node;
      //cout << "added node on right...\n";
    }
    else{
      //cout << "added node on left...\n";
      leaf_node->lChild = node;
    }    
  }
}

template <typename TYPE>
bool BinaryTree<TYPE>::find(TYPE element){
  TreesNode<TYPE>* node_index = root;
  while(node_index != NULL){
    int node_value = node_index->data;
    if(element == node_value){
      return true;
    }
    else if(element > node_value){
      // follow right
      node_index = node_index->rChild;
    }
    else{
      // follow left
      node_index = node_index->lChild;
    }
  }
  return false;
}

template <class TYPE>
void BinaryTree<TYPE>::inorder(TreesNode<TYPE> *root_ptr){
  if(root_ptr == NULL){
    return;
  }
  else{
    //cout << "before lChild" << endl;
    inorder(root_ptr->lChild);
    cout << root_ptr->data << " ";
    //cout << root_ptr->data << " :" << root_ptr->height << endl;
    //cout << "balance factor: " << root_ptr->balance << endl;
    inorder(root_ptr->rChild);
    //cout << "after rChild" << endl;
    //cout <<  "going to traverse right " << root_ptr << endl;
  }
  //cout << "total diameter: " << left+right << endl;
}
//---------------------
template <class TYPE>
void BinaryTree<TYPE>::inorderPrint(){
  if(root !=NULL)
    inorder(root);
}

template <class TYPE>
void BinaryTree<TYPE>::destroy_all_nodes(TreesNode<TYPE> *root){
  if(root == NULL){
    return;
  }
  destroy_all_nodes(root->lChild);
  destroy_all_nodes(root->rChild);
  //cout << "deleting " << root->data->get_roll_no() << endl;
  delete root;
}

template <class TYPE>
BinaryTree<TYPE>::~BinaryTree(){
  // just a wrapper function to be called itself
  if(root != NULL){
    destroy_all_nodes(root);
  }
  //cout << "All nodes destroyed successully";
}
//===================== doubly link list

template <class TYPE>
class Node{
public:
  TYPE data;
  Node* next;
  Node* prev;

  Node();
  Node(TYPE data);
  ~Node();
};

template <class TYPE> 
Node<TYPE>::Node(){
  next=NULL;
  prev=NULL;
}

template <class TYPE> 
Node<TYPE>::Node(TYPE data){
  this->data = data;
  this->next=NULL;
  this->prev = NULL;
}

template <class TYPE> 
Node<TYPE>::~Node(){
}

template <class TYPE>
class DoublyLinkList{
private:
  Node<TYPE>* head;
  Node<TYPE>* tail;
public:
  Node<TYPE>* cursor;
  DoublyLinkList();
  DoublyLinkList(TYPE const element);
  void setHead(Node<TYPE>* ptr);
  void setTail(Node<TYPE>* ptr);
  Node<TYPE>* getHead();
  Node<TYPE>* getTail();
  void insertAtStart(TYPE const element);
  void insertAtEnd(TYPE const element);
  void deleteAtStart();
  void deleteAtEnd();
  void print();
  void reverse();
  void removeDuplicates();
  bool insertBefore(TYPE const v1, TYPE const v2 );
  void deleteUnderCursor(Node<TYPE> *&cursor_node);
  void insertAfterNode(Node<TYPE> *&cursor_node,TYPE const element);
  void moveCursorLeft(Node<TYPE> *&cursor_node);
  void moveCursorRight(Node<TYPE> *&cursor_node);
  void intoArray(TYPE *array);
  bool isEmpty();
  int getLength();
  //--------------------------------
  DoublyLinkList<TYPE>*  concatenate(DoublyLinkList<TYPE>* list1,\
				     DoublyLinkList<TYPE>* list2);
  DoublyLinkList<TYPE>* concatenateOrdered(DoublyLinkList<TYPE>* list1,	\
					   DoublyLinkList<TYPE>* list2);

  DoublyLinkList<TYPE>* sumDoublyLinkList(TYPE num1, TYPE num2);
  DoublyLinkList<char>* sumDoublyLinkList(const char* num1, const char* num2);
  ~DoublyLinkList();
};

template <class TYPE>
DoublyLinkList<TYPE>::DoublyLinkList(){
  head = NULL;
  tail = NULL;
  cursor = NULL;
}

template <class TYPE>
DoublyLinkList<TYPE>::DoublyLinkList(TYPE const element){
  insertAtStart(element);
  cursor = NULL;
}

template <class TYPE>
void DoublyLinkList<TYPE>::setHead(Node<TYPE>* ptr){
  head = ptr;
}
template <class TYPE>
void DoublyLinkList<TYPE>::setTail(Node<TYPE>* ptr){
  tail = ptr;
}
template <class TYPE>
Node<TYPE>* DoublyLinkList<TYPE>::getHead(){
  return head;
}
template <class TYPE>
Node<TYPE>* DoublyLinkList<TYPE>::getTail(){
  return tail;
}

template <class TYPE>
void DoublyLinkList<TYPE>::insertAtStart(TYPE const element){
  Node<TYPE>* temp = new Node<TYPE>(element);
  temp->next = head;
  temp->prev = NULL;
  if(head != NULL){
    head->prev = temp;
  }
  head = temp;	// update head
  if(head->next == NULL) tail = head; // in case of zero or one element
}

template <class TYPE>
void DoublyLinkList<TYPE>::insertAtEnd(TYPE element){
  Node<TYPE>* temp = new Node<TYPE>(element);
  if(head != NULL){
    temp->next = NULL;
    tail->next = temp;
    temp->prev = tail;
    tail = temp; // update tail
  }
  else{
    head = temp;
    tail = temp;
  }
}

template <class TYPE>
void DoublyLinkList<TYPE>::insertAfterNode(Node<TYPE> *&cursor_node,TYPE const element){
  // inserts the value after given address
  if(cursor_node != NULL){
    if(cursor_node->next != NULL){
      // cursor is in between
      Node<TYPE> *new_node = new Node<TYPE>(element);
      Node<TYPE> *next_node = cursor_node->next;
      //---------inserting new_node
      new_node->next = cursor_node->next;
      cursor_node->next = new_node;
      new_node->prev = cursor_node;
      next_node->prev = new_node;
      cursor = new_node;
    }
    else{
      // it is at the end
      insertAtEnd(element);
      // cout << "adding at tail\n";
      cursor = tail;
    }
  }
  else{
    // insert at start
    insertAtStart(element);
    cursor = head;
  }
  cursor_node = cursor;
}

template <class TYPE>
void DoublyLinkList<TYPE>::moveCursorLeft(Node<TYPE> *&cursor_node){
  if(cursor != NULL){
    if(cursor->prev != NULL) cursor = cursor->prev;
    
  }
  cursor_node = cursor;
}

template <class TYPE>
void DoublyLinkList<TYPE>::moveCursorRight(Node<TYPE> *&cursor_node){
  if(cursor != NULL){
    if(cursor->next != NULL) cursor = cursor->next;
  }
  cursor_node = cursor;
}

template <class TYPE>
void DoublyLinkList<TYPE>::intoArray(TYPE *array){
    Node<TYPE>* current = head; // leave dummy at first
    int index=0;
    while(current!= NULL){
      array[index++] = current->data;
      current = current->next;
    }
  array[index] = '\0';
}

template <class TYPE>
bool DoublyLinkList<TYPE>::isEmpty(){
  if(head == NULL) return true;
  return false;
}

template <class TYPE>
int DoublyLinkList<TYPE>::getLength(){
  Node<TYPE>* current = head;
  int length = 0;
  while(current!= NULL){
    length++;
    current = current->next;
  }
  return length;
}

// template <class TYPE>
// void DoublyLinkList<TYPE>::insertBeforeNode(Node<TYPE> *cursor_node,TYPE const element){
//   // inserts the value before given address
//     if(cursor_node != NULL){
//     if(cursor_node->prev != NULL){
//       // cursor is in between
//       Node<TYPE> *new_node(element);
//       cursor_node = cursor_node->prev;
      
//     }
//     else{
//       // it is at the end
//       insertAtStart(element);
//     }
//   }

// }

template <class TYPE>
void DoublyLinkList<TYPE>::deleteUnderCursor(Node<TYPE> *&cursor_node){
  // deletes the value after given address
  // deletion is made from right to left
  if(head != NULL){
    // there is atleast one node
    if(head == tail){
      // there is one element
      deleteAtStart();
      cursor = NULL;
    }
    else{
      // there are more than one element
      if(cursor_node == tail) {
	deleteAtEnd();
	cursor = tail;
      }
      else if(cursor_node == head) {
	deleteAtStart();
	cursor  = head;
      }
      else{
	// node is between
	Node<TYPE> *prev_node = cursor_node->prev;
	Node<TYPE> *next_node = cursor_node->next;
	cursor_node->next = NULL;
	cursor_node->prev = NULL;
	next_node->prev = prev_node;
	prev_node->next = next_node;
	delete cursor_node;
	cursor = prev_node;
      }
    }
    
  }
  cursor_node = cursor;
}

// template <class TYPE>
// void DoublyLinkList<TYPE>::deleteBeforeNode(){
//   // deletes the value before given address
// }

template <class TYPE>
void DoublyLinkList<TYPE>::deleteAtStart(){
  if(head != NULL && head != tail){
    // more than one nodes
    head = head->next;
    head->prev->next=NULL;
    delete head->prev;
    head->prev = NULL;
  }
  else if(head != NULL && head == tail){
    // one node
    tail = NULL;
    delete head;
    head =NULL;
  }
}

template <class TYPE>
void DoublyLinkList<TYPE>::deleteAtEnd(){
  if(head != NULL && head != tail){
    // more than one nodes
    tail = tail->prev;
    tail->next->prev = NULL;
    delete tail->next;
    tail->next = NULL;
  }
  else if(head != NULL && head == tail){
    // one node
    tail = NULL;
    delete head;
    head = NULL;
  }
}

template <class TYPE>
void DoublyLinkList<TYPE>::print(){
  Node<TYPE>* current = head;
  while(current!= NULL){
    cout <<	current->data << " ";
    current = current->next;
  }
  cout << endl;
}

template <class TYPE>
void DoublyLinkList<TYPE>::reverse(){
  Node<TYPE>* current = tail;
  Node<TYPE>* previous_ptr;
  while(current != NULL ){
    previous_ptr = current->prev;
    current->prev = current->next;
    current->next = previous_ptr;
    current = current->next;
  }
  // now swapping head and tail
  Node<TYPE>* temp = head;
  head = tail;
  tail = temp;
}



template <class TYPE>
void DoublyLinkList<TYPE>::removeDuplicates(){
  Node<TYPE>* start = head;
  if(head != NULL ){
    // more than one node
    while(start->next != NULL){
      Node<TYPE>* current = start->next;
      while( current->next != NULL){
	if(current->data == start->data){
	  // duplicate found
	  current->prev->next = current->next;
	  current->next->prev = current->prev;
	  current->next = NULL;
	  current->prev = NULL;
	  delete current;
	  current = NULL;
	}
	current = current->next;
      }
      start = start->next;
    }
  }
}

template <class TYPE>
bool DoublyLinkList<TYPE>::insertBefore(TYPE const v1, TYPE const v2 ){
  if(head != NULL){
    Node<TYPE>* current = head;
    bool inserted = false;
    while(current->next != NULL && inserted == false){
      if(current->data == v2){
	// found
	Node<TYPE>* temp = new Node<TYPE>(v1);
	temp->next = current;
	temp->prev = current->prev;
	current->prev = temp;
	inserted = true;
	// if inserted at start then update head
	if(current == head ) head = temp;
	// if inserted at end then update tail
	else if(current ==tail) tail = temp;
      }
      current = current->next;
    }
  }
  else{return false;}
}

template <class TYPE>
DoublyLinkList<TYPE>::~DoublyLinkList(){
  Node<TYPE>* current = head;
  if(current != NULL){
    if(current != tail){
      // more than one elements
      current = current->next;
      delete current->prev;
      
    }
    else{
      delete head;
      head=NULL;
      tail =NULL;
    }
  }
}

#endif
