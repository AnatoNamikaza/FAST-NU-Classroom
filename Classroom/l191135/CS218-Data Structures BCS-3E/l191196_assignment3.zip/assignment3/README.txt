Author: Zaeem Yousaf
Assignment: Data Structures
Submitted To: Dr. Amna Khan

Files and their description
|------------------------+----------+--------------------------|
| Files                  | Question | Description              |
|------------------------+----------+--------------------------|
| q1.h                   | Q1       | solution of q1           |
| max_heap.h             | Q3       | priority Queue           |
| max_heap.cpp           | Q3       | definition of prototypes |
| q1_q3_main.cpp         | Q1 & Q3  | Test harness             |
| coalesced_hashing.h    | Q2       | Q2 implemented           |
| HashingLinearProbing.h | Q1       | Q1 is using hashtable    |
| q2_main.cpp            | Q2       | Test Harness             |
| q3.h                   | Q3       | solution of question 3   |
| README.txt             |          | Help                     |
|------------------------+----------+--------------------------|
| Total = 9              |          |                          |
|------------------------+----------+--------------------------|
