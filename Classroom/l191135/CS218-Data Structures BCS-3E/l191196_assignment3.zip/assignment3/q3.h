#include<string>
#include "max_heap.h"
using namespace std;

int occurance(string line, char c){
  int counter = 0;
  for(int i=0; i < line.length(); i++){
    if(line[i] == c) counter++;
  }
  return counter;
}

bool find_char(string line, char c){
  for(int i=0; i< line.length(); i++){
    if(line[i] == c) return true;
  }
  return false;
}

bool is_sep_possible(string line){
int n = line.length();
 string visited = "";
 MaxHeap heap;
 for(int i= 0; i < n; i++){
   if(!find_char(visited,line[i])){
     int occur = occurance(line,line[i]);
     visited = visited+line[i];
     //cout << line[i] << " " << occur << endl;
     HNode n1(occur,line[i]);
     heap.insert_node(n1);
     
   } 
   
 }
  string possible;
  HNode last(-1,'!');
  while(!heap.isEmpty()){
    HNode top = *heap.getMax();
    heap.deleteMax();
    possible = possible + top.character;

    if(last.freq > 0) heap.insert_node(last);
    top.freq = top.freq-1;

    last.freq = top.freq;
    last.character = top.character;    
  }

  if(possible.length() == line.length()){
     cout << "One possibility is: " << possible << endl;
  }
  else{
    cout << "NO\n"; 
  }
}
