#include "q1.h"
#include "q3.h"
#include "max_heap.h"
#include <string>
// #include <iostream>
// using namespace std;

template <typename TYPE>
void printArray(TYPE array,int size);
void test_q1();

int main(){
  cout << "testing Q1...\n";
  test_q1();
  cout << "testing Q3 ...\n";
  is_sep_possible("helloo");
  
}

//----------------
template <typename TYPE>
void printArray(TYPE array,int size){
  for(int i=0; i< size; i++)
    cout << array[i] << "\t";
cout << endl;
}
//---------------- test of q1
void test_q1(){
  int x_length =6;
  float x[] = {10.0,40.3,30.9,100.2,202.3,-20.9};
  int hash_keys_x[x_length]; // will hold keys
  toHashKeys<float>(x,x_length,hash_keys_x);
  cout << "Input: ";
  printArray(x,x_length);
  cout << "Output: ";
  printArray(hash_keys_x,x_length);
  cout << endl;
  int letters_length =6;
  char letters[] = {'A','Z','C','a','9','!'};
  int hash_keys_letters[letters_length]; //keys will be returned
  toHashKeys<char>(letters,letters_length, hash_keys_letters);
  cout << "Input: ";
  printArray(letters,letters_length);
  cout << "Output: ";
  printArray(hash_keys_letters,letters_length);
}
