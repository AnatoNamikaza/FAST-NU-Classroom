// Why I passed another int array by reference
// because character array cannot hold returned int keys
// it is hence more generic
#include <algorithm> // for sort
#include "HashingLinearProbing.cpp" // code was given by maa'm Amna khan for reuse

template <typename TYPE>
void toHashKeys(TYPE array[],int its_size,int key_list[]){
  //for(int i=0; i< its_size; i++) cout << array[i] << " ";
  TYPE copy_array[its_size];
  for(int i=0; i< its_size; i++){
    copy_array[i] = array[i];
    //cout << "copying \n";
  }

  sort(copy_array,copy_array+its_size);
  //for(int i=0; i< its_size; i++) cout << copy_array[i] << " ";
  HashMap<int, TYPE> h;
   for(int i=0; i< its_size; i++){
     h.insertNode(i,copy_array[i]); //key value
   }

   //h.display();
   for(int i=0; i< its_size; i++){
     key_list[i] = h.getKey(array[i]);
     // for conversion in same array
     // array[i] = ....
     //cout << h.getKey(array[i]) << endl;
   }
}
