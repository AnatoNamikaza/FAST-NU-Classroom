// q2
#include "coalesced_hashing.h"
#include <iostream>
using namespace std;
int main(){
  HashMap<int,int> h1;;
  h1.insertNode(20,20);
  h1.insertNode(26,26);
  h1.insertNode(30,30);
  h1.insertNode(23,23);
  h1.display();
  
}
