#include "max_heap.h"
#include <iostream>
using namespace std;
 
MaxHeap::MaxHeap(){
  // default constructor
  arr = new HNode[1];
  capacity = 1;
  totalItems =0;
  //cout << "defalut constructor\n";
}

MaxHeap::MaxHeap(int _capacity){
  arr = new HNode[_capacity];
  capacity = _capacity;
  totalItems =0;
  //cout << "parametrized called\n";
}
 
void MaxHeap::insert_node(HNode parent){
  if(totalItems < capacity){
    // there is space
    arr[totalItems] = parent;
    totalItems++;
  }
  else{
    // grow double and insert
    grow_double();
    arr[totalItems] = parent;
    totalItems++;
  }
  //cout << "index: " << totalItems << endl;
  adjust(totalItems,(totalItems)/2);
}

 
void MaxHeap::grow_double(){
  int new_capacity = capacity*2;
  HNode *new_arr = new HNode[new_capacity];
  for(int i=0; i< capacity; i++){
    // copy old array into new_array
    new_arr[i] = arr[i];
  }
  if(arr != NULL) delete []arr;
  arr = new_arr;
  capacity = new_capacity;  
}
 
void MaxHeap::adjust(int cindex,int pindex){
  if(pindex !=0 && arr[cindex-1].freq > arr[pindex-1].freq){    
    //cout << "adjusting ...\n";
    // HNode parent = arr[pindex];
    // HNode child = arr[pindex];

    HNode temp = arr[pindex-1];
    arr[pindex-1] = arr[cindex-1];
    arr[cindex-1] = temp;
    
    cindex = pindex;
    pindex = pindex/2;
    adjust(cindex,pindex);
  }
  return;
}
 
HNode* MaxHeap::getMax(){
  return &arr[0];
}
 
void MaxHeap::deleteMax(){  
  arr[0] = arr[totalItems-1];
  totalItems = totalItems-1;
  // now hepify
  for(int i=0; 2*i+2 <= totalItems; i++){
    int gc = arr[2*i+1].freq < arr[2*i+2].freq ? 2*i+1 : 2*i+2;
    if(arr[i].freq < arr[gc].freq){
      // if parent < greatest children then swap
      HNode temp = arr[i];
      arr[i] = arr[gc];
      arr[gc] = temp;
    }
  }
} 
 
bool MaxHeap::isEmpty()const{
  if(totalItems >0) return false;
  return true;
}

 
int MaxHeap::size(){
  return totalItems;
}

 
void MaxHeap::print(){
  for(int i=0; i < totalItems; i++){
    cout << arr[i].freq << ": " << arr[i].character << "\n";
  }
}
 
MaxHeap::~MaxHeap(){
  delete []arr;
  //cout << "heap destroyed...\n";
}
