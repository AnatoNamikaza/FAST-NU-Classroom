All the code have been thoroughly tested on vs code and terminal.

Its behaviour may vary on the hardware.

		Thank You :)