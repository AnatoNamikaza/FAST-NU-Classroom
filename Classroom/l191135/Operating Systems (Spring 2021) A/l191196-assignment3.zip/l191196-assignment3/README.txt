compile command 
g++ -pthread l191196_assignment3.cpp
./a.out matrix1.txt matrix2.txt ans.txt

