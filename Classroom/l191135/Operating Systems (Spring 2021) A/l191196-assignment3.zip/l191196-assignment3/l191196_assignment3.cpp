#include<iostream>
#include<sys/sysinfo.h>
#include<fstream>
#include<string>
#include <sstream>
#include<pthread.h>
using namespace std;

pthread_mutex_t mutex; // for mutex lock
void count_rows_cols(char *filename,int &rows, int &cols);
void readMatrix(char *filename, int **matrix, int rows, int cols);
int **makeMatrix(int rows, int cols);
void printMatrix(int **matrix, int rows, int cols);
void saveMatrix(char *filename, int **matrix, int rows, int cols);
void *multiplyMatrix(void* subMatrix); // might throw warning of return

int rows_first;
int rows_second;
int cols_first;
int cols_second;
int **matrix1;
int **matrix2;
int **ans;
	      
struct indices{
  int start;
  int end;
};
	      

int main(int argc, char* argv[]){
 

  count_rows_cols(argv[1],rows_first,cols_first);
  cout << rows_first << " " << cols_first << endl;
  count_rows_cols(argv[2],rows_second,cols_second);					
  cout << rows_second << " " << cols_second << endl;

  if(rows_first == cols_second){
    matrix1 = makeMatrix(rows_first,cols_first);
    matrix2 = makeMatrix(rows_second,cols_second);
    ans = makeMatrix(rows_first,rows_first);
      
    readMatrix(argv[1],matrix1,rows_first,cols_first);
    printMatrix(matrix1,rows_first,cols_first);
    cout << endl;
    readMatrix(argv[2],matrix2,rows_second,cols_second);
    printMatrix(matrix2,rows_second,cols_second);

    int no_of_cores=get_nprocs();
    // create new thread
    pthread_t* t=new pthread_t[no_of_cores];
        
    int enteries=rows_first*rows_first;
    
    int per_head=enteries/no_of_cores;

    int i=0;
    int start=0;
    int end=enteries*(0+1/no_of_cores)-1;
    indices* index=new indices[per_head+1];
    while(start<(enteries-1))
      {
	end=enteries*(i+1/no_of_cores)-1;

	index[i].start=start;
	index[i].end=end;
	pthread_create(&t[i], NULL, multiplyMatrix,&index[i]);
	
	start=end+1;
	i++;
      }    

    // wait for all threads to join    
    for(int k=0; k<no_of_cores; k++){
	pthread_join(t[k],NULL);
      }

    // display ans
    cout << endl;
    printMatrix(ans,rows_first,rows_first);
    saveMatrix(argv[3],ans,rows_first,rows_first);
    cout << "<<<ans is saved in " << argv[3] << " >>>";
    
  }									  
  									  
  else{
    cout << "rows of first should be equal to cols of second matrix\n"; 
  }									
  
  return 0;
}

void* multiplyMatrix(void* subMatrix){
  indices *index=(indices*) subMatrix;
  for(int i=index->start; i <= index->end; i++){ 
        
    int row = i / cols_second;
    int col = i % cols_second;
    int sum=0;
    
    for(int j=0;j<cols_first;j++){
	sum+=(matrix1[row][j])*(matrix2[j][col]);
      }
    ans[row][col]=sum;
  }
  return subMatrix;
}


void count_rows_cols(char *filename, int &rows, int &cols){
  rows=0;
  cols=0;
  
  string line;
  ifstream in(filename);
  getline(in,line);
  if(line.length() > 0){
    rows++;
    //count cols;
    istringstream iss(line);
    string next_int;
    while(iss){
      iss >> next_int;
      if(next_int != "\n"){
	cols++;
      }
    }
    cols = cols-1; // 
  }
  if(in.is_open()){
    while(!in.eof()){
      getline(in,line);
      //cout << line;
      if(line.length() > 0){	
	rows++;
      }
    }
  }
}

void readMatrix(char *filename, int **matrix, int rows, int cols){
  string line;
  ifstream in(filename);
  int row=0;
  if(in.is_open()){
    while(!in.eof()){
      getline(in,line);
      if(line.length() > 0){
	istringstream iss(line);
	string next_int;
	for(int i=0; i< cols; i++){
	  iss >> next_int;
	  int x = atoi(next_int.c_str());
	  //matrix[row][i] = x;
	  *(*(matrix+row)+i) = x;
	}
      }
      row++;
    }
  }
}

int **makeMatrix(int rows, int cols){
  int **matrix = new int *[rows];
  for(int i=0; i< rows; i++){
    matrix[i] = new int[cols];
  }
  return matrix;
}

void printMatrix(int **matrix, int rows, int cols){
  for(int i=0; i< rows; i++){
    for(int j=0; j< cols; j++){
      cout << matrix[i][j] << " ";
    }
    cout << endl;
  }
}

void saveMatrix(char *filename, int **matrix, int rows, int cols){
  ofstream out(filename);
  if(out.is_open()){
    for(int i=0; i< rows; i++){
    for(int j=0; j< cols; j++){
      out << matrix[i][j] << " ";
    }
    out << endl;
  }
  }
  

  out.close();
}
