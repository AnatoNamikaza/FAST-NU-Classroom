#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>

#define BARBAR_SLEEPING 2
#define BARBAR_BUSY 1
#define BARBAR_FREE 0

using namespace std;
class HairSaloon;
void *goToHairSaloon(void *);

class HairSaloon{
private:
  int seats; // seats for wating customers
  int empty_seats; // empty slots plus barbar seat
  int barbar_state; // 0: barbar free, 1: busy, 2: sleeping

  sem_t cutting_lock, arival_lock, barbar_free, mutex;
  
public:
  HairSaloon(int waiting_seats){
    seats = waiting_seats;
    empty_seats = seats+1; // all seats are empty_seats including the barbar chair

    sem_init(&cutting_lock,0,1); // barbar is ready to cut hair
    sem_init(&arival_lock,0,1); // customer is ready to get in
    sem_init(&mutex,0,1); // mutex lock
    sem_init(&barbar_free,0,0); // there is no one, barbar cannot cut hair
    barbar_state = 2;  // initially barbar is sleeping
  }

  void hair_cut(){
    // if barber is free then move customer to the seat
    if(barbar_state == BARBAR_BUSY){
      cout << "barber is busy in cutting ... \n";
    }
    else if(empty_seats > 0 && barbar_state == BARBAR_FREE){
      sem_wait(&mutex);
      cout << "barbar is ready for hair cut " << endl;
      sem_wait(&barbar_free);
      //sleep(1); // cutting takes time
      cout << "barbar has got free\n";
      sem_post(&barbar_free);
      sem_post(&mutex);

      // customer is leaving
    }
    else if(barbar_state == BARBAR_FREE && empty_seats >= seats ){
      // barbasr is sleeping
      barbar_state = 2;
      cout << "barbar is sleeping ...\n";
      sem_wait(&barbar_free);
    }

    leave_customer();
  }

  void wake_barber(){
    if(barbar_state == BARBAR_SLEEPING){
      // if barbar is sleeping then wake it up
      cout << "waking the barbar up \n";
      sem_post(&barbar_free);
      barbar_state = BARBAR_FREE;
    }
  
  }

  void sleep_barber(){
   if(empty_seats >= seats){
      // and let the barbar sleep      
      sem_wait(&mutex);            
      barbar_state = BARBAR_SLEEPING;
      cout << "no customer at shop \n";
      cout << "barbar has slept\n";
      sem_post(&barbar_free);
      
      // new customer can come after leaving of this customer
      sem_post(&arival_lock);
      sem_post(&mutex);
    } 
  }
  
  void add_customer(){
    if(empty_seats == 0) {cout << "no space, customer is leaving ...\n";}
    // if there is capacity customer comes in
    else if(empty_seats == 1){
      // last comer will lock the arival
      sem_wait(&mutex);
      empty_seats = empty_seats - 1;
      sem_wait(&arival_lock);
      sem_post(&mutex);      
    }
    else{
      sem_wait(&mutex);
      cout << "customer joined ... \n";
      empty_seats = empty_seats -1;
      wake_barber();
      sem_post(&mutex);
      //custormer has joined, hair cutting may start
      hair_cut();
    }
    
  }
  void leave_customer(){
      sem_wait(&mutex);
      cout << "customer left ... \n";
      empty_seats = empty_seats +1;
      cout << "empty seats " << empty_seats << endl;
      sem_post(&mutex);

      sleep_barber();
  }
};


HairSaloon saloon(20);
int n=200; // number of customers
int main(){

  pthread_t *customers = new pthread_t[n];
  for(int i=0; i< n; i++){
    pthread_create(&customers[i], NULL, &goToHairSaloon, NULL);
  }

  for(int i=0; i< n; i++){
    pthread_join(customers[i],NULL);    
  }

  return 0;
}

void *goToHairSaloon(void *){
  saloon.add_customer();
  return NULL;
}
