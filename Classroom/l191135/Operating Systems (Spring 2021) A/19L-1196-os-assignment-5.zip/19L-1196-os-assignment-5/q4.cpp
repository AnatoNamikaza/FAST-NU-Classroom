#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
using namespace std;
class Ladder;
void* move_up(void *);
void* move_down(void *);

class Ladder{
private:
  int state; // 0: free, 1: moving up, 2: moving down
  sem_t top_gate, bottom_gate, update_lock; // three semaphores
  int n_robots; // number of robots available on the ladder
public:
  Ladder(){
    state = 0; // initially ladder is empty
    sem_init(&top_gate,0,1); // top gate is open
    sem_init(&bottom_gate,0,1); // bottom gate is open
    sem_init(&update_lock,0,1); 
  }

  void climbe_up(){    
    // if someone coming down then wait
    if(state == 2){
      cout << "waiting to go up" << endl;
      sem_wait(&bottom_gate);
    }
    else if(state == 1){
      // someone already moving up which has locked top_gate
      // this robot will not not take care of lock of top_gate
      sem_wait(&update_lock);
      n_robots ++;
      sem_post(&update_lock);
      cout << "moving up..." << endl;
      //sleep(1); // moving up takes time
      cout << "reached the ladder up " << " state == 1 " << endl;
      
      sem_wait(&update_lock);
      //critical section
      n_robots --;
      if(n_robots <=0){
	sem_post(&top_gate);
	sem_post(&bottom_gate);
	state = 0;
      }
      sem_post(&update_lock);
    }
    else{
      // ladder is empty
      // this robot will lock top_gate first

      sem_wait(&update_lock);
      state = 1;
      sem_wait(&top_gate); // this gate was initially opened
      n_robots ++;
      sem_post(&update_lock);
      
      cout << "moving up..." << endl;
      //sleep(1); // moving up takes time
      cout << "reached the ladder up " << " else " << endl;

      sem_wait(&update_lock);
      //critical section
      n_robots--; // one robot has left the ladder
      if(n_robots <=0){
	sem_post(&top_gate);
	sem_post(&bottom_gate);
	state = 0;
      }
      sem_post(&update_lock);
    }
  }
  
  void climbe_down(){
    // if someone coming up then wait
    if(state == 1){
      cout << "waiting to move down" << endl;
      sem_wait(&top_gate);
    }
    else if(state == 2){
      // someone already moving down which has locked bottom_gate
      // this robot will not not take care of lock of bottom_gate
      sem_wait(&update_lock);
      n_robots++;
      sem_post(&update_lock);
      
      cout << "moving down..." << endl;
      //sleep(1); // moving down takes time
      cout << "reached the ladder down" << endl;

      sem_wait(&update_lock);
      //critical section
      n_robots--;
      if(n_robots <=0){
	sem_post(&top_gate);
	sem_post(&bottom_gate);
	state = 0;
      }
      sem_post(&update_lock);
    }
    else{
      // ladder is empty
      // this robot will lock bottom_gate first
      sem_wait(&update_lock);
      state = 1;
      sem_wait(&bottom_gate); // this gate was initially opened
      n_robots++;
      sem_post(&update_lock);
            
      cout << "moving down..." << endl;
      //sleep(1); // moving down takes time
      cout << "reached the ladder down" << endl;

      sem_wait(&update_lock);
      //critical section
      n_robots--;
      if(n_robots <=0){
	sem_post(&top_gate);
	sem_post(&bottom_gate);
	state = 0;
      }
      sem_post(&update_lock);
    }
  }
};

Ladder long_ladder;
int n=9; // number of robots

int main(){
  pthread_t *threads = new pthread_t[n];
  for(int i=0; i< n; i++){
    if(i%2 == 0){
      // move the robot randomly up
      pthread_create(&threads[i],NULL,&move_up,NULL);
      cout << i << " ";
    }
    else{
      // move the robot randomly down
      pthread_create(&threads[i],NULL,&move_down,NULL);
      cout << i << " ";
    }
  }
  
  cout << "-----------\n";
  for(int i=0; i< n; i++){
    pthread_join(threads[i],NULL);
    cout << i+1 << " is leaving...\n";
  }
  
  return 0;
}

void* move_up(void *){
  long_ladder.climbe_up();
  return NULL;
}
void* move_down(void *){
  long_ladder.climbe_down();
  return NULL;
}
