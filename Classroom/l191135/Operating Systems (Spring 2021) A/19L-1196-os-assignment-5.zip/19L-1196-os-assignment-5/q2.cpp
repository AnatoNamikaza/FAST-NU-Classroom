#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
using namespace std;
/* 
wrong solution
explanation: all threads will wait just before 'doSomeThing' until last threads wchich will flip open the lock. Then only one thread will perform 'doSomething' and others will remain trapped

to correct, each thread will post just after 'doSomething'
*/


int n = 5;
int count = 0;

sem_t mutex;
sem_t barrier;
void* foo(void *){
  
  sem_wait(&mutex);
  count = count + 1;  
  sem_post(&mutex);
  
  if (count == n)
    sem_post(&barrier);

  pthread_t self = pthread_self();
  cout << "waiting thread  " << self << endl;
  sem_wait(&barrier);
  //doSomeThing();
  sleep(1); // just for creating illusion of 'doingSomething'
  cout << "I am executed by " << self << endl;
  sem_post(&barrier); // additional line for correct solution

  return NULL;
}


int main(){

  sem_init(&mutex,0,1); // setting mutex to 1
  sem_init(&barrier,0,0);// setting barrier to 0

  pthread_t *threads = new pthread_t [n];
  for(int i=0; i < n; i++){
      pthread_create(&threads[i],NULL,&foo,NULL);
  }
  
  for(int i=0; i< n; i++){
      pthread_join(threads[i],NULL);
  }
}
