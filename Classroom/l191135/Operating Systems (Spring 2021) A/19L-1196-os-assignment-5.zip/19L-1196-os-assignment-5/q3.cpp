#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
using namespace std;

class Stack;
void* pushOnStack(void *value);
void* popFromStack(void *value);

sem_t push_update_lock, pop_lock, push_lock, pop_update_lock;
int n = 200; // number of threads
int stackSize = 30;

class Stack {
private:
  int* a; // array for stack
  int max; // max size of array
  int top; // stack top
public:
  Stack(int m){
    a = new int[m]; max = m; top = 0;
  }
  void push(int x) {
    pthread_t self = pthread_self();
    if(top == max){
      // if stack is full then wait
      cout << "thread: " <<  self << "waiting ... to push: [ " << top << " th]\n";
      sem_wait(&push_lock);
      
    }
    else if(top == 0){sem_post(&pop_lock);}

    cout << "thread: " <<  self << " ready to push [ " << top << " th]\n";
    sem_wait(&push_update_lock);
    if(top < max){
      // critical section
      a[top] = x;
      cout << "thread: " <<  self << " pushed [ " << top << " th] sucessfully\n";
      ++top;
    }
    sem_post(&push_update_lock);
  }
  
  int pop() {
    pthread_t self = pthread_self();
    if(top == 0){
      // if stack is empty then wait
      cout << "thread: " <<  self << " waiting ... to pop: [ " << top << " th]\n";
      sem_wait(&pop_lock);
      return -1;
    }
    else if(top == max) sem_post(&push_lock);

    cout << "thread: " <<  self << " ready to pop [ " << top << " th]\n";
    sem_wait(&pop_update_lock);
    int tmp = top;
    if(top > 0){
      // critical section
      cout << "thread: " <<  self << " poped [ " << top << " th] sucessfully\n";
      --top;
    }
    sem_post(&pop_update_lock);
    return a[tmp];
  }
};


Stack stack(stackSize);
int main(){

  sem_init(&pop_lock,0,0); // initially set pop lock as stack is empty
  sem_init(&push_lock,0,1);// initially remove push lock
  sem_init(&push_update_lock,0,1);// set remove update lock
  sem_init(&pop_update_lock,0,1);// set remove update lock

  pthread_t *threads = new pthread_t [n];
  for(int i=0; i < n; i++){
    if(i%2 == 0)
      pthread_create(&threads[i],NULL,&popFromStack,NULL);
    else{
      int valueToPush = i;
      pthread_create(&threads[i],NULL,&pushOnStack,&valueToPush);
    }
  }
  
  for(int i=0; i< n; i++){
    pthread_join(threads[i],NULL);
  }
}

void* pushOnStack(void *value){
  stack.push(*(int*)value);
  return NULL;
}

void* popFromStack(void *value){
  stack.pop();
  return NULL;
}
