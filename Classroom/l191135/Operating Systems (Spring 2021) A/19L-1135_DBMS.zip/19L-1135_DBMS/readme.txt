All the code have been thoroughly tested on vs code and terminal.

Commands to use:

	g++ main.cpp -o main
	./main	

		Thank You :)