Just wrote it for fun ;P
It was looks good.