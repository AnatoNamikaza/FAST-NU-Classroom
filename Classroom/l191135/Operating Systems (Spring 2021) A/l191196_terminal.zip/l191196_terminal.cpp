// g++ l191196_terminal.cpp -o l191196_terminal; ./l191196_terminal
#include <iostream>
#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include <string>
#include<sstream>
#include<string.h>
#include<sys/wait.h>
using namespace std;
char *current_dir = new char [100];

void get_all_path(string pathenv, char *pathlist[]);
int get_no_of_paths(string pathenv);
string concate(string str1,string str2);
string look_up_command(char *paths[],int size,string current_dir,string command);
bool contains(string command, char x);
string drop(string command,char x);
bool is_shell_command(string command);
string read_command();
struct command_t{
  char *name;
  int argc;
  char *argv[];
};

void parse_command(command_t *argv,string command);

int main(){
  
  int npaths = get_no_of_paths(getenv("PATH"));
  char *paths[npaths];
  get_all_path(getenv("PATH"),paths);
  string command;
  getcwd(current_dir,100);

  while(command != "exit"){
    command = read_command();
    int pid = fork();
    if(pid == -1){ cout << "child process was not created \n";}
    else if(pid ==0){
      // child process created successfully
      string file = look_up_command(paths,npaths,current_dir,command);
      //cout << file << "-----------\n";
      if(file == "" || is_shell_command(command)){
      	// may be internal or wrong command
      	// cout << "shell or external command \n";
	istringstream cmd(command);
	string name;	
	cmd >> name;
	//cout << name << endl;
	if(name == "cd"){
	}
	else{
	  system(command.c_str());
	}
      }
      else{
    	command_t *command_set = new command_t;
    	parse_command(command_set,command);
    	int flag = execv(file.c_str(), command_set->argv);
    	if(flag == -1) cout << "error\n";
    	//cout << "executed by execv\n";
      }
      exit(0); 
    }
    else{ wait(NULL);
      // only cd command is running in parent process
      // so that current_directory be updated
      istringstream cmd(command);
      string name;	
      cmd >> name;
      if(name == "cd"){
	string cd_path;
	cmd >> cd_path;
	chdir(cd_path.c_str());
	getcwd(current_dir,100);
      }	
    }
  }

  return 0;
}

void get_all_path(string pathenv, char*pathlist[]){
  /* transform : into space */
  int i=0;
  int path_counter =0;
  while(pathenv[i]){
    if(pathenv[i] == ':') pathenv[i] = ' ';
    i++;
  }
  istringstream iss(pathenv);
  int index=0;
  do{
    char *buffer = new char[50];
    iss >> buffer;
    pathlist[index++] = buffer;
  }
  while(iss);
}

int get_no_of_paths(string pathenv){
  /* transform : into space */
  int i=0;
  int path_counter =0;
  while(pathenv[i]){
    if(pathenv[i] == ':') path_counter++;
    i++;
  }
  return path_counter+1;
}

string concate(string str1,string str2){
  string result = str1+str2;
  return result;
}

string look_up_command(char *paths[],int size, string current_dir,string command){
  // its looks 'command e.g gcc' in all 'paths' e.g ["/usr/bin",...]
  // of 'size'
  // it returns the complete path of command
  //============== first of all look in relative path
  if(contains(command,'/')){
    // it is externel command with reletive or absolute path
    if(command[0] == '/'){
      // if first char is '/' then no need to make file path
      // it will be users responsibility to provide full path
      if(!access(command.c_str(),F_OK)) return command;
    }
    else{
      // it is relative path
      if(command[0] == '.') command = drop(command,'.');
      string file = current_dir + command;;
      if(!access(file.c_str(),F_OK)) return file;
      else{return "";}

      
    }
  }
  else{
    command = "/"+command;
    for(int i=0; i< size; i++) {
      string file = concate(string(paths[i]),command);
      if(!access(file.c_str(),F_OK)) {
	//cout << "found in bin\n";
	return file;
      }      
    }
  }
  return "";
}

bool contains(string command,char x){
  for(int i=0; i< command.length(); i++){
    if(command[i] == x) return true;
  }
  return false;
}

string drop(string command,char x){
  // it removes the unwanted char from a string 
  string result;
  for(int i=0; i< command.length(); i++){
    if(command[i] != x) result=result+command[i];
  }
  return result;
}

void parse_command(command_t *argv,string command){
  istringstream iss(command);
  string cmd_name;
  iss >> cmd_name;
  argv->name = new char[cmd_name.length()+1];
  strcpy(argv->name,cmd_name.c_str());

  int i=0;
  int arg_counter =0;
  while(command[i]){
    if(command[i] == ' ') arg_counter++;
    i++;
  }
  arg_counter += 1;
  argv->argc = arg_counter;
  istringstream rss(command); // reset head
  
  //argv->argv = new char*[arg_counter];
  for(int i=0; i< arg_counter; i++){
    string arg;
    rss >> arg;
    argv->argv[i] = new char[arg.length()+1];
    strcpy(argv->argv[i],arg.c_str());
  }
  argv->argv[arg_counter] = NULL;
}

bool is_shell_command(string command){
  istringstream iss(command);
  string name;
  iss >> name;
  string shell_commands[] = {"cd","ls","help"};
  //for(int i=0; i< 2; i++){
  for(int i=0; i< sizeof(shell_commands)/sizeof(string); i++){
    //    cout << "-----------" << shell_commands[i] << endl;
    if(name == shell_commands[i]) return true;
    
  }
  return false;    
}

string read_command(){
  string command;
  char hostname[50];
  gethostname(hostname,50);  
  cout << getenv("USER") << "@" << hostname << ":" << current_dir << "$ ";
  getline(cin, command);
  return command;
  
}
