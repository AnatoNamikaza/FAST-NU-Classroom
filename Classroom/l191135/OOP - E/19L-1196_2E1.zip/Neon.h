#ifndef _NEON_H
#define _NEON_H
class Course; //forward declaration

class Person{
  // it is abstract class
 private:
  char *name;
 public:
  // default constructor
  Person();
  //parametrized constructor
  Person(const char *_name);
  char *getName();
  void print();

  ~Person();
  
};
//======================================================

class Student: public Person{
 private:
  int rollNo;
 public:
  Student();
  Student(const char *_name, int _rollNO);
  int getRollNo();
  void print();
  ~Student();
};
//=====================================================

class Employee: public Person{
 private:
  int employee_id;
  
 public:
  Employee();
  Employee(const char *_name, int _employee_id);
  char* getName();
  int getEmployee_ID();
  void teachCourse(const Course &_course);
  
  void print();
  ~Employee();

};
//====================================================
class Teacher: public Employee{
 private:
  Course **courses;
  int course_counter;
   public:
  Teacher();
  Teacher(const char *_name, int _teacher_id);
  //  Teacher(const Teacher &_teacher);
  char* getName();
  void teachCourse(const Course &_course);
  int getTeacherID();
  void print();
  ~Teacher();
 
};
//==================================================
/*
class TA: public Student, public Teacher{
 public:
  TA();
  TA(const char *_name, int _rollNO, int _teacher_id);
  int getRollNo();
  void print();
  ~TA();
};
*/

//==================================================
class Course{
 private:
  char *name;
  int course_id;
  Student **students;
  int student_counter;
  Teacher *teacher;
  //  TA *ta;
  
 public:
  Course();
  Course(const char *_course_name, int _course_id);
  Course(const Course &obj);
  char* getName();
  bool registerStudent(Student &_student);
  void assignTeacher(Teacher &_teacher);
  //  void assignTA(TA &_ta);
  void print();
  ~Course();
};

/* class Registration{ */
/*  private: */
  
/*  public: */
/*   void registerCourse(const Student &_student, const Course &_course); */
  
/* } */;

class Department{
 private:
  char *name; // department name
  int n_courses;
  int course_counter;
  Course **courses;
  Employee IT;
  Employee hod;
  Employee **teachers;
  int teacher_counter;
  Student **students;
  int student_counter;
  
 public:
  Department();
  Department(const char *_name, int _n_courses);
  char* getName();

  void addCourse(const Course &course);
  bool registerStudent(Student &_student, Course &_course);
  bool assignTeacher(const Teacher &_teacher, const Course &_course);

  void print();
  ~Department();
};

//=========================== 
class University{
 private:
  char *name;
  int n_departments;
  int department_counter;
  Department **departments;
 public:
  University();
  University(const char *_name, int _n_departments);
  bool addDepartment(const char * _name, int n_courses);
  bool addCourse(const char * _department_name, const Course &obj);
  bool registerStudent(char *_department_name, Student &_student, Course &_course);
  void print();
  ~University();
};
/*
class Department
class Course{};
class Registration{};
*/

#endif
