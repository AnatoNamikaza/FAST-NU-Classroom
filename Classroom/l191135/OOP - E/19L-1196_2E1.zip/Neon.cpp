#include "Neon.h"
#include <iostream>
using namespace std;

int strCompare(const char *str1, const char *str2){
  int index=0;
  while(str1[index] && str2[index]){
    if(str1[index] > str2[index]) return 1;
    else if (str1[index] < str2[index]) return -1;
    index++;
  }
    if(str1[index] > str2[index]) return 1;
    else if (str1[index] < str2[index]) return -1;
    else{return 0;}  
}
Person::Person(){name=0;}
//parametrized constructor
Person::Person(const char *_name){
  int length=0;
  while(_name[length++]); // counting length
  // allocate memory 
  name = new char[length];
  for(int i=0; i<= length; i++){
    name[i] = _name[i];
  }
}

char* Person::getName(){
  if(name !=0){return name;}
  else {return '\0';}
}

void Person::print(){
  cout << "Name: " << name << endl;
}


Person::~Person(){
  if(name != 0){
    delete [] name;
  }
}


Student::Student(){rollNo=0;}
Student::Student(const char *_name,int _rollNo):
  Person(_name){rollNo = _rollNo;}

int Student::getRollNo(){return rollNo;}
void Student::print(){

  Person::print();
  cout << "roll No : " << rollNo << endl;
}

Student::~Student(){
  cout << "~Student() called";
  // name will be deleted by person
}
//=================================================
Employee::Employee(){cout << "Employee() called";}
Employee::Employee(const char *_name, int _employee_id):
  Person(_name){employee_id = _employee_id;
  cout << "Employee(char,id) called\n";
}

char* Employee::getName(){return Person::getName();}
int Employee::getEmployee_ID(){
  return employee_id;
}

void Employee::print(){
  Person::print();
  cout << "Employee Number: "  << employee_id << endl;
}

Employee::~Employee(){
  cout << "~Employee() called\n";
  // name will be deleted by person
}

//=================================================
Teacher::Teacher(){
  courses=0;
  course_counter=0;
cout << "Teacher() called";}

char* Teacher::getName(){
  return Employee::getName();
}

Teacher::Teacher(const char *_name, int _teacher_id):
  Employee(_name,_teacher_id){
  courses = 0;
  course_counter=0;
  }
/*
Teacher::Teacher(const Teacher &_teacher){
  Teacher(_teacher.getName(), _teacher.getEmployee_ID());
  if(course_counter !=0){
    for(int i=0; i< _teacher.course_counter; i++){
      this->teachCourse(*_teacher.courses[i]);
    }
  }
  cout << "Teacher(const Teacher) called\n";
}
*/

int Teacher::getTeacherID(){
return Employee::getEmployee_ID();
}

void Teacher::teachCourse(const Course &_course){
  Course **temp; // 
  course_counter++;
  temp = new Course *[course_counter];
  
  for(int i=0; i< course_counter-1; i++){
    // copying previous values
    temp[i] = new Course(*(courses[i]));
    
  }
  // append this pbject
  
  temp[course_counter-1] = new Course(_course);
  
  for(int i=0; i< course_counter-1; i++){
    delete courses[i];
  }
  delete courses;
    courses = temp;
}

void Teacher::print(){
Person::print();
cout << "Teacher id: "  << Employee::getEmployee_ID() << endl;
 cout << "course list teaching " << endl;
 for(int i=0; i< course_counter; i++){
      cout << i+1 << " : " << (courses[i]->getName()) << endl;
 }
}

Teacher::~Teacher(){
  cout << "~Teacher() called\n";
// name will be deleted by person destructor
}
//=================================================
/*
TA::TA(){cout << "TA() called";}
TA::TA(const char *_name, int _rollNo, int _teacher_id):
  Student(_name, _rollNo), Teacher(_name, _rollNo){}
int TA::getRollNo(){return Student::getRollNo();}
void TA::print(){
Student::print();
cout << "Teacher ID: " << Teacher::getTeacherID() << endl;
}

TA::~TA(){
  cout << "~TA called";
//name will be deleted in base class
}
*/
//================================================

Course::Course(){
  name = 0;
  students=0;
  
  }

Course::Course(const char *_name, int _course_id){
int length=0;
  while(_name[length++]); // counting length
  // allocate memory 
  name = new char[length];
  for(int i=0; i<= length; i++){
    name[i] = _name[i];
  }
  course_id = _course_id;
  students = 0;
  student_counter=0;
  teacher=0;
}

Course::Course(const Course &course){
int length=0;
  while(course.name[length++]); // counting length
  // allocate memory 
  name = new char[length];
  for(int i=0; i<= length; i++){
    name[i] = course.name[i];
    }
  course_id = course.course_id;
  students = 0;
  student_counter=0;
  teacher=0;
}
//--------------------------------
bool Course::registerStudent(Student &_student){
Student **temp; // 
  student_counter++;
  temp = new Student *[student_counter];
  
  for(int i=0; i< student_counter-1; i++){
    // copying previous values
    temp[i] = new Student(*(students[i]));
    
  }
  // append this pbject
  
  temp[student_counter-1] = new Student(_student);
  
  for(int i=0; i< student_counter-1; i++){
    delete students[i];
  }
  delete students;
    students = temp;
}
//--------------------------------
char* Course::getName(){return name;}
//--------------------------------
void Course::assignTeacher(Teacher &_teacher){
  //teacher = new Teacher(_teacher);

  Teacher *temp = new Teacher(_teacher.getName(),_teacher.getTeacherID());
  teacher = temp;

}
/*
void Course::assignTA(TA &_ta){
  TA *temp = new TA(_ta.getName(),_ta.getRollNo(),_ta.getTeacherID());
  ta = temp;
}
*/
void Course::print(){
  cout << "++++++++++++++++++++++++++++\n";
  cout << "course name: " << name;
  cout << " id: " << course_id << endl;
  cout << "Teacher Name: " << teacher->getName() << endl;
    //cout << "TA Name: " << ta->getName() << endl; 
  cout << "++++++++++++++++++++++++++++\n";
  cout << "list of students ...\n";
  for(int i=0; i< student_counter; i++){
    students[i]->print();
  }
}

Course::~Course(){
  if(name !=0){
    delete []name;
  }
  name = 0;
  cout << "~Course() called\n";

}
//==================================
// Registration::Registration(){
//   cout << "Registration() called\n";
// }
//==================================
Department::Department(){
  name = 0;
  course_counter=0;
  courses=0;
  teachers=0;
  teacher_counter = 0;
  student_counter = 0;
}

Department::Department(const char *_name, int _n_courses){
  int length=0;
  while(_name[length++]); // counting length
  // allocate memory 
  name = new char[length];
  for(int i=0; i<= length; i++){
    name[i] = _name[i];
  }
  
  courses = new Course *[_n_courses];
  n_courses = _n_courses;
  
  course_counter=0;
}

char* Department::getName(){return name;}

void Department::addCourse(const Course &course){
  Course *temp = new Course(course);
  if(course_counter < n_courses){
    courses[course_counter++] = temp;
  }
  else{
    cout << "you cannot add further courses\n";
  }
}
//----------------------------
bool Department::registerStudent( Student &_student,  Course &_course){
  // search course name
int index=-1; // index of search department
  for(int i=0; i< course_counter; i++){
    char *cname= _course.getName();
    if(strCompare(cname, courses[i]->getName()) ==0) index=i;
  }
    if(index != -1){
      // Course found
      
      courses[index]->registerStudent(_student);
      return 1;
    }
    else{
      cout << "no such course found\n";
      return 0;
    }

}

void Department::print(){
  cout << "Department Name: " << name << endl;
  cout << "list of courses offered\n";
  for (int i=0; i< course_counter; i++){
    courses[i]->print();
    
  }
}

Department::~Department(){

  for(int i=0; i < course_counter; i++){
    delete courses[i];
  }
  delete courses;
 courses=0;
 cout << "~Department() called\n";
}
		
University::University(){
  name=0;
  n_departments=0;
  department_counter=0;
  departments =0;
}				       

University::University(const char *_name, int _n_departments){
  int length=0;
  while(_name[length++]); // counting length
  // allocate memory 
  name = new char[length];
  for(int i=0; i<= length; i++){
    name[i] = _name[i];
  }
  n_departments = _n_departments;
  departments = new Department *[n_departments];
  department_counter =0;
}

bool University::addDepartment(const char *_name, int n_courses){
  if(department_counter < n_departments){
  Department *temp = new Department(_name,n_courses);
  departments[department_counter++] = temp;
  return 1; // successfully added
  }
  else{
    cout << "you cannot add further department\n";
    return 0; // failed to add
  }
}
 
//---------------------
bool University::addCourse(const char *_department_name, const Course &obj){
  // search the department name
  // then add course
  
  int index=-1; // index of search department
  for(int i=0; i< department_counter; i++){
    if(strCompare(_department_name, departments[i]->getName()) ==0) index=i;
  }
    if(index != -1){
      // department found
      
      departments[index]->addCourse(obj);
      return 1;
    }
    else{
      cout << "no department found\n";
      return 0;
    }

  }
//--------------------
bool University::registerStudent(char *_department_name, Student &_student, Course &_course){

  int index=-1; // index of search department
  for(int i=0; i< department_counter; i++){
    if(strCompare(_department_name, departments[i]->getName()) ==0) index=i;
  }
    if(index != -1){
      // department found
      
      departments[index]->registerStudent(_student, _course);
      return 1;
    }
    else{
      cout << "no department found\n";
      return 0;
    }

}
//---------------------
void University::print(){
  cout << "university Name: " << name << endl;
  cout << "Total departments allowed: " << n_departments << endl;
  cout << "list of departments\n";
  for(int i=0; i< department_counter; i++){
    cout << "--------------------------------\n";
        departments[i]->print();
  }
} 
  
//--------------------
University::~University(){
  //  cout << "running ~University()\n";
  for(int i=0; i< department_counter; i++){
    delete departments[i];
  }
  delete [] departments;
  departments =0;
  cout << "~University Called\n";
}
