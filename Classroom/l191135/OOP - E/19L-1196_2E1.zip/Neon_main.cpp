#include <iostream>
#include <string>
#include "Neon.h" // contains all classes prototypes
#include <fstream>
using namespace std;

int display_menu(string,int);	//specific prompt, max_possible option

class Menu{
  // it contains all the prompts and number of possible options 
  //for validation purpose at the time of input
public:
  string student_menu;
  string teacher_menu;
  string IT_menu;
  string hod_menu;
  int student_options;
  int teacher_options;

  int IT_options;
  int hod_options;
public:
  Menu():

    //using \ for breaking long lines
    hod_menu("0: log out\n\
1: Assign Course to teacher\n\
2: Register a course for a student\n\
3: Unregister a course for student\n\
4: View grades of specific course: "),
    // you will have to update the no of optipons
    // if new new option is added above
    hod_options(5), // total options in menu

    student_menu("0: log out\n\
1: Register Course\n\
2: Unregister a course\n\
3: withdraw a course\n\
4: View markssheet of specific course\n\
5: View attendence of specific course\n\
6: change password: "),
    student_options (7),

    teacher_menu( "0: log out\n\
1 Manage attendence\n\
2: View attendence\n\
3: Manage Evaluation\n\
4: View Evaluation\n\
5: Assign Grades: "),
    teacher_options( 6),

    IT_menu("0: log out\n\
1: Create Account of Faculty\n\
2: Delete account of Faculty\n\
3: Create account of student\n\
4: Delete Accout of Student\n\
5: Maintain Accounts: "),
    IT_options (6)
  {} // end of initializer list
};

int main(){


  
 
    int choice;

    Menu main_menu;
    // read database
    // if no database, then allow IT manager to customize
    ifstream database;
    database.open("database.txt",ios::in);
    if(database.fail()){
      // no database exist
      char email[30];
      char password[20];
      cout << "Welcome to NEON: University Management software\n";
      cout << "please sign up first ";
      cout << "Enter email ... ";
      cin.getline(email,30);
      cout << "Enter password: ";
      cin.getline(password,20);
      //---------------------- store email and password
      ofstream credentials;
      credentials.open("login_info.txt",ios::app);
      if(credentials.is_open()){
	credentials << email << "\t// email \n";
	credentials << password << "\t// password \n";
	credentials.close();
      }
      else{
	cout << "failed to open the login file\n";
      }

      //---------------------
      cout << "Enter Name of University\n";
      char university_name[50];
      int n_departments;
      cin.getline(university_name,50);
      cout << "Enter Number of Departments: ";
      cin >> n_departments;
      
      ofstream database;
      database.open("database.txt",ios::out);
      if(database.is_open()){
      cout << "university name is " << university_name << endl;
      database << university_name << " // university name\n";
      database << n_departments << " // No of departments\n";
      database.close();
      cout << "Data has been stored in a file \n";
      }
      else{
	cout << "failed to open the database file...\n";
      }
    }
      else{
	// read data and make uni obj and return that obj
	// university = readDataFromFile(filename);
	
	cout << "database has been read\n";
	

      }
/*
    choice = display_menu(main_menu.student_menu, main_menu.student_options);
    choice = display_menu(main_menu.teacher_menu, main_menu.teacher_options);
    choice = display_menu(main_menu.IT_menu, main_menu.IT_options);
    choice = display_menu(main_menu.hod_menu, main_menu.hod_options);
  

    Person p1;
    Person p2("zaeem");
    p2.print();
  
    Student s1("zikar", 1196);
    s1.print();
  
    Faculty f1("ahsan",1234);
    Teacher t1("ahsan yousaf",2333);
    TA ta1("Abdur rehman", 1122, 775);
  
    f1.print();
    t1.print();
    ta1.print();
  */

    

}// end of main


int display_menu(string prompt, int no_of_options) {
  // performing validation
  int choice = 0;
  do{
    if(choice < 0 || choice > no_of_options){
      cout << "***invalid option, select carefully***\n";
    }
    cout << "Enter an integer to select from given options\n";
        cout << prompt;
    cin >> choice;
  }while(choice < 0 || choice >no_of_options);  
  return choice;
}
