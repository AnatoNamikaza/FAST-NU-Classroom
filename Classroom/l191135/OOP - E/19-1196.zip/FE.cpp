#include <iostream>
#include <fstream>
#include <string.h>
using namespace std;

//------------------------------------Global Template Function----------------------------------------
//Add here
template<typename Type>
void grow(Type*& arr,int size) {
	int old_size = strlen(arr)+1;
	Type* newarray = new Type[size];
	for (int i = 0;i < old_size;i++) {
		newarray[i] = arr[i];
	}
	for(int i=0; i< old_size; i++){
	  delete []arr[i];
	}
	arr = newarray;
	newarray = 0;
	old_size = size;
}
//-----------------------------
template <class Type1, class Type2>
int strCompare(Type1 *str1, Type2 *str2){
  int index=0;
  while(str1[index] && str2[index]){
    if(str1[index] > str2[index]) return 1;
    else if (str1[index] < str2[index]) return -1;

    index++;
  }
  if(str1[index] > str2[index]) return 1;
  else if (str1[index] < str2[index]) return -1;
  else{return 0;}  
}

template <class Type1, class Type2>
void copy(Type1 *&var1, Type2 *&var2){
  // copy var2 into var1
  int length=0;
  while(var2[length++]);
  var1 = new char[length];
  for(int i=0; i<=length; i++) var1[i]=var2[i];

}
//-----------------------------




//-----------------------------------------Name----------------------------------------------------------
class Name{
  char* fname;
  char* lname;
public:
  Name(char* fname, char* lname) {
    this->fname = new char[strlen(fname) + 1];
    this->lname = new char[strlen(lname) + 1];
    strcpy(this->fname, fname);
    strcpy(this->lname, lname);
  }
  ~Name() {
    if (fname != 0)
      delete[] fname;
    if (lname != 0)
      delete[] lname;
  }
  
  Name(){
    fname=0;
    lname=0;
  }

  Name(const Name & n) {
    this->fname = new char[strlen(n.fname) + 1];
    this->lname = new char[strlen(n.lname) + 1];
    strcpy(this->fname, n.fname);
    strcpy(this->lname, n.lname);

  }
  friend ostream& operator<<(ostream& out, const Name & n){
    //out << "Name is ";
    out << n.fname << " " << n.lname << endl;
    return out;
  }
  
  char* getFirstName(){
    return fname;
  }
  //-------------
    char* getLastName(){
    return lname;
  }
  
  // ostream& operator<<(ostream& out, const Name & n) {
  // out << n.fname << " " << n.lname;
  //return out;
  //}
};

void signUp(Name &name, int &b){
  char* fname;
  char* lname;
  
  cout << "enter your first name: ";
  cin >> fname;
    cout << "enter your last name: ";
    cin >> lname;
      cout << "enter balance: ";
      cin >> b;
      name = Name(fname,lname);
}

//-----------------------------------------Player----------------------------------------------------------

class Player {
  int id;
  Name  pname;
  char * contact;
  int balance;
  static int count;
  public:
    Player(){
      // default constructor
      id=0; // 0 means nullptr
      //pname=0;
      contact = 0;
      balance = 0;
      count = 0;
    }
    //------------- parametrized constructor
    Player(Name _name, int _id, char* _contact, int _balance=0){
      //pname = Name(_name);
      id = _id;
      copy(contact,_contact);
      balance = _balance;
      //count = 0;
    }
  Name getName(){
    return pname;
  }
  //------------------
  Player(Player &obj){
      //pname = Name(_name);
    id = obj.id;
      copy(contact,obj.contact);
      balance = obj.balance;
      //count = 0;
    }
  // Name getName(){
  //   return pname;
  // }

  //-------------------
  //Add all required functions.
  friend ostream& operator<<(ostream& out,Player& p){
    //cout << p.getName();
    //out << p.pname.getFirstName() << p.pname.getLastName();
    out << p.pname;
    return out;
    
  }
};

  //-----------------------------------------------------------------------------------------------------------

  //Add all required classes with complete Implementaion here.
class Team{
private:
  char* team_name;
  int team_id;
  Player** players;
  int player_counter;
  Team(){
    players=0;
    team_id=0;
    player_counter=0;
  }
  Team(char* _name, int id){\
    copy(team_name, _name);
    team_id = id;
    player_counter=0;
    players= new Player* [5]; // max 5 players
  }
  
  bool addMember(Player &obj){
    if(player_counter <5 && players !=0){
      players[player_counter++] = new Player(obj);
    }
  }
  
};
//-------------------------------------
class plateform{
private:
  char* name; // name of plateform
  int controllerId;
  Player p1;
  
  plateform(){
    name=0;
    controllerId =0;
  }
  plateform(const char* _name, int _controllerId){
    copy(name,_name);
    controllerId = _controllerId;
  }
  assignPlayer(const player &p1){
    player p1 = new Player(p1);
  }
   removePlayer(const player &p1){
     delete p1;
     player p1=0;
  }
};

class PC: public plateform {
public:
  PC(int id):
    plateform("pc",id){}

};
class PS: public plateform {
private:
  plateform ** plateforms;
  int no_of_players;
  int player_counter;
  PS(){
    plateforms =0;
    no_of_players=0;
    player_counter =0;
  }
  PS(int no_of_controllers){
    no_of_players = no_of_controllers;
    plateforms = new Plateform* [no_of_players];
    player_counter=0;
  }
  assignPlayer(int controllerId, const player &p1){
    
    plateforms[player_counter++]->assignPlayer(p1);
  }
  
  removePlayer(int controllerId, const player &p1){
    
    plateforms[player_counter++]->removePlayer(p1);
  }
  
  
};

  //-----------------------------------------GamingZone----------------------------------------------------------

  class GamingZone {
  private:
    Plateform** plateforms;
    int no_of_plateforms;
    int player_no;
    
    //Add all required functions and data members.
  public:
    GamingZone(int no_of_players, int no_of_plateforms){
      player_no= no_of_players;
      plateforms = new Plateform*[no_of_plateforms];
    }
    
  void run() {
  while (true) {
  //system("cls"); commented because I am using linux
  int option;
  cout << "What do you want to do?\n\t1. Register new player\n\t2. Login\n\t3. Press Any key to Exit \n\nEnter your choice: ";
  cin >> option;
  if (option == 1) // 1. Register new player
  {
  signUp();
  //system("PAUSE");
  }
  else if (option == 2)	// 2. Login
  {
  int id;
  cout << "Enter Your User Id:";
  cin >> id;
  if (getPlayerWithId(id) != 0) { //Search player in list and return its address if exist.
  cout << "What do you want to do?\n\t1. Play a PS game\n\t2. Play a PC game\n\t3. Press Any key to Exit\n\nEnter your choice: ";
  cin >> option;
  if (option == 1) // 1. Play a PS game
  playonPS(id); 
  else if (option == 2)	// 2. Play a PC game
  playonPC(id);
  else  //3. Exit
  return;  
  }
  }
  else //3. Exit
  return; 
  }
  }

  };

  //-----------------------------------------Driver----------------------------------------------------------
  */
int main() {
  //Player p1;
  char fname[] = "zaeem";
  char lname[] = "Yousaf";
  Name zaeem(fname, lname);
  char pn[] = "0304-8818185";
    
  // GamingZone zone (50, 20);
  // zone.loadPlayers();
  // zone.loadPlatforms();
  // zone.run();
  return 0;
}
