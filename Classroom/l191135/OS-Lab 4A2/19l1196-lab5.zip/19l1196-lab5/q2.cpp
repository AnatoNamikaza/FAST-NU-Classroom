#include<iostream>
#include<stdlib.h>
#include<fcntl.h>
#include<sys/mman.h>
#include<unistd.h>
#include<fstream>
#include <sys/types.h>
#include <sys/wait.h>
#include<string.h>
using namespace std;

int main(){
    char c;
    char buffer[500];
    int size=0;
    fstream fin("lab.txt");
    
    if(fin.is_open())
    {
      char c;
        while(!fin.eof())
        {
	  fin >> c;
	  buffer[size] = c;
	  size++;
	}
        buffer[size]='\0';
        fin.close();
    }
    int fd=shm_open("sharem",O_CREAT|O_EXCL|O_RDWR,0600);
    
    if(fd<0){
        perror("shm_open() error");
        return EXIT_FAILURE;
    }
    ftruncate(fd,size);
    char *data=(char*)mmap(0,size*sizeof(int),PROT_WRITE|MAP_SHARED|PROT_READ,fd,0);
    printf("addressed maped by sender: %p\n",data);
    for(int i=0;i<size;i++)
    {
        data[i]=buffer[i];
    }
    int pid=fork(); // create new process
    if(pid==0)
    {
      int words=0; // word is considered when a space occures
        for(int i=0;i<size;i++)
        {
            if(data[i]==' ')
                words++;
        }
        ofstream out;
        out.open("lab.txt",ios::app);
        out<<endl<<words;
        out.close();   
    }
    else
    {
        int lines=0;
        for(int i=0;i<size;i++)
        {
            if(data[i]=='.')
                lines++;
        }
	// create output file stream
        ofstream out;
        out.open("lab.txt",ios::app);
        out<<endl<<lines;
        out.close();   
    }
    munmap(data,size*sizeof(int));
    close(fd);
    // unlink shared mem
    shm_unlink("sharem");
    return EXIT_SUCCESS;
}
