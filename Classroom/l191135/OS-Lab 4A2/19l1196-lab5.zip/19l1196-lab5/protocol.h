#ifndef PROTOCOL_H
#define PROTOCOL_H

#define NAME "/shmem-example"


#define NUM 5

#define SIZE (NUM * sizeof(int))

#endif /*PROTOCOL_H*/