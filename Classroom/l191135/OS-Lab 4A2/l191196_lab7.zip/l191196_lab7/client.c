//gcc client.c -pthread -o client
#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <string.h>
#define PORT 8080

int allocatedPopulation; // total population of an area
int election_status=1;// 1: continue 0: ended

int getRegionID(){
  int region_id;
  do{
    printf("Enter your region ID [1-5] ");
    scanf("%d",&region_id);
  }while(region_id < 1 && region_id > 5);
}

int castVote(int waiting){
  int castedVote;
  printf("waiting for other %d voters: ",waiting); 
  printf("1: Green 2: Blue: ");  
  scanf("%d",&castedVote);
  while(castedVote < 1 || castedVote > 2){
    printf("1: Green 2: Blue: ");  
    scanf("%d",&castedVote);
  }
}
int main(int argc, char const *argv[])
{
  int sock = 0;
  struct sockaddr_in serv_addr;
  char buffer[1024] = {0};
  if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
      printf("\n Socket creation error \n");
      return -1;
    }

  serv_addr.sin_family = AF_INET;
  serv_addr.sin_port = htons(PORT);
	
  // Convert IPv4 and IPv6 addresses from text to binary form
  if(inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr)<=0)
    {
      printf("\nInvalid address/ Address not supported \n");
      return -1;
    }

  if (connect(sock, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
    {
      printf("\nConnection Failed \n");
      return -1;
    }

  printf("Most welcome to the Election 2021\n");
  
  int region_id = getRegionID();  
  
  write(sock,&region_id ,sizeof(int));
  read( sock , &allocatedPopulation, sizeof(int));
  
  int waiting = allocatedPopulation;
  
  if(allocatedPopulation == -1){
    printf("This polling Station is already casting votes\n");
  }
  else{
      while(election_status != 0 && waiting > 0){
  	int castedVote = castVote(waiting);
  	write(sock,&castedVote ,sizeof(int));
  	read( sock , &election_status, sizeof(int));
  	waiting--;
      }
      printf("All are done, watch the result on server\n");
      printf("allocated population is: %d ",allocatedPopulation);
    }
  return 0;
}
