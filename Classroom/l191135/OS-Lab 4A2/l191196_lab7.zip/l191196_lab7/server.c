//g++ server.c -pthread -o server;
// Server side C/C++ program to demonstrate Socket programming
#include <unistd.h>
#include <stdio.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#define PORT 8080
#include <pthread.h>

typedef struct Election{
  int totalVotes[2];
  int totalCompleted;
  int totalBegan;
  int regionCompleted[5];
  int began[5];
  int population[5];
  
}Election_t;

void *handle_election(void *ptr);
int isElectionOver(Election_t *election,int max);
void addVote(Election_t *election, int vote);
void display_election(Election_t *election);

Election_t *newElection(){
  Election_t *election = (Election_t *)malloc(sizeof(Election_t));
  election->population[0] = 5;
  election->population[1] = 10;
  election->population[2] = 15;
  election->population[3] = 20;
  election->population[4] = 25;

  return election;
}

/* void fillPopulation(Election_t *election){ */
/*   election->population[0] = 5; */
/*   election->population[1] = 10; */
/*   election->population[2] = 15; */
/*   election->population[3] = 20; */
/*   election->population[4] = 25; */
/* } */

int isElectionOver(Election_t *election,int max){
  if(election != NULL)
    if(election->totalCompleted == max) return 1;
  return -1;
}


void addVote(Election_t *election, int vote){
  if(vote == 1) election->totalVotes[0]++;
  else
    election->totalVotes[1]++;
}

int allocatePopulation(Election_t *election, int id){
  // if election area has already casted then return -1;
  for(int i=0; i< 5; i++){
    if(election->began[i] == id || election->regionCompleted[i] == id) return -1;
  }  
  // id 1 is mapped to 0 threadIndex
  if(election != NULL){
    election->began[id-1] = id;
    //printf("returning %d ",election->population[id-1]);
    return election->population[id-1];
  }
  return -1;
}
 
void display_election(Election_t *election){
  if(election != NULL){
    printf("======================= Election statistics =================\n");
    printf("Election Result\n");
    printf("Total Votes of Green party: %d\n", election->totalVotes[0]);
    printf("Total Votes of  Blue party: %d\n", election->totalVotes[1]);
    printf("======================= Election statistics =================\n");
  }
}

Election_t *electionData;
int main(int argc, char const *argv[])  
{
  electionData = newElection();// for five areas
  int server_fd, new_socket, valread;
  struct sockaddr_in address;
  int opt = 1;
  int addrlen = sizeof(address);
  char buffer[1024] = {0};
  //char *hello = "Hello from server";
	
  // Creating socket file descriptor
  if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == 0)
    {
      perror("socket failed");
      exit(EXIT_FAILURE);
    }
	
  // Forcefully attaching socket to the port 8080
  if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT,&opt, sizeof(opt)))
    {
      perror("setsockopt");
      exit(EXIT_FAILURE);
    }
  address.sin_family = AF_INET;
  address.sin_addr.s_addr = INADDR_ANY;
  address.sin_port = htons( PORT );
	
  // Forcefully attaching socket to the port 8080
  if (bind(server_fd, (struct sockaddr *)&address,
	   sizeof(address))<0)
    {
      perror("bind failed");
      exit(EXIT_FAILURE);
    }
  if (listen(server_fd, 3) < 0)
    {
      perror("listen");
      exit(EXIT_FAILURE);
    }


  int n_threads = 6;
  pthread_t *threads[n_threads]; // 5 polls and one itself
  int threadIndex=0;
  printf("waiting ... for client\n");
  while(threadIndex < n_threads){
    if ((new_socket = accept(server_fd, (struct sockaddr *)&address,(socklen_t*)&addrlen))<0)
      {
	perror("accept");
	exit(EXIT_FAILURE);
      }
    int * connect_socket = (int *)malloc(sizeof(int));
    * connect_socket = new_socket;
    pthread_t *t = (pthread_t *)malloc(sizeof(pthread_t));
    threads[threadIndex++] = t;
    pthread_create(t,NULL,&handle_election, connect_socket);  
  }
  for(int i=0; i< threadIndex; i++){
    pthread_join(*threads[i],NULL);
  }

  display_election(electionData);  
  return 0;
}

void *handle_election(void *socket_to_coneected){
  int connect_socket = *(int *)socket_to_coneected;
  int areaID;
  read( connect_socket , &areaID, sizeof(int));
  
  int population_size = allocatePopulation(electionData,areaID);
  write( connect_socket , &population_size, sizeof(int));
  if(population_size > 0){

    for(int i=0; i< population_size; i++){
      int vote;
      read(connect_socket , &vote, sizeof(int));
      addVote(electionData,vote);

      if(isElectionOver(electionData,5)){
	int end=1;
	write(connect_socket , &end, sizeof(int));
      }

      else{
	int end=0;
	write( connect_socket,&end,sizeof(int));
      }
    }
  } 
  close( connect_socket);
  return NULL;
}
