#include<iostream>
#include<fstream>
using namespace std;

int avgIndex = 0; 
float avg[2]; // it will store two averages

bool contains(int arr[], int toSearch, int size){
  // will help to find duplicates
  bool found=false;
  for(int i=0;i<size;i++){
      if(arr[i]==toSearch){
	  found=true;
      }
  }
  return found;
}

void* computeAvg(void *filename){
  // it reads a file and extracts positive unique integers
  int buffer[500]; // max rows in a file
  int rows = 0;
  string line;
  ifstream in((char *)filename);
  if(in.is_open()){
    while(!in.eof()){
      getline(in,line);
      if(line.length() > 0){
	//cout << line << endl;
	int nextNumber = atoi(line.c_str());
	if(!contains(buffer,nextNumber,rows) && nextNumber > 0){
	  buffer[rows] = nextNumber;
	  rows++;
	}	
      }
    }
  }

  in.close();
  int sum = 0;
  for(int i=0; i < rows; i++){
    sum = sum + buffer[i];
  }

  avg[avgIndex++]= sum/(float)rows;
  return filename; // to avoid return error
  //return avg;
}

int main(int args, char *argv[]){
  pthread_t t1;
  pthread_t t2;
  char *f1 = argv[1];
  char *f2 = argv[2];

  pthread_create(&t1,NULL,&computeAvg, f1);
  pthread_create(&t2,NULL,&computeAvg, f2);
  
  pthread_join(t1,NULL);
  pthread_join(t2,NULL);
  
  cout << "--------------------\n";
  cout << "average of one file: " << avg[0] << endl;
  cout << "--------------------\n";
  cout << "average of other file: " << avg[1] << endl;
  cout << "--------------------\n";
  cout << "combined average: " << (avg[0] + avg[1])/2.0 << endl;
  cout << "--------------------\n";

  //return 0;
}
