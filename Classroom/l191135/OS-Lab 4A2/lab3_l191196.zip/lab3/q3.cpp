#include <iostream>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
using namespace std;
int main(int argc, char *argv[]){
  char *const commands_list[4] = {"mkdir dir_created",
				 "touch file.txt",
				 "echo hello > file.txt",
				  "rm -r dir_created"};
  
  int pid = fork();
  for(int i=0; i< 4; i++){
    if(pid == 0){
      system(commands_list[i]);
    }
    else{
      wait(NULL);
    }
  }
  return 0;
}
