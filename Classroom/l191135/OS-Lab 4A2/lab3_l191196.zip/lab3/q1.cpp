#include <iostream>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
using namespace std;
int main(){
  int pid=fork();
  if(pid == -1) exit(-1);
  else if(pid == 0){
    for(int i=0; i< 100; i++)
      cout << i+1 << " I am child process\n";
  }
  else{
    for(int i=0; i< 100; i++)
      cout << i+1 << " I am parent process\n";
  }
}
