#include <iostream>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
using namespace std;

int add(int array[], int size){
  int s=0;
  for(int i=0; i< size; i++) s+=array[i];
  return s;
}

int avg(int array[], int size){
  int s=add(array,size);
  return s/size;  
}

int max(int array[], int size){
  int max=array[0];
  for(int i=0; i< size; i++){
    if(array[i] > max) max= array[i];
  }
  return max;
}

int main(int argc, char *argv[]){
  int array[argc-1];
  for(int i=1; i< argc; i++) {array[i-1] = atoi(argv[i]);}
  //for(int i=0; i< argc-1; i++) cout << array[i];

  int pid=fork(); // two process created
  int pid2=fork(); // total 4 process created
  // 1 parent and 3 three child
  if(pid > 0 && pid2 > 0){    
    //parent;
    wait(NULL);
  }

  else if(pid > 0 && pid2 == 0){
    //child
    int sum = add(array,argc-1);
    cout << "sum is : " << sum << endl;
    exit(0);
  }

  else if(pid == 0 && pid2 > 0){
    //1st grand child
    int average = avg(array,argc-1);
    cout << "average is : " << average << endl;
    exit(0);
  }
  else{
    //2nd grand child
    int maximum = max(array,argc-1);
    cout << "maximum is : " << maximum << endl;
    exit(0);
  }
}
