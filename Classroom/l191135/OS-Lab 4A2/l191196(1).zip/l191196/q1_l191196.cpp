#include<stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <fstream>
#define SIZE 200 // size 100 bytes
using namespace std;
int main(int argc, char *argv[]){
	
	int c;
    int buffer[100];
    int size=0;
    fstream fin(argv[1]);
    
    if(fin.is_open())
    {
      char c;
        while(!fin.eof())
        {
	  fin >> c;
	  buffer[size] = c;
	  size++;
	}
        buffer[size]='\0';
        fin.close();
    }
    
    int fd= shm_open("temp",O_RDWR|O_CREAT,0600);
    if  (fd <0){
        perror("shm_open()");
        return EXIT_FAILURE;
    }
    
    ftruncate(fd,SIZE);
    int *data=(int *)mmap(0,SIZE,PROT_READ ,MAP_SHARED,fd,0);
   	
   	for (int i=0; i< SIZE; ++i){
      if(buffer[i] % 2 == 1){
      	data[i] = ' '; 
      }
      else{
      	data[i] = buffer[i];
      }
    }
   	
   	int f = open(argv[1],'w');
   	write(f,data,SIZE);
   	close(f);
   	 munmap(data,SIZE);
    close(fd);
   	 shm_unlink("temp");
    return EXIT_SUCCESS;
    }
