#include <iostream>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include<string>
using namespace std;

string folder_name;

void *copyToFolder(void *file_name){
	string file = *(string *)file_name;
	string command = "cp "+ file + " " + folder_name;
	if(!access(folder_name.c_str(),F_OK)){
		system(command.c_str());
	}
	else{
		//cout << "such folder does not exists\n";
		string cmd = "mkdir " + folder_name;
		system(cmd.c_str());
		string command = "cp "+ file + " " + folder_name;
		system(command.c_str());
	}
	return NULL;
}
using namespace std;
int main(int argc, char *argv[]){

	// first argument is folder name
	// second argument is list.txt
	if(argc < 2){
		cout << "./q3 folderName list.txt\n";
	}
	else{

pthread_t array[100]; // max thread is 100
int t_count = 0;
folder_name = argv[1];
string line;
  ifstream in(argv[2]);
  if(in.is_open()){
    while(!in.eof()){
      getline(in,line);
      	pthread_create(&array[t_count++],NULL,&copyToFolder,&line);
	  cout << line;
	}	
	}
	for(int i=0; i< t_count; i++){
		pthread_join(array[i],NULL);
	}
	in.close();
	}
}	
