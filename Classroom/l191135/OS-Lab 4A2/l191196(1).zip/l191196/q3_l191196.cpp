#include <iostream>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>

using namespace std;
int refined_size; // size of after removing special character

int main(int argc, char *argv[]){
  int pid=fork(); // two process created
  int pid2=fork(); // total 4 process created
  // 1 parent and 3 three child
  
  int fd = open(argv[1],'r');
	struct stat sb;
	fstat(fd, &sb);
	int MAX_SIZE = sb.st_size;
	int buffer[MAX_SIZE];
  
  int fd1[2];
  int fd2[2];
  int fd3[2];
  if(pipe(fd1) == -1 || pipe(fd2) == -1){
    perror("pipe error\n");
    exit(EXIT_FAILURE);
  }
  
  if(pid > 0 && pid2 > 0){    
    //parent;
    int file = open(argv[1],'r');
    read(file,buffer,MAX_SIZE);
    close(fd1[0]);
    write(fd1[1],buffer,MAX_SIZE);
    wait(NULL); //wait for all children to complete their jobs
    cout << "task completed\n";
  }

  else if(pid > 0 && pid2 == 0){
    //child 1
    close(fd1[1]);
    read(fd1[0],buffer,MAX_SIZE);
    int array_size=0;
    for(int i=0; i< MAX_SIZE; i++){
    	if(buffer[i] >=0 && buffer[i] <=9){
    		array_size++;
    	}
    }
    
    refined_size = array_size;
    
    int array_of_int[array_size];
    for(int i=0; i< MAX_SIZE; i++){
    	if(buffer[i] >=0 && buffer[i] <=9){
    		array_of_int[index++] =buffer[i];
    	}
    }
    // special character has been removed
    close(fd2[0]);
    write(fd2[1],array_of_int,refined_size);
  }

  else if(pid == 0 && pid2 > 0){
    //child 2
   	int ordered_buffer[refined_size];
   	close(fd2[1]);
   	read(fd2,ordered_buffer,refined_size);
   	sort_ascending(ordered_buffer,refined_size);
   	close(fd3[0]);
   	write(fd3[1],ordered_buffer,refined_size);
   }
  else{
    //child 3
    close(fd3[1]);
    int last_buffer[refined_size];
    read(fd3[0],last_buffer,refined_size);
    // now write on the output.txt file
    int output = open("output.txt",'w');
    write(output,last_buffer,refined_size);
  }
}
