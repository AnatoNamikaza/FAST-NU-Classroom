#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main(int argc, char *argv[]){
  ifstream fin(argv[1]);
  if(fin.is_open()){
  char buffer[100];
  fin.getline(buffer,100,'\n');
  while(!fin.eof()){
    cout << buffer << endl;
    fin.getline(buffer,100,'\n');
  }
  }
  else{
    cout << "failed to open a file\n";
  }
}
