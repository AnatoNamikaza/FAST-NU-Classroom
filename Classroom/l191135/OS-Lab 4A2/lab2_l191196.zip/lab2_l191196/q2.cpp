#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
using namespace std;

void bubble_sort(int array[],int size);

int main(int argc, char *argv[]){
  int array[argc];
  for(int i=1; i < argc; i++){
    array[i-1] = atoi(argv[i]);
  }

  bubble_sort(array,argc);
  
 for(int i=1; i < argc; i++){
   cout << array[i-1] << " ";
  }
  return 0;
}


void bubble_sort(int array[],int size){
  for(int i=0; i< size-1; i++){
    bool swaped =false;
    for(int j=i; j < size; j++){
      if(array[i] > array[j]){
	// swap
	int temp = array[i];
	array[i] = array[j];
	array[j] = temp;
	swaped=true;
      }      
    }
    if(!swaped) return;
  }
}
