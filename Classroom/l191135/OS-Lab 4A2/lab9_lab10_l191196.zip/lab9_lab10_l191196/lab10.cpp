#include<iostream>
using namespace std;
#include <pthread.h>
#include<semaphore.h>
#include <stdlib.h>

void* multiplyMatrix(void* rows);


int matrix1_rows;
int matrix1_cols;
int matrix2_rows;
int matrix2_cols;

int** mat1;
int** mat2;
int** result;
sem_t s;

void display_result(){
  for(int i=0;i<matrix1_rows;i++){
      for(int j=0;j<matrix2_cols;j++){
	cout<<result[i][j]<<" ";
      }
      cout<<endl;
    }
}


void* multiplyMatrix(void* rows){
  int pa = *(int*)rows;
  sem_wait(&s);
  pa++;
  sem_post(&s);
  for(int i=0;i<matrix2_cols;i++)
    {
      int sum=0;
      for(int j=0;j<matrix2_rows;j++)
	{
	  sum+=mat1[pa][j]*mat2[j][i];
	}
      result[pa][i]=sum;
    }
  return NULL;
}


int main(int argc,char* argv[])
{
  cout<<"enter rows of matrix 1: ";
  cin>>matrix1_rows;
  cout<<"enter columns of matrix 1: ";
  cin>>matrix1_cols;
	
  cout<<"enter rows of matrix 2: ";
  cin>>matrix2_rows;
  cout<<"enter columns of matrix 2: ";
  cin>>matrix2_cols;
	
  if(matrix1_cols!=matrix2_rows)
    {
      cout<<"dimensions are not compatible"<<endl;
      exit(EXIT_FAILURE);
    }
	
  mat1=new int*[matrix1_rows];
  for(int i=0 ;i < matrix1_rows; i++){
      mat1[i]=new int[matrix1_cols];
    }
	
  mat2=new int*[matrix2_rows];
  for(int i=0;i<matrix2_rows;i++)
    {
      mat2[i]=new int[matrix2_cols];
    }
	
  int i=0;
  for(;i<matrix1_rows*matrix1_cols;i++)
    {
      mat1[i/matrix1_cols][i%matrix1_cols]=atoi(argv[i+1]);		
    }
	
  int j=0;
  for(;j<matrix2_rows*matrix2_cols;j++)
    {
      mat2[j/matrix2_cols][j%matrix2_cols]=atoi(argv[i+1]);
      i++;
    }
	
  for(int i=0;i<matrix1_rows;i++)
    {
      for(int j=0;j<matrix1_cols;j++)
	{
	  cout<<mat1[i][j]<<" ";
	}
      cout<<endl;
    }
  cout<<endl;
	
  for(int i=0;i<matrix2_rows;i++)
    {
      for(int j=0;j<matrix2_cols;j++)
	{
	  cout<<mat2[i][j]<<" ";
	}
      cout<<endl;
    }
  cout<<endl;
	
	
  result=new int*[matrix1_rows];
  for(int i=0;i<matrix1_rows;i++)
    {
      result[i]=new int[matrix2_cols];
    }
  pthread_t* t=new pthread_t[matrix1_rows];
  int rows;
  rows=0;
  sem_init(&s,0,1);
  for(int i=0;i<matrix1_rows;i++)
    {
      pthread_create(&t[i],NULL,&multiplyMatrix,&rows);
    }
  for(int i=0;i<matrix1_rows;i++)
    {
      pthread_join(t[i],NULL);
    }
	
  display_result();
}

