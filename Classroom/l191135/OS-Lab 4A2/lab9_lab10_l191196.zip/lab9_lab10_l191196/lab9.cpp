#include<iostream>
#include <sys/mman.h>
#include <sys/stat.h>        /* For mode constants */
#include <fcntl.h>           /* For O_* constants */
#include <sys/types.h>
#include <unistd.h>
#include<semaphore.h>
#include <sys/wait.h>
using namespace std;

int main(int argc, char *argv[]){
  struct stat sb1;
  struct stat sb2;

  const char* shm_file1="/shm_file1";
  const char* shm_file2="/shm_file2";

  sem_t mutex;

  int fd1=shm_open(shm_file1,O_RDWR|O_CREAT|O_EXCL,0600);
  if (fd1<0){
    perror("Shared memory error\n");
    exit(EXIT_FAILURE);
  }
  int file1=open(argv[1],O_RDONLY);
  fstat(file1, &sb1);
  char* buffer1=(char*)mmap(NULL, sb1.st_size, PROT_READ, MAP_SHARED,file1, 0);
	
  int fd2=shm_open(shm_file2,O_RDWR|O_CREAT|O_EXCL,0600);
  if (fd2 < 0){
    
    perror("Shared memory error\n");
    exit(EXIT_FAILURE);
  }
  int file2=open(argv[2],O_RDONLY);
  fstat(file2, &sb2);
  char* data2=(char*)mmap(NULL, sb2.st_size, PROT_READ, MAP_SHARED,file2, 0);

  sem_init(&mutex,0,1);
  int pid=fork();
  if(pid==0){
    int sum=0;
    sem_wait(&mutex);
    char int_array[100];
    char int_sign;
    int i=0;
    int_sign=buffer1[i];
    int k=0;
    while(int_sign =='+'|| int_sign=='-'){	
      int j=0; i++;
      
      while(buffer1[i]>='0' && buffer1[i]<='9'){
	int_array[j]=buffer1[i];
	i++;j++;
      }
      int_array[j]='\0'; i++;
	  
      int net_profit=atoi(int_array);
      if(int_sign=='+'){
	sum= sum + net_profit;
      }
      else
	{
	  sum-=net_profit;
	}
      int_sign=buffer1[i];
      k++;
    }
    sem_post(&mutex);
    cout<<"Total Revenue of 2017: "<<sum<<endl;

  }
  else
    {
      wait(NULL);
      int sum=0;
      sem_wait(&mutex);
      char int_array[100];
      char int_sign;
      int i=0;
      int_sign=data2[i];
      int k=0;
      while(int_sign=='+'||int_sign=='-'){	
	int j=0;
	i++;
	while(data2[i]>=47 && data2[i]<=57)
	  {
	    int_array[j]=data2[i];
	    i++;
	    j++;
	  }
	int_array[j]='\0';
	i++;
	int net_profit=atoi(int_array);
	if(int_sign=='+')
	  {
	    sum+=net_profit;
	  }
	else
	  {
	    sum-=net_profit;
	  }
	int_sign=data2[i];
	k++;
      }
      sem_post(&mutex);
      cout<<"Total Revenue of 2018: "<<sum<<endl;	
    }
  
  munmap(buffer1,sb1.st_size);
  munmap(data2,sb2.st_size);

  shm_unlink(shm_file1);
  shm_unlink(shm_file2);

  close(file1);
  close(file2);

  close(fd1);
  close(fd2);
}
