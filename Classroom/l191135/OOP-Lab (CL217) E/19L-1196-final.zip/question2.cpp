#include <iostream>
#include <math.h>
using namespace std;

class DessertItem{
protected:
  char* name;
public:
  DessertItem(){
    name = NULL;
  }
  DessertItem(const char* _name){
    int lenght=0;
    while(_name[lenght++]);
    name = new char[lenght];
    for(int i=0; i<= lenght; i++){
      name[i]=_name[i]; // last null char has been copied
    }
  }

  void setName(char* _name){
    int lenght=0;
    while(_name[lenght++]);
    for(int i=0; i<= lenght; i++){
      name[i]=_name[i]; // last null char has been copied
    }
  }

  char* getName(){
    return name;
  }

  virtual int getCost()=0;
  ~DessertItem(){
    if(name !=0) delete []name;
  }
  
  virtual int getTax(int _taxrate) =0;
  
};
//==============================
class Cookie: public DessertItem{
protected:
  int number;
  int price_per_dozen;
  
public:
  Cookie():DessertItem(){}
  Cookie(int _number, int _ppd):
    DessertItem("Cookie")
  {
    number = _number;
    price_per_dozen = _ppd;
  }
  //-------------------
  int getCost(){
    return round((double )(number/12.0)* price_per_dozen);
  }
  //-------------------
  int getTax(int _taxrate){
    return round(getCost()*(double)( _taxrate/100.0));
  }
};
//==============================
class IceCream: DessertItem{
protected:
  int cost;
  char* flavor_name;
public:
  IceCream():DessertItem(){}
  IceCream(int cost, char* _flavor_name):DessertItem("IceCream"){
    int lenght=0;
    while(_flavor_name[lenght++]);
    flavor_name = new char[lenght];
    for(int i=0; i<= lenght; i++){
      flavor_name[i]=_flavor_name[i]; // last null char has been copied
    }
  }
  //----------------
  char* getFlavorName(){
    return flavor_name;
  }
  //----------------
  int getCost(){
    return cost;
  }
  int getTax(int _taxrate){
    return round((double )(cost*_taxrate/100.0));
  }
};
//======================
class Sundae: public IceCream{
protected:
  int topping_cost;
public:
  Sundae():IceCream(){}
  Sundae(int _cost, char* _flavor_name, int _topping_cost):IceCream(_cost,_flavor_name){
    topping_cost = _topping_cost;
  }
  //==================
  int getToppingCost(){
    return topping_cost;
  }
};
//==========================
class Order{
private:
  DessertItem** itemsList;
  int noOfItems;
public:
  Order(){
    itemsList= NULL;
    noOfItems=0;
  }
  Order(int _no_of_items){
    noOfItems = _no_of_items;
    itemsList = new DessertItem* [noOfItems];
  }
  //-----------------------
  void placeOrder(){
    int userChoice;
    int i=0, itemCount=0;
    while(i< this->noOfItems){
      cout<<"Choose Item you want to add\n";
      cin>>userChoice;
      if(userChoice==1){
	//take parameters from user needed for a Cookie
	int no_of_cookies=0;
	int cookies_rate=0;
	cout << "Enter no of cookies: ";
	cin >> no_of_cookies;
	cout << "Enter price per dozen: ";
	cin >> cookies_rate;
	itemsList[itemCount++]= new Cookie(no_of_cookies,cookies_rate);
	//making base class pointer //point cookie object
      }
      else if(userChoice==2){
	//take parameters from user needed for an IceCream
	int cost;
	char flavor_name[20];
	cout << "enter cost: ";
	cin >> cost;
	cout << "Enter flavor name: ";
	cin >> flavor_name;
	itemsList[itemCount++]=(DessertItem*) new IceCream(cost,flavor_name);
	//making base class pointer //point IceCream object
      }
      else if(userChoice==3){
	//take parameters from user needed for a Sundae
	int cost;
	char flavor_name[20];
	int topping_cost;
	cout << "enter cost: ";
	cin >> cost;
	cout << "Enter flavor name: ";
	cin >> flavor_name;
	cout << "Enter topping cost: ";
	cin >> topping_cost;
	itemsList[itemCount++]= (DessertItem*) new IceCream(cost,flavor_name);
	//
	itemsList[itemCount++]= (DessertItem*) new Sundae(cost,flavor_name,topping_cost);
	//making base class pointer //point Sundae object
      }
      i++;

    }
  }
};


int main(){

  return 0;
  
}

