#include <iostream>
using namespace std;
class CompactMatrix{
private:
  int rows;
  int** mat;
public:
  CompactMatrix(){
    rows=0;
    mat=NULL;
  }
  CompactMatrix(int** _matrix, int _rows, int _cols){
    rows = _rows;
    mat = new int*[rows];
    for(int row=0; row < _rows; row++){
      int element_counter=0;
      for(int col=0; col < _cols; col++){
	if(_matrix[row][col] !=0){
	  element_counter++;
	}
      }
      mat[row] = new int[2*element_counter+1];
      mat[row][0] = element_counter;
    }
    //----------------- memory has been allocated
    for(int row=0; row < _rows; row++){
      int col_counter=1;
      for(int col=0; col < _cols; col++){
	if(_matrix[row][col] !=0){
	  mat[row][col_counter++] = col;
	  mat[row][col_counter++] = _matrix[row][col];
	}
      }
      cout << endl;
    }
  }
  //========================
  int get_rows(){
    return rows;
  }
  //========================
  friend ostream &operator <<(ostream &out, CompactMatrix &_compactMatrix){
    int rows = _compactMatrix.rows;
    for(int i=0; i< rows; i++){
      for(int j=1; j< _compactMatrix.mat[i][0]; j++){
	out << _compactMatrix.mat[i][2*j] << " ";
      }
      out << "\n";
    }
    return out;
  }
  
  ~CompactMatrix(){
    for(int i=0; i< rows; i++){
      delete [] mat[i];
    }
    delete mat;
    mat=NULL;
  }

};

int main(){
  
const int rows = 3, cols = 7;
int m1[rows][cols] = { {3,0,0,1,0,0,0},{0,0,9,0,0,0,0},{7,12,9,0,8,2,8} };
int m2[rows][cols] = { {0,0,0,1,2,0,8},{ 0,0,0,0,0,0,0},{ 7,0,3,0,2,0,0} };
int *matrix1[rows]; int *matrix2[rows]; //array of pointers same as int**
for (int i = 0; i < rows; i++) {
matrix1[i] = m1[i];
matrix2[i] = m2[i];
}
CompactMatrix compactMatrix1(matrix1, rows, cols);
CompactMatrix compactMatrix2(matrix2, rows, cols);
cout<< compactMatrix1<<endl;
cout << "\n\n + \n\n";
cout<< compactMatrix2<<endl;
cout << "\n\n = \n\n";
  return 0;
}
