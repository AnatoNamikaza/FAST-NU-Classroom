#include "geometry.h"
#include <iostream>
//19L-1196 Cs-2E1

Point::Point(int a, int b){
  x=new int;
  y=new int;
  *x=a;
  *y=b;
}

void Point::print_point(){
  std::cout << "x: "  << *x << " ";
  std::cout << "y: " <<*y << " " << std::endl;
}

int Point::get_x(){return *x;}

int Point::get_y(){return *y;}

void Point::set_x(int a){
  delete x;
  x= new int;
  *x=a;
}
void Circle::print_circle(){
  std::cout << "radius: " << *radius << " ";
  this->print_point();
}

void Point::set_y(int b){
  delete y;
  y= new int;
  *y=b;
}

Point::~Point(){
  delete x;
  delete y;
  *x=0; *y=0;
}


//Circle::Circle(float r, int a, int b):coordinate(a,b),radius(r);
Circle::Circle(float r, int a, int b):Point(a,b)
{
radius = new float;
 *radius=r;
 Point p(a,b);
 //coordinate = &p;
 coordinate = new Point(a,b);

}
float Circle::get_radius(){return *radius;}
//int Circle::get_x(){return coordinate->get_x();}
//int Circle::get_y(){return coordinate->get_y();}
bool Circle::CheckOnCircle(Point &p){
  int x_dis, y_dis;
  x_dis = (this->get_x()-p.get_x()) * (this->get_x()-p.get_x());
  y_dis = (this->get_y() -p.get_y()) * (this->get_y() - p.get_y());
  int dis= x_dis+y_dis;
  return(dis < (*this->radius)*(*this->radius));
}
Circle::~Circle(){
  delete radius;
  delete coordinate;
  radius=0;
  coordinate=0;
}
//---------------------
Cylinder::Cylinder(int h, float r1, int x1,int y1, float r2, int x2, int y2){
  //Circle t(r1,x1,y1);
  //Circle b(r2, x2,y2);
  height=h;
  top = new Circle(r1,x1,y1);
  bottom = new Circle(r2, x2,y2);
  //top = &t;
  //bottom = &b;

} 

void Cylinder::print_top(){
  std::cout << "info for top is...\n";
  //std::cout << this->top->get_y();
  (this->top)->print_circle();
}

void Cylinder::print_bottom(){
  std::cout << "info for bottom is...\n";
  this->bottom->print_circle();
}

void Cylinder::print_cylinder(){
  std::cout << "height: " << this->height << " " << std::endl;
  std::cout << "info for top... \n";
  this->top->print_circle();
  std::cout << "info for bottom... \n";
  this->bottom->print_circle();
}

bool Cylinder::CheckOnCylinder(Point &p){
  // if point's x-axis is cylinder
  return (this->top->CheckOnCircle(p) && this->bottom->CheckOnCircle(p));
}

Cylinder::~Cylinder(){
  //height is not a pointer
  delete top;
  delete bottom;
  top =0;
  bottom=0;

}
