#include <iostream>
using namespace std;
#include "geometry.h"
//19L-1196 Cs-2E1
int main(){
  Point p1(2,4);
  //p1.print_point();

  Circle c1(5.3,2,3);
  // c1.print_circle();

  Cylinder cl1(7,5.3,2,9,5.3,2,3);
  //c.print_cylinder();
   cl1.CheckOnCylinder(p1);
   return 0;
   
}
