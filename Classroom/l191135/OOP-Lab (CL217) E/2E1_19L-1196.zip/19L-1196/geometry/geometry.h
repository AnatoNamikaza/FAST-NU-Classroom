/*classPoint{ private: int* x;  int* y; public: //Constructors, Getters and Destructor }; classCircle{ private: float* radius;  point* coordinate; public: Constructors, Getters, Destructor boolCheckOnCircle(point& p1)- //Returns true if point lies in circle,    // false otherwise}; classCylinder{ private: int height; circle* top; //Circle on top of Cylinder  circle* bottom; //Circle on bottom of Cylinder public: //Constructors, Destructors bool CheckOnCylinder(point& p1) //Returns true if point lies in cylinder, false otherwise }; 
  */
#ifndef _GEOMETRY_H
#define _GEOMETRY_H
//19L-1196 Cs-2E1
  class Point {
  private:
    int* x;
    int* y;
  public:
Point(int, int);
 void print_point();
 int get_x();
 int get_y();
 void set_x(int);
 void set_y(int);
 ~Point();
  };

class Circle: public Point{
  private:
    float* radius;
    Point* coordinate;
  public:
    Circle(float, int, int);
    
    float get_radius();
    bool CheckOnCircle(Point &p);
    void print_circle();
    ~Circle();
  };

class Cylinder{
 private:
  int height;
  Circle* top;
  Circle* bottom;
 public:
  
  Cylinder(int,float,int, int, float,int,int);
  void print_top();
  void print_bottom();
  void print_cylinder();
  bool CheckOnCylinder(Point &);
  ~Cylinder();
};
#endif
