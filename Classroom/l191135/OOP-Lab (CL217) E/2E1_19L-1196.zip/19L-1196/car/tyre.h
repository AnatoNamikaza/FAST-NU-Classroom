#include <iostream>
using namespace std;

#ifndef _TYRE_H
#define _TYRE_H

class Tyre{
private:
int *width;
int *aspect_ratio;
int *diameter;
public:
Tyre();
Tyre(int, int, int);
void set_width(int);
void set_aspect_ratio(int);
void set_diameter(int);

int get_width();
int get_aspect_ratio();
int get_diameter();

void printTyre();

~Tyre();
};

class Car{
private:
int* model;
char* company;
Tyre* t1;
public:
Car();
Car(int,const char*,Tyre &);
//Car(const Tyre &);
void set_model(int);
void set_company(const char*);
void set_tyre(Tyre &);

int get_model();
char* get_company();
Tyre get_tyre();

~Car();

};

#endif
