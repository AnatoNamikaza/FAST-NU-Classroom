#include "tyre.h"
//19L-1196
int main(){
  Tyre tNew(12, 10, 13);
Car cNew(2016,"Honda",tNew);
return 0;
}
