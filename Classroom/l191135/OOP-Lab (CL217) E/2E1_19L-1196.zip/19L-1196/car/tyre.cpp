
#include "tyre.h"

Tyre::Tyre(){
  width=0;
  aspect_ratio=0;
  diameter=0;
 }
Tyre::Tyre(int w, int ar, int d){
  width = new int;
  aspect_ratio = new int;
  diameter = new int;

  *width = w;
  *aspect_ratio = ar;
  *diameter = d;
}
/*
Tyre Tyre::Tyre(const Tyre &obj){
  width = new int;
  aspect_ratio = new int;
  diameter = new int;

  *width = w;
  *aspect_ratio = ar;
  *diameter = d;

}
*/
void Tyre::set_width(int w){
  delete width;
  *width=w;
}
void Tyre::set_aspect_ratio(int ar){
  delete aspect_ratio;
  *aspect_ratio = ar;
}
void Tyre::set_diameter(int d){
  delete diameter;
  *diameter = d;
}

int Tyre::get_width(){
  if(this->width !=0)
  return *this->width;
  cout << "not assigned yet ... \n";
}
int Tyre::get_aspect_ratio(){
  if(this->aspect_ratio !=0)
  return *this->aspect_ratio;
  cout << "not assigned yet ... \n";
}
int Tyre::get_diameter(){
  if(this->diameter !=0)
  return *this->diameter;
  cout << "not assigned yet ... \n";
}

void Tyre::printTyre(){
  cout << "width: " << *this->width << endl;
  cout << "aspect ratio: " << *this->aspect_ratio << endl;
  cout << "diameter: " << *this->diameter << endl;
}

Tyre::~Tyre(){
  delete width;
  delete aspect_ratio;
  delete diameter;
}

Car::Car(){
  model = 0;
  company=0;
  t1=0;
}

Car::Car(int m, const char *c, Tyre &t){
  int size=0;
  while(c[size++] !='\0');

  if(this->model == 0){
    // allocate memory for all variables
    model = new int;
    company = new char [size];
    for(int i=0; i< size; i++) company[i]=c[i];
    this->company[size]='\0';
    t1 = new Tyre(t);
  }
}

void Car::set_model(int m){
  if(this->model !=0)
    delete this->model;
  *this->model = m;
}

void Car::set_company(const char *c){
  if(this->company !=0)
    delete this->company;
  int size=0;
  while(c[size++] !='\0');
      company = new char [size];
    for(int i=0; i< size; i++) company[i]=c[i];
    this->company[size]='\0';
}

void Car::set_tyre(Tyre &t){
  if(this->t1 !=0)
    delete t1;
  t1 = new Tyre(t);
}

int Car::get_model(){
  if(this->model !=0)
  return *this->model;
}

char* Car::get_company(){
  if(this->company != 0)
    return this->company;
}

Tyre Car::get_tyre(){
  if(this->t1 !=0)
    return *this->t1;
}

Car::~Car(){
  //delete model;
  delete company;
  //delete t1;
  
}
