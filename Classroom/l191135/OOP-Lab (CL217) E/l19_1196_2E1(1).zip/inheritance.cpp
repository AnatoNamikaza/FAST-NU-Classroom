#include <iostream>
using namespace std;

class Person{
private:
  char* fName;
  char* lName;
protected:
  int age;
public:

  Person(const char* fn, const char* ln, int a){

    int index=0;
    while(fn[index++]);
    this->fName = new char[index];
    for(int i=0; i< index; i++) this->fName[i] = fn[i];
    this->fName[index] = '\0';

    index=0;
    while(ln[index++]);
    this->lName = new char[index];
    for(int i=0; i< index; i++) this->lName[i] = ln[i];
    this->lName[index] = '\0';

      age = a;
      cout << "Persion(parameters list) called\n";
  }
  
  char* getFirstName(){
    return fName;
  }

  char* getLastName(){
    return lName;
  }

    void printInformation(){
      cout << fName << " " << lName;
      cout << "is " << age << " old " << endl;
    
  }

  // virtual void printInformation()=0;

~Person(){
    if(fName !=0){
      delete []fName;
      delete []lName;
    }
    cout << "~Person called\n";
  }

};


class Student: public Person{
private:
  float cgpa;

public:
  Student(const char* fn,const  char*ln, int a, float CGPA):
    Person(fn,ln,a),cgpa(CGPA){
    cout << "Student(parameters list) called\n";
  }
  /*
void printInformation(){
    Person::printInformation();
    cout << "CGPA: " << cgpa << endl;
  }
  */

  char* getFirstName(){return Person::getFirstName();}
  char* getLastName(){return Person::getLastName();}


   void printInformation(){
     cout << Person::getFirstName() << " " << Person::getLastName();
     cout << " is " << age <<  " years old  and has gpa " << cgpa << endl;
   }


  ~Student(){
    cout << "~Student() called\n";
  }
};

class Undergraduate: public Student{
private:
  char* fyp;

public:
  Undergraduate(const char* fn, const char* ln, int a, float CGPA, const char* FYP):
    Student(fn, ln, a,CGPA)
{
  int index=0;
  while(FYP[index++]);
  this->fyp = new char[index];
  for(int i=0; i< index; i++) this->fyp[i] = FYP[i];
    this->fyp[index] = '\0';
    
    cout << "Undergraduate(parameters list) called\n";
  }

  void printInformation(){
     Student::printInformation();
    cout << " and his first year project is : " << fyp << endl;
  }
  ~Undergraduate(){


    if(fyp !=0){
      delete []fyp;
    }
    cout << "~Undergraduate called\n";
  }
};

class Graduate: public Student{
private:
  char* thesis;
public:
  Graduate(const char* fn, const char* ln, int a, float CGPA, const char* t):
    Student(fn, ln, a,CGPA)
{
  int index=0;
  while(t[index++]);
  this->thesis = new char[index];
  for(int i=0; i< index; i++) this->thesis[i] = t[i];
    this->thesis[index] = '\0';
    cout << "Graduate(parameters list) called\n";
  }
  void printInformation(){
    Student::printInformation();
    cout << "Thesis: " << thesis << endl;
  }
  ~Graduate(){
    if(thesis !=0){
      delete []thesis;
    }
    cout << "~Graduate called\n";
  }

};


class Faculty: public Person{
private:
  int course_count;
  int extension;
public:
  Faculty(const char* fn, const char* ln, int age, int cc,int ext):
    Person(fn,ln,age),course_count(cc),extension(ext){
    cout << "Faculty(parameters list) called\n";
  }
  int get_course_count(){return course_count;}
  int get_ext(){return extension;}

  void printInformation(){
    Person::printInformation();
    cout << "Course-Count " << course_count << endl;
    cout << "enxtension number is: " << extension << endl;
  }
  
  void set_course_count (int c){course_count =c;}
  void set_extension(int e){extension = e;}
  //  void printInformation(){
  //   cout << "first Name: " << Person::xgetFirstName() << endl;
  //   cout << "last Name: " << Person::getLastName() << endl;
  //   cout << "age: " << age << endl; // is protected var
  //   cout << "Course-counts " << course_count << endl;
  //   cout << "extensions: " << extension << endl;
  // }

  ~Faculty(){
    cout << "~Faculty called\n";
  }

};

class TA: public Undergraduate, public Faculty{
public:
  TA(const char* fn, const char* ln, int a, float CGPA, const char* FYP, int cc, int ext):Undergraduate(fn,ln,a,CGPA,FYP),Faculty(fn,ln,a,cc,ext)
  {
    Faculty::set_course_count(cc);
    Faculty::set_extension(ext);
    cout << "Ta(parameters list) called\n";
  }
  
  void printInformation(){
    Undergraduate::printInformation();
    cout << "course-count " << get_course_count() << endl;
    cout << "extension no: " <<get_ext() << endl;
  }

  ~TA(){
    cout << "~TA() called\n";
  }
};


int main(){
  // Person p1("zaeem","yousaf",25);
  // p1.printInformation();
  // Student s1("askar","hussain",22,3.95);
  // s1.printInformation();
  // Undergraduate u1("allama","iqbal", 30, 3.99, "poetry");
  // u1.printInformation();
  // Graduate g1("quaid","azim", 60, 2.25, "formation of pakistan");
  // g1.printInformation();
  TA t1("abdul","wahab",30,3.75, "game",2,302);
  t1.printInformation();
}

