#include <iostream>
#include "inheritance.cpp"
using namespace std;
int main(){
  Undergraduate u1("Ted","thompson",22,3.91,"game");
  Faculty f1("Richard","Karp",45,2,420);
  /*
Persion(parameters list) called
Student(parameters list) called
Undergraduate(parameters list) called
Persion(parameters list) called
Faculty(parameters list) called
~Faculty called
~Person called
~Undergraduate called
~Student() called
~Person called
  */

}
