import pandas as pd
import numpy as np

Year = [2015, 2016, 2017, 2018, 2019, 2020, 2021, 2022, 2023]
Levels = ['PhD', 'Masters', 'Masters, PhD']
Type = ['International', 'Local', 'Local']
Category = ['Merit Based', 'Need Based', 'Merit & Need Based']
Age = [25, 27, 29, 30, 33, 35, -0.1, -0.1, -0.1]
Marks = [60, 66, 75, 85, -0.1]
Scholarship = [60, 70, 80, 90, 100, -0.1, -0.1]
Family_Income = [50, 100, 150, 200, -0.1]
Approved = ['Yes', 'Yes', 'No']

t_size = 5432
df = pd.DataFrame()
df["Year"] = np.random.choice(Year, size= t_size)
df["Levels"] = np.random.choice(Levels, size= t_size)
df["Type"] = np.random.choice(Type, size= t_size)
df["Category"] = np.random.choice(Category, size= t_size)
df["Age"] = np.random.choice(Age, size= t_size)
df["Marks"] = np.random.choice(Marks, size= t_size)
df["Scholarship"] = np.random.choice(Scholarship, size= t_size)
df["Family_Income"] = np.random.choice(Family_Income, size= t_size)
df["Approved"] = np.random.choice(Approved, size= t_size)


print(df)
df = df.replace(-0.1, np.nan)
df.to_csv('S_Data.csv', index=False)