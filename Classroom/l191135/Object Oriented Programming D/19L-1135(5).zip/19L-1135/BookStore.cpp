#include<iostream>
#include<string>
using namespace std;

//===================================================================================================================================================
//===================================================================================================================================================
//===================================================================================================================================================
//===================================================================================================================================================

class Author {
private:
	char* Name{};
	int Age;
	char* gender{};
public:

	//    Author() {
	//        Name = nullptr;
	//        gender = nullptr;
	//        Age = 0;
	//    }
	static int Authorlistpresent;    //To store the total no. of Authors;

	Author(const char* name = nullptr, int age = 0, const char* gender = nullptr) {
		if (name != nullptr) {
			int size = 0;
			for (int i = 0; name[i] != '\0'; i++) {
				size++;
			}
			size++;
			for (int i = 0; i < size; i++) {
				this->Name[i] = name[i];
			}
			this->Age = age;
			size = 0;
			for (int i = 0; gender[i] != '\0'; i++) {
				size++;
			}
			size++;
			for (int i = 0; i < size; i++) {
				this->gender[i] = gender[i];
			}
		}
		Authorlistpresent++;
	}

	static int GetAuthorlist() {
		return Authorlistpresent;
	}

	char* GetName() {
		return Name;
	}

	static bool compare(const char* p, const char* &q) {
		bool value = true;
		int size = 0;
		for (int i = 0; p[i] != '\0'; i++) {
			size++;
		}
		size++;
		for (int i = 0; i < size; i++) {
			if (p[i] == q[i]) {}
			if (p[i] != q[i]) {
				return value = false;
			}
		}
		return value;

	}

	void copy(const Author &p) {
		//        int size = 0;
		//        for (int i = 0; p.Name[i] != '\0'; i++) {
		//            size++;
		//        }
		//        size++;
		int x = p.Age;
		UpdateAge(x);
		UpdateName(p.Name);
		UpdateGender(p.gender);
		//        Name = new char[size];
		//        for (int i = 0; i < size; i++) {
		//            Name[i] = p.Name[i];
		//        }
		//        size = 0;
		//        for (int i = 0; p.gender[i] != '\0'; i++) {
		//            size++;
		//        }
		//        size++;
		//        gender = new char[size];
		//        for (int i = 0; i < size; i++) {
		//            gender[i] = p.gender[i];
		//        }

	}

	void UpdateAge(int &x) {
		this->Age = x;
	}

	void UpdateName(char* name) {
		int size = 0;
		for (int i = 0; name[i] != '\0'; i++) {
			size++;
		}
		size++;
		Name = new char[size];
		for (int i = 0; i < size; i++) {
			this->Name[i] = name[i];
		}
	}

	void UpdateGender(char* gender) {
		int size = 0;
		for (int i = 0; gender[i] != '\0'; i++) {
			size++;
		}
		size++;
		this->gender = new char[size];
		for (int i = 0; i < size; i++) {
			this->gender[i] = gender[i];
		}
	}

	void UpdateInfo() {
		cout << "Enter Name: \n";
		char* author;
		author = new char[20];
		cin.ignore(5, '\n');
		cin.clear();
		cin.getline(author, 20);
		int size = 0;
		for (int i = 0; author[i] != '\0'; i++) {
			size++;
		}
		size++;
		Name = new char[size];
		for (int i = 0; i < size; i++) {
			this->Name[i] = author[i];
		}
		cout << "Enter Gender: \n";
		char* gene;
		gene = new char[8];

		cin.getline(gene, 8);
		size = 0;
		for (int i = 0; gene[i] != '\0'; i++) {
			size++;
		}
		size++;
		this->gender = new char[size];
		for (int i = 0; i < size; i++) {
			this->gender[i] = gene[i];
		}
		cout << "Enter Age: \n";
		int age;
		cin >> age;
		this->Age = age;
		delete[] author;
		author = nullptr;
		delete[] gene;
		gene = nullptr;
		age = 0;
	}

	void printData() {
		cout << "( Name: " << this->Name << ", Age: " << this->Age << ", Gender: " << this->gender << " )" << endl;
	}

	~Author() {
		delete[] Name;
		Name = nullptr;
		delete[] gender;
		gender = nullptr;
		Age = 0;
	}
};

int Author::Authorlistpresent = 0;

//===================================================================================================================================================
//===================================================================================================================================================
//===================================================================================================================================================
//===================================================================================================================================================

class Book {
private:
	char* Title;
	float price;
	char* genre;
	Author* Authors;
public:

	static int Booklist;    //To store the total no. of Books;

	/*Book() {
		Title = "\0";
		price = "\0";
		genre = "\0";
		Authors = NULL;
		noOfBooks = 0;
	}*/

	Book(const char* title = nullptr, float price = 0, const char* genre = nullptr) {
		if (title != nullptr) {
			int size = 0;
			for (int i = 0; title[i] != '\0'; i++) {
				size++;
			}
			size++;
			for (int i = 0; i < size; i++) {
				this->Title[i] = title[i];
			}
			size = 0;
			for (int i = 0; genre[i] != '\0'; i++) {
				size++;
			}
			size++;
			for (int i = 0; i < size; i++) {
				this->genre[i] = genre[i];
			}
			size = 0;
			cout << "Enter no of Authors of Book: \n";
			cin.ignore(2, '\n');
			cin.clear();
			cin >> size;
			Authors = new Author[size];
			for (int i = 0; i < size; i++) {
				Authors[i].UpdateInfo();
			}
			this->price = price;
		}
		Booklist++;
	}

	void Copy(const Book &B2) {
		int size = 0;
		for (int i = 0; B2.Title[i] != '\0'; i++) {
			size++;
		}
		size++;
		Title = new char[size];
		for (int i = 0; i < size; i++) {
			this->Title[i] = B2.Title[i];
		}
		this->price = B2.price;
		size = 0;
		for (int i = 0; B2.genre[i] != '\0'; i++) {
			size++;
		}
		size++;
		this->genre = new char[size];
		for (int i = 0; i < size; i++) {
			this->genre[i] = B2.genre[i];
		}
		size = Author::GetAuthorlist();
		Authors = new Author[size];
		for (int i = 0; i < size; i++) {
			Authors[i].copy(B2.Authors[i]);
		}
	}

	char* &GetTitle() {
		return Title;
	}

	char* &GetGenre() {
		return genre;
	}

	float GetPrice() {
		return price;
	}

	static bool compare(char* &p, char* &q) {
		bool value = true;
		int size = 0;
		for (int i = 0; p[i] != '\0'; i++) {
			size++;
		}
		size++;
		for (int i = 0; i < size; i++) {
			if (p[i] == q[i]) {}
			else {
				return value = false;
			}
		}
		return value;

	}

	void UpdateInfo() {
		cout << "Enter Title: \n";
		char* title;
		title = new char[40];
		cin.ignore(2, '\n');
		cin.clear();
		cin.getline(title, 40);
		int size = 0;
		for (int i = 0; title[i] != '\0'; i++) {
			size++;
		}
		size++;
		Title = new char[size];
		for (int i = 0; i < size; i++) {
			this->Title[i] = title[i];
		}
		cout << "Enter Genre: \n";
		char* GenrNam;
		GenrNam = new char[14];
		cin.getline(GenrNam, 14);
		size = 0;
		for (int i = 0; GenrNam[i] != '\0'; i++) {
			size++;
		}
		size++;
		this->genre = new char[size];
		for (int i = 0; i < size; i++) {
			this->genre[i] = GenrNam[i];
		}
		cout << "Enter Price: \n";
		float pric;
		cin >> pric;
		this->price = pric;
		size = 0;
		cout << "Enter No. of Authors of Book: \n";
		cin >> size;
		this->Authors = new Author[size];
		for (int i = 0; i < size; i++) {
			cout << "Info of Author#" << i + 1 << ": \n";
			Authors[i].UpdateInfo();
		}
		delete[] title;
		title = nullptr;
		delete[] GenrNam;
		GenrNam = nullptr;

	}

	void getPrice() {
		cout << "Price of Book: " << this->price << endl;
	}

	bool SearchAuthor(const char* AuthorName = nullptr) {
		int AuthorNo = Author::GetAuthorlist();

		for (int i = 0; i < AuthorNo; i++) {
			if (Author::compare(Authors[i].GetName(), AuthorName)) {
				return true;
				break;
			}
			else {
				return false;
			}
		}
		return false;
	}

	static int GetBooklist() {
		return Booklist;
	}

	static void SetBooklist(int v) {
		Booklist = v;
	}

	void printData() {
		int AuthorNo = Author::GetAuthorlist();
		cout << "( Title: " << this->Title << ", Price: " << this->price << ", Genre: " << this->genre << " )" << endl;
		cout << "Authors:" << endl;
		for (int i = 0; i < AuthorNo; i++) {
			Authors[i].printData();
		}
	}

	~Book() {
		delete[] Title;
		Title = nullptr;
		price = 0;
		delete[] genre;
		genre = nullptr;
		if (Authors != nullptr) {
			delete[] Authors;
			Authors = nullptr;
		}
	}
};

int Book::Booklist = 0;
//===================================================================================================================================================
//===================================================================================================================================================
//===================================================================================================================================================
//===================================================================================================================================================

class BookStore {
private:
	Book* listofBooks;
	float totalSales;

public:
	/*BookStore() {
		listofBooks = NULL;
		totalSales = 0;
	}*/

	BookStore(float Sales = 0) {
		totalSales = Sales;
		int size = 0;
		cout << "Enter no of Books in the BookStore: \n";
		cin >> size;
		if (size == 1) {
			listofBooks = new Book[size];
			for (int i = 0; i < size; i++) {
				listofBooks[i].UpdateInfo();
			}
		}
		if (size > 1) {
			listofBooks = new Book[size];
			for (int i = 0; i < size; i++) {
				cout << "Info of Book#" << i + 1 << " : " << endl;
				cin.ignore(3, '\n');
				cin.clear();
				listofBooks[i].UpdateInfo();
			}
		}
	}

	void addBook() {
		Book* temp;
		//newBook.UpdateInfo();
		int size = Book::GetBooklist();
		temp = new Book[size + 1];
		for (int i = 0; i < size; i++) {
			temp[i].Copy(listofBooks[i]);
		}
		temp[size].UpdateInfo();
		///qovbewhhhhhhhhhhhhhhhhhhhhhhhhhbvevhqobwrehvboqehrvbweorhvbqerovbqe
		delete[] listofBooks;
		listofBooks = new Book[size + 1];
		for (int i = 0; i < size + 1; i++) {
			listofBooks[i].Copy(temp[i]);
		}
		delete[] temp;
		temp = nullptr;
	}

	void sellBook(char* BookTitle = nullptr) {

		bool Ser = false;
		int size = Book::GetBooklist();
		for (int i = 0; i < size; i++) {
			Ser = Book::compare(listofBooks[i].GetTitle(), BookTitle);
			if (Ser) {
				AddPrice(totalSales, listofBooks[i].GetPrice());
				listofBooks[i].GetTitle() = nullptr;
				cout << BookTitle << " has been sold successfully. \n";
				cout << listofBooks[i].GetPrice() << " has been added to your account. \n";
			}
		}
		RemoveExtraBooks(size);
	}

	void RemoveExtraBooks(int &size) {
		Book* temp;
		//newBook.UpdateInfo();
		int lastsize = size;
		temp = new Book[size];
		for (int i = 0; i < size; i++) {
			temp[i].Copy(listofBooks[i]);
		}

		for (int i = 0; i < size; i++) {
			if (listofBooks[i].GetTitle() == nullptr) {
				int j = i;
				for (; j < size; j++) {
					listofBooks[j].Copy(listofBooks[j + 1]);
				}
				lastsize--;
			}
		}
		delete[] listofBooks;
		listofBooks = new Book[lastsize];
		for (int i = 0; i < lastsize; i++) {
			listofBooks[i].Copy(temp[i]);
		}
		delete[] temp;
		temp = nullptr;
	}

	static int GetNoOfBooks() {
		int size = Book::GetBooklist();
		return size;
	}

	static void AddPrice(float &p, float q) {
		p = p + q;
	}

	bool SearchBook(char* BookTitle = nullptr) {
		int Searchlist = Book::GetBooklist();
		for (int i = 0; i < Searchlist; i++) {
			if (Book::compare(listofBooks[i].GetTitle(), BookTitle)) {
				return true;
				break;
			}
			else {
				return false;
			}
		}
		return false;
	}

	void printAllBooks() {
		int size = Book::GetBooklist();
		for (int i = 0; i < size; i++) {
			cout << "============================================================================================" << endl;
			listofBooks[i].printData();
			cout << "============================================================================================" << endl;
		}
	}

	void printAllBooksByAuthor(char* AuthorName = nullptr) {
		int size = Book::GetBooklist();
		for (int i = 0; i < size; i++) {
			if (listofBooks[i].SearchAuthor(AuthorName)) {
				cout << "============================================================================================" << endl;
				listofBooks[i].printData();
				cout << "============================================================================================" << endl;
			}
		}
	}

	void printAllBooksByGenre(char* GenreType = nullptr) {
		int size = Book::GetBooklist();
		for (int i = 0; i < size; i++) {
			if (Book::compare(listofBooks[i].GetGenre(), GenreType)) {
				cout << "============================================================================================" << endl;
				listofBooks[i].printData();
				cout << "============================================================================================" << endl;
			}
		}
	}

	~BookStore() {
		delete[] listofBooks;
		listofBooks = nullptr;
		totalSales = 0;
	}
};

int DisplayConsole(BookStore &Shop1) {
	system("CLS");
	int xin;

	cout << "                          \" Welcome to The BOOKSTORE\"                          ";
	cout << endl;
	cout << endl;
	cout << endl;
	cout << endl;

	cout << "What do you wish to do: \n";
	while (true) {
		cout << "1.Add books in shop. \n";
		cout << "2.Sell books from shop. \n";
		cout << "3.View Info of all the books in the shop. \n";
		cout << "4.Search books in shop. \n";
		cout << "5.Close shop. \n";

		cout << "Enter choice: ";
		cin >> xin;
		system("CLS");
		if (xin == 1) {
			cout << "How many books would you like to add? \n";
			int n;
			cin >> n;
			for (int i = 0; i < n; i++) {
				Shop1.addBook();
			}
			bool x = true;
			int ch;
			cout << "1. Return to Console. \n";
			cout << "2. Close Shop. \n";
			cin >> ch;
			while (x) {
				if (ch == 1) { x = false; system("CLS"); }
				else if (ch == 2) {
					return 0;
				}
				else {
					cout << "Option unavailable \n";
					cout << "Enter Correct Choice: \n";
				}
			}
		}

		//=================================================================================================================================================================================
		else if (xin == 2) {
			int s;
			cin.ignore(1, '\n');
			cin.clear();
			cout << "How many books do you wish to sell: \n";
			cout << "Enter Number: \n";
			cin >> s;
			//			system("CLS");
			for (int i = 0; i < s; i++) {
				char* title;
				title = new char[20];
				int w = 0;
				while (w != 1) {
					cout << "Title of Book#" << i + 1 << ": \n";
					cin.ignore(1, '\n');
					cin.clear();
					cin.getline(title, 20);
					if (Shop1.SearchBook(title)) {
						Shop1.sellBook(title);
						w = 1;
					}
					else {
						cout << "The book that you are trying to sell is either already sold or it is not available in the shop. \n";
					}
				}
			}
			bool x = true;
			int ch;
			cout << "1. Return to Console. \n";
			cout << "2. Close Shop. \n";
			cin >> ch;
			while (x) {
				if (ch == 1) { x = false; system("CLS"); }
				else if (ch == 2) {
					return 0;
				}
				else {
					cout << "Option unavailable \n";
					cout << "Enter Correct Choice: \n";
				}
			}
		}

		//=================================================================================================================================================================================
		else if (xin == 3) {
			Shop1.printAllBooks();
			bool x = true;
			int ch;
			cout << "1. Return to Console. \n";
			cout << "2. Close Shop. \n";
			cin >> ch;
			while (x) {
				if (ch == 1) { x = false; system("CLS"); }
				else if (ch == 2) {
					return 0;
				}
				else {
					cout << "Option unavailable \n";
					cout << "Enter Correct Choice: \n";
				}
			}
		}

		//=================================================================================================================================================================================
		else if (xin == 4) {
			bool y = true;
			int u;
			cout << "How do you wish to search: \n";
			cout << "1.Search books by Author. \n";
			cout << "2.Search books by Genre. \n";
			cout << "Enter choice: ";
			while (y) {
				cin >> u;
				system("CLS");
				if (u == 1) {
					y = false;
					char *author;
					author = new char[20];
					cout << "Name of Author: \n";
					cin.ignore(1, '\n');
					cin.clear();
					cin.getline(author, 20);
					Shop1.printAllBooksByAuthor(author);
				}
				else if (u == 2) {
					y = false;
					char *genre;
					genre = new char[20];
					cout << "Genre Type: \n";
					cin.ignore(1, '\n');
					cin.clear();
					cin.getline(genre, 20);
					Shop1.printAllBooksByGenre(genre);
				}
				else {
					cout << "Option unavailable \n";
					cout << "Enter Correct Choice: \n";
				}
			}
			bool x = true;
			int ch;
			while (x) {
				cout << "1. Return to Console. \n";
				cout << "2. Close Shop. \n";
				cin >> ch;
				if (ch == 1) {
					x = false;
					system("CLS");
				}
				else if (ch == 2) {
					return 0;
				}
				else {
					cout << "Option unavailable \n";
					cout << "Enter Correct Choice: \n";
				}
			}
		}

		//=================================================================================================================================================================================
		else if (xin == 5) {
			return 0;
		}
		else {
			cout << "Option unavailable \n";
			cout << "Enter Correct Choice: \n";
		}
	}

	return 0;
}
//===================================================================================================================================================
//===================================================================================================================================================
//===================================================================================================================================================
//===================================================================================================================================================

int main() {
	BookStore Store;
	DisplayConsole(Store);


	system("pause");
	return 0;
}