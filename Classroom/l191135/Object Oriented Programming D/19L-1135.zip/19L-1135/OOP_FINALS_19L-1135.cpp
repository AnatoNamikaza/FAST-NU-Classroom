#include <iostream>
#include <cstring>
#include <fstream>
using namespace std;



//------------------------------------Global Template Function----------------------------------------
//Add here




//-----------------------------------------Name----------------------------------------------------------
int PtrSize(const char *p) {
	int size = 0;
	for (int i = 0; p[i] != '\0'; i++) {
		size++;
	}
	size++;

	return size;
}


int Strlen(const char* Name){
	int size=0;
	for(int i=0; Name[i]!='\0';i++) {
		size++;
	}

	return size;
}

class Name{
	char* fname;
	char* lname;
public:
	Name(const char* fname= nullptr, const char* lname= nullptr) {
		if(fname!= nullptr) {
			int size=PtrSize(fname);
			this->fname = new char[size + 1];
			for(int i=0;i<size;i++){
				fname= nullptr;
			}
		}

		if(lname!= nullptr) {
			int size = PtrSize(fname);
			this->lname = new char[size + 1];
			for (int i = 0; i < size; i++) {
				lname = nullptr;
			}
		}

		strcpy(this->fname, fname);
		strcpy(this->lname, lname);
	}

	~Name() {
		if (fname != nullptr)
			delete[] fname;
		if (lname != nullptr)
			delete[] lname;
	}

	Name(const Name & n) {
		this->fname = new char[Strlen(n.fname) + 1];
		this->lname = new char[Strlen(n.lname) + 1];
		strcpy(this->fname, n.fname);
		strcpy(this->lname, n.lname);

	}


	char * GetFName() const {
		return this->fname;
	}

	char * GetLName() const {
		return this->lname;
	}

	void SetFName(const char* q){
		strcpy(this->fname,q);
	}

	void SetLName(const char* q){
		strcpy(this->lname,q);
	}

	friend ostream& operator<<(ostream& out, const Name & n);
};

ostream& operator<<(ostream& out, const Name & n) {
	out << n.fname << " " << n.lname;
	return out;
}

//-----------------------------------------Player----------------------------------------------------------


class Player {
	int id;
	Name  pname;
	char * contact;
	int balance;
	static int count;
public:
	//Add all required functions.
	static int time;
	Player(const char* FstName=nullptr,const char* LstName=nullptr,int x=0,const char* Cellno=nullptr, int y=0): pname(FstName,LstName) {
		if(time==0){
			count=0;
			time++;
		}
		this->id=x;
		this->balance=y;
		int size= PtrSize(Cellno);
		contact=new char [size];
		for (int i = 0; i < size; i++) {
			contact[i] = Cellno[i];
		}

		count++;
	}

	Player(const Player & n) {
		this->count=n.Getcount();
		this->id=n.Getid();
		this->balance=n.Getbalance();
		this->pname.SetFName(n.pname.GetFName());
		this->pname.SetLName(n.pname.GetLName());
	}

	void Update() {
		int x,y;
		string Cell;
		cin>>x;
		this->id=x;
		cin>>y;
		this->balance=y;
		cin>>Cell;
		int size= PtrSize(Cell.data());
		contact=new char [size];
		for (int i = 0; i < size; i++) {
			contact[i] = Cell[i];
		}

		count++;
	}

	int Getbalance() const {
		return balance;
	}

	int Getid() const {
		return id;
	}

	int Getcount() const {
		return count;
	}

	void Setid(int i){
		this->id=i;
	}

	void Setbalance(int i){
		this->id=i;
	}

	void Setcontact(const char* q){
		strcpy(this->contact,q);
	}

	void SetFrstName(const char* q){
		pname.SetFName(q);
	}

	void SetLastName(const char* q){
		pname.SetLName(q);
	}

	void resetCount(){
		this->count=0;
	}

	friend ostream& operator<<(ostream& out, const Player& p) {
		out << p.pname << "\n ";
		out << p.id << "\n ";
		out << p.contact << "\n ";
		out << p.balance << "\n ";
		out << p.count << "\n ";

		return out;
	}

	~Player() {
		count = 0;
		id = 0;
		balance = 0;
		delete[] contact;
		contact = nullptr;
	}
};

//-----------------------------------------------------------------------------------------------------------

//Add all required classes with complete Implementaion here.


//-----------------------------------------GamingZone----------------------------------------------------------

class GamingZone {
	int TotalPlayers;
	Player *People;
	int TotalPCPlatforms;
	int* PCplatforms;
	int TotalPSPlatforms;
	int* PSplatforms;
	int* PSplatformsControlers;

	//Add all required functions and data members.
public:

	GamingZone(int PCpForms=0, int PSpForms=0) {
		People=nullptr;
		int i = 0;
		if(PCpForms!=0) {
			PCplatforms = new int[PCpForms];
			for (; i < PCpForms; i++) {
				PCplatforms[i] = 0;
			}
		}
		i = 0;
		if(PSpForms!=0) {
			PSplatforms = new int[PSpForms];
			for (; i < PSpForms; i++) {
				PSplatforms[i] = 0;
			}
			PSplatformsControlers = new int[PSpForms];
			for (; i < PSpForms; i++) {
				PSplatforms[i] = 0;
			}
		}
	}


	void loadPlayers() {
		ifstream fin;

		fin.open("Players.txt");
		fin >> TotalPlayers;

		if (TotalPlayers != 0) {

			People = new Player[TotalPlayers];
			string text;
			int inputNo = 0;
			for (int i = 0; i < TotalPlayers; i++) {
				fin >> inputNo;
				People[i].Setid(inputNo);
				fin >> text;
				People[i].SetFrstName(text.data());
				fin >> text;
				People[i].SetLastName(text.data());
				fin >> text;
				People[i].Setcontact(text.data());
				fin >> text;
				People[i].Setbalance(std::stoi(text));
			}
		}
	}

	void copyint(int P1, int P2){
		P1=P2;
	}

	void loadPlatforms(){
		ifstream fin;

		fin.open("Platforms.txt");
		fin >> TotalPCPlatforms;

		if (TotalPCPlatforms != 0) {

			PCplatforms = new int[TotalPCPlatforms];
			string text;
			for (int i = 0; i < TotalPCPlatforms; i++) {
				fin >> text;
				copyint(PCplatforms[i], std::stoi(text));
			}
		}

		fin >> TotalPSPlatforms;

		if (TotalPSPlatforms != 0) {

			PSplatforms = new int[TotalPSPlatforms];
			PSplatformsControlers = new int[TotalPSPlatforms];
			string text;
			for (int i = 0; i < TotalPSPlatforms; i++) {
				fin >> text;
				copyint(PSplatforms[i], std::stoi(text));
				fin >> text;
				copyint(PSplatformsControlers[i], std::stoi(text));
			}
		}
	}

	void printAllPlayers() {
		for (int i = 0; i < TotalPlayers; i++) {
			cout << People[i] << "\n";
		}
	}

	void printAllPlatforms() {
		cout<<"Total PC platforms: \n";
		for (int i = 0; i < TotalPCPlatforms; i++) {
			cout << PCplatforms[i] << "\n";
		}

		cout<<"-------------------------------------------------------- \n";
		cout<<"Total PS platforms: \n";
		for (int i = 0; i < TotalPSPlatforms; i++) {
			cout << PSplatforms[i] << " " << PSplatformsControlers[i]<<"\n";
		}
	}

	void signUp(){
		Player *TempPeople;
		TempPeople = new Player[TotalPlayers+1];
		int i=0;
		for(;i<=TotalPlayers;i++){
			TempPeople[i]=People[i];
		}
		i++;
		TempPeople[i].Update();

		TotalPlayers++;
	}

	Player * getPlayerWithId(int id) {
		for (int i = 0; i < TotalPlayers; i++) {
			if (People[i].Getid() == id) {
				return &People[i];
			}
		}
	}

	void playonPS(int id){

	}

	void playonPS(int  id){

	}

	void run() {
		while (true) {
			system("cls");
			int option;
			cout << "What do you want to do?\n\t1. Register new player\n\t2. Login\n\t3. Press Any key to Exit \n\nEnter your choice: ";
			cin >> option;
			if (option == 1) // 1. Register new player
			{
				signUp();
				system("PAUSE");
			}

			else if (option == 2)	// 2. Login
			{
				int id;
				cout << "Enter Your User Id:";
				cin >> id;
				if (getPlayerWithId(id) != nullptr) { //Search player in list and return its address if exist.
					cout << "What do you want to do?\n\t1. Play a PS game\n\t2. Play a PC game\n\t3. Press Any key to Exit\n\nEnter your choice: ";
					cin >> option;
					if (option == 1) // 1. Play a PS game
						playonPS(id);
					else if (option == 2)	// 2. Play a PC game
						playonPC(id);
					else  //3. Exit
						return;
				}
			}
			else //3. Exit
				return;
		}
	}

};

int Player::count = 0;
int Player::time = 0;
//-----------------------------------------Driver----------------------------------------------------------
int main() {
	GamingZone zone (50, 20);
	zone.loadPlayers();
	zone.loadPlatforms();
	zone.printAllPlayers();
	zone.printAllPlatforms();
	zone.run();
	return 0;
}

#include <iostream>
#include <cstring>
#include <fstream>
using namespace std;



//------------------------------------Global Template Function----------------------------------------
//Add here




//-----------------------------------------Name----------------------------------------------------------
int PtrSize(const char *p) {
	int size = 0;
	for (int i = 0; p[i] != '\0'; i++) {
		size++;
	}
	size++;

	return size;
}


int Strlen(const char* Name){
	int size=0;
	for(int i=0; Name[i]!='\0';i++) {
		size++;
	}

	return size;
}

class Name{
	char* fname;
	char* lname;
public:
	Name(const char* fname= nullptr, const char* lname= nullptr) {
		if(fname!= nullptr) {
			int size=PtrSize(fname);
			this->fname = new char[size + 1];
			for(int i=0;i<size;i++){
				fname= nullptr;
			}
		}

		if(lname!= nullptr) {
			int size = PtrSize(fname);
			this->lname = new char[size + 1];
			for (int i = 0; i < size; i++) {
				lname = nullptr;
			}
		}

		strcpy(this->fname, fname);
		strcpy(this->lname, lname);
	}

	~Name() {
		if (fname != nullptr)
			delete[] fname;
		if (lname != nullptr)
			delete[] lname;
	}

	Name(const Name & n) {
		this->fname = new char[Strlen(n.fname) + 1];
		this->lname = new char[Strlen(n.lname) + 1];
		strcpy(this->fname, n.fname);
		strcpy(this->lname, n.lname);

	}


	char * GetFName() const {
		return this->fname;
	}

	char * GetLName() const {
		return this->lname;
	}

	void SetFName(const char* q){
		strcpy(this->fname,q);
	}

	void SetLName(const char* q){
		strcpy(this->lname,q);
	}

	friend ostream& operator<<(ostream& out, const Name & n);
};

ostream& operator<<(ostream& out, const Name & n) {
	out << n.fname << " " << n.lname;
	return out;
}

//-----------------------------------------Player----------------------------------------------------------


class Player {
	int id;
	Name  pname;
	char * contact;
	int balance;
	static int count;
public:
	//Add all required functions.
	static int time;
	Player(const char* FstName=nullptr,const char* LstName=nullptr,int x=0,const char* Cellno=nullptr, int y=0): pname(FstName,LstName) {
		if(time==0){
			count=0;
			time++;
		}
		this->id=x;
		this->balance=y;
		int size= PtrSize(Cellno);
		contact=new char [size];
		for (int i = 0; i < size; i++) {
			contact[i] = Cellno[i];
		}

		count++;
	}

	Player(const Player & n) {
		this->count=n.Getcount();
		this->id=n.Getid();
		this->balance=n.Getbalance();
		this->pname.SetFName(n.pname.GetFName());
		this->pname.SetLName(n.pname.GetLName());
	}

	void Update() {
		int x,y;
		string Cell;
		cin>>x;
		this->id=x;
		cin>>y;
		this->balance=y;
		cin>>Cell;
		int size= PtrSize(Cell.data());
		contact=new char [size];
		for (int i = 0; i < size; i++) {
			contact[i] = Cell[i];
		}

		count++;
	}

	int Getbalance() const {
		return balance;
	}

	int Getid() const {
		return id;
	}

	int Getcount() const {
		return count;
	}

	void Setid(int i){
		this->id=i;
	}

	void Setbalance(int i){
		this->id=i;
	}

	void Setcontact(const char* q){
		strcpy(this->contact,q);
	}

	void SetFrstName(const char* q){
		pname.SetFName(q);
	}

	void SetLastName(const char* q){
		pname.SetLName(q);
	}

	void resetCount(){
		this->count=0;
	}

	friend ostream& operator<<(ostream& out, const Player& p) {
		out << p.pname << "\n ";
		out << p.id << "\n ";
		out << p.contact << "\n ";
		out << p.balance << "\n ";
		out << p.count << "\n ";

		return out;
	}

	~Player() {
		count = 0;
		id = 0;
		balance = 0;
		delete[] contact;
		contact = nullptr;
	}
};

//-----------------------------------------------------------------------------------------------------------

//Add all required classes with complete Implementaion here.


//-----------------------------------------GamingZone----------------------------------------------------------

class GamingZone {
	int TotalPlayers;
	Player *People;
	int TotalPCPlatforms;
	int* PCplatforms;
	int TotalPSPlatforms;
	int* PSplatforms;
	int* PSplatformsControlers;

	//Add all required functions and data members.
public:

	GamingZone(int PCpForms=0, int PSpForms=0) {
		People=nullptr;
		int i = 0;
		if(PCpForms!=0) {
			PCplatforms = new int[PCpForms];
			for (; i < PCpForms; i++) {
				PCplatforms[i] = 0;
			}
		}
		i = 0;
		if(PSpForms!=0) {
			PSplatforms = new int[PSpForms];
			for (; i < PSpForms; i++) {
				PSplatforms[i] = 0;
			}
			PSplatformsControlers = new int[PSpForms];
			for (; i < PSpForms; i++) {
				PSplatforms[i] = 0;
			}
		}
	}


	void loadPlayers() {
		ifstream fin;

		fin.open("Players.txt");
		fin >> TotalPlayers;

		if (TotalPlayers != 0) {

			People = new Player[TotalPlayers];
			string text;
			int inputNo = 0;
			for (int i = 0; i < TotalPlayers; i++) {
				fin >> inputNo;
				People[i].Setid(inputNo);
				fin >> text;
				People[i].SetFrstName(text.data());
				fin >> text;
				People[i].SetLastName(text.data());
				fin >> text;
				People[i].Setcontact(text.data());
				fin >> text;
				People[i].Setbalance(std::stoi(text));
			}
		}
	}

	void copyint(int P1, int P2){
		P1=P2;
	}

	void loadPlatforms(){
		ifstream fin;

		fin.open("Platforms.txt");
		fin >> TotalPCPlatforms;

		if (TotalPCPlatforms != 0) {

			PCplatforms = new int[TotalPCPlatforms];
			string text;
			for (int i = 0; i < TotalPCPlatforms; i++) {
				fin >> text;
				copyint(PCplatforms[i], std::stoi(text));
			}
		}

		fin >> TotalPSPlatforms;

		if (TotalPSPlatforms != 0) {

			PSplatforms = new int[TotalPSPlatforms];
			PSplatformsControlers = new int[TotalPSPlatforms];
			string text;
			for (int i = 0; i < TotalPSPlatforms; i++) {
				fin >> text;
				copyint(PSplatforms[i], std::stoi(text));
				fin >> text;
				copyint(PSplatformsControlers[i], std::stoi(text));
			}
		}
	}

	void printAllPlayers() {
		for (int i = 0; i < TotalPlayers; i++) {
			cout << People[i] << "\n";
		}
	}

	void printAllPlatforms() {
		cout<<"Total PC platforms: \n";
		for (int i = 0; i < TotalPCPlatforms; i++) {
			cout << PCplatforms[i] << "\n";
		}

		cout<<"-------------------------------------------------------- \n";
		cout<<"Total PS platforms: \n";
		for (int i = 0; i < TotalPSPlatforms; i++) {
			cout << PSplatforms[i] << " " << PSplatformsControlers[i]<<"\n";
		}
	}

	void signUp(){
		Player *TempPeople;
		TempPeople = new Player[TotalPlayers+1];
		int i=0;
		for(;i<=TotalPlayers;i++){
			TempPeople[i]=People[i];
		}
		i++;
		TempPeople[i].Update();

		TotalPlayers++;
	}

	Player * getPlayerWithId(int id) {
		for (int i = 0; i < TotalPlayers; i++) {
			if (People[i].Getid() == id) {
				return &People[i];
			}
		}
	}

	void playonPS(int id){

	}

	void playonPS(int  id){

	}

	void run() {
		while (true) {
			system("cls");
			int option;
			cout << "What do you want to do?\n\t1. Register new player\n\t2. Login\n\t3. Press Any key to Exit \n\nEnter your choice: ";
			cin >> option;
			if (option == 1) // 1. Register new player
			{
				signUp();
				system("PAUSE");
			}

			else if (option == 2)	// 2. Login
			{
				int id;
				cout << "Enter Your User Id:";
				cin >> id;
				if (getPlayerWithId(id) != nullptr) { //Search player in list and return its address if exist.
					cout << "What do you want to do?\n\t1. Play a PS game\n\t2. Play a PC game\n\t3. Press Any key to Exit\n\nEnter your choice: ";
					cin >> option;
					if (option == 1) // 1. Play a PS game
						playonPS(id);
					else if (option == 2)	// 2. Play a PC game
						playonPC(id);
					else  //3. Exit
						return;
				}
			}
			else //3. Exit
				return;
		}
	}

};

int Player::count = 0;
int Player::time = 0;
//-----------------------------------------Driver----------------------------------------------------------
int main() {
	GamingZone zone (50, 20);
	zone.loadPlayers();
	zone.loadPlatforms();
	zone.printAllPlayers();
	zone.printAllPlatforms();
	zone.run();
	return 0;
}

