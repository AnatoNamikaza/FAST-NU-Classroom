#include <iostream>
#include <cstring>
#include <cmath>
using namespace std;

bool NumFullZero(const char *pin) {
	bool value = true;
	int siz = 0;
	for (int i = 0; pin[i] != '\0'; i++) { siz++; }
	for (int i = 0; i < siz; i++) {
		if (pin[i] != 48) {
			value = false;
			return value;
		}
	}
	return value;
}

char* RemoveZerosFromArr(const char *pin) {
	int ZeroCount = 0;
	int size = 0;
	for (int i = 0; pin[i] != '\0'; i++) { size++; }
	size++;
	char *temp;
	temp = new char[size + 1];
	for (int i = 0; i < size + 1; i++) {
		temp[i] = pin[i];
	}
	int len = size + 1;
	int i = 0;
	for (; i < size; i++) {
		i = 0;
		int con = (temp[i] - 48);
		if (con == 0) {
			int j = i;
			for (; j < size; j++) {
				temp[j] = temp[j + 1];
			}
			len--;
			ZeroCount++;
		}
		else if (con != 0) {
			break;
		}
	}
	int xe = size - 1;
	if (ZeroCount == xe) {
		temp[0] = '0';
		temp[1] = '\0';
	}

	return temp;
}

bool compare(char* str1, char* str2) {
	bool v = true;
	int size = 0;
	for (int i = 0; str1[i] != '\0'; i++) { size++; }
	size++;
	for (int j = 0; j < size; j++) {
		if (strcmp(str1, str2) == 0) {}
		else if (strcmp(str1, str2) != 0) { return false; }
	}
	return v;
}

int GorL(char* str1, char* str2) {
	int v = 0;
	if (strcmp(str1, str2) == 1) {
		v = 1;
		return v;
	}
	else if (strcmp(str1, str2) == -1) {
		v = -1;
		return v;
	}

	return v;
}

char* iNtoa(int num) {
	int i = 0;
	char* str;
	char numb[80];

	if (num == 0) {
		str = new char[2];
		str[i] = '0';
		str[i++] = '\0';
		return str;
	}

	while (num != 0) {
		int rem = num % 10;
		numb[i] = (rem + 48);
		num = num / 10;
		i++;
	}
	numb[i] = '\0';

	int k = i;
	k--;
	int j = k;
	i = 0;
	str = new char[j + 1];
	for (; i < j; i++) {
		str[i] = numb[k];
		k--;
	}
	str[j] = '\0';

	return str;
}

int atoi(char *array) {
	int number = 0;
	int mult = 10;
	int size1 = 0;

	for (int i = 0; array[i] != '\0'; i++) { size1++; }

	for (int n = 0; n < size1; n++) {
		number = number * mult + (array[n] - '0');
	}

	return number;
}

class HugeInteger {
private:
	char *data;
	int size{}; //// Total no. of digits in data;

public:

	/*HugeInteger() {
		data = NULL;
		size = 0;
	}*/

	HugeInteger(int digits = 0, char *Number = nullptr) {
		if (digits == 0) {
			data = NULL;
			size = 0;
		}
		if (digits != 0) {
			size = digits;
			int size1 = 0;
			for (int i = 0; Number[i] != '\0'; i++) { size1++; }
			size1++;
			bool x = CheckForHugeInt(Number);
			if (!x) {
				cout << "Error detected, The Given Number is not a HugeInt. \n";
			}
			else {
				char* NewArr;
				NewArr = RemoveZerosFromArr(Number);
				int NewSiz = 0;
				for (int i = 0; NewArr[i] != '\0'; i++) { NewSiz++; }

				data = new char[NewSiz + 1];
				for (int i = 0; i < NewSiz; i++) {
					data[i] = NewArr[i];
				}
				data[NewSiz] = '\0';
				this->size = NewSiz;
			}
		}
	}

	HugeInteger(const char *p) {
		int size = 0;
		for (int i = 0; p[i] != '\0'; i++) {
			size++;
		}
		bool x = CheckForHugeInt(p);
		if (!x) {
			cout << "Error detected, The Given Number is not a HugeInt. \n";
		}
		else {
			char* NewArr;
			NewArr = RemoveZerosFromArr(p);
			int NewSiz = 0;
			for (int i = 0; NewArr[i] != '\0'; i++) { NewSiz++; }

			data = new char[NewSiz + 1];
			for (int i = 0; i < NewSiz; i++) {
				data[i] = NewArr[i];
			}
			data[NewSiz] = '\0';
			this->size = NewSiz;
		}
	}

	HugeInteger(const HugeInteger &p2) {
		this->size = p2.size;
		data = new char[size + 1];
		for (int i = 0; i < this->size + 1; i++) {
			this->data[i] = p2.data[i];
		}
	}

	/*void copy(char* &p) {
		int size = 0;
		for (int i = 0; p[i] != '\0'; i++) {
			size++;
		}
		size++;
		data = new char[size];
		for (int i = 0; i < size; i++) {
			data[i] = p[i];
		}
	}*/

	char *GetData() {
		return this->data;
	}


	static bool CheckForHugeInt(const char *p) {
		bool Check = true;
		int siz = 0;
		for (int i = 0; p[i] != '\0'; i++) {
			siz++;
		}

		for (int i = 0; i < siz; i++) {
			if (p[i] >= 58 || p[i] < 48) {
				Check = false;
				return Check;
			}
		}
		return Check;
	}

	static HugeInteger IntToHugInt(int num) {
		HugeInteger temp;
		char *temp1;

		int x = num;
		int tempx = x;
		int len = 0;
		if (x == 0) {
			temp.data = new char[2];
			temp.data[0] = '0';
			temp.data[1] = '\0';
			temp.size = 1;
		}
		else {
			while (tempx > 0) {
				++len;
				tempx /= 10;
			}
			temp1 = new char[len + 1];
			for (int i = 0; i < len; i++) {
				temp1[i] = (x % 10) + 48;
				x /= 10;
			}
			temp1[len] = '\0';

			temp.data = new char[len + 1];
			int j = len - 1, k = 0;
			for (; k < len; k++) {
				temp.data[k] = temp1[j];
				j--;
			}
			temp.data[k] = '\0';
			temp.size = k;
		}

		return temp;
	}

	static HugeInteger CharToHugInt(char *P, int siz) {
		HugeInteger temp;
		temp.data = new char[siz + 1];
		int j = siz - 1, k = 0;
		for (; k < siz; k++) {
			temp.data[k] = P[j];
			j--;
		}
		temp.data[k] = '\0';
		temp.size = k;

		return temp;
	}

	bool operator==(const HugeInteger &objh) const {
		bool value = true;
		int siz = this->size + 1;

		for (int i = 0; i < siz; i++) {
			if (data[i] != objh.data[i]) {
				value = false;
				return value;
			}
		}
		return value;
	}

	HugeInteger &operator=(const HugeInteger &p2) {

		this->size = p2.size;
		data = new char[p2.size + 1];
		for (int i = 0; i < this->size + 1; i++) {
			this->data[i] = p2.data[i];
		}

		return *this;
	}

	bool operator!=(const HugeInteger &objh) const {
		bool value = false;
		int siz = this->size + 1;

		for (int i = 0; i < siz; i++) {
			if (data[i] != objh.data[i]) {
				value = true;
				return value;
			}
		}
		return value;
	}

	bool operator<(const HugeInteger &objh) const {
		bool value = false;
		int siz1 = this->size + 1;
		int siz2 = objh.size + 1;
		if (siz1 > siz2) {
			return value;
		}
		else if (siz1 == siz2) {
			for (int i = 0; i < siz1; i++) {
				if (data[i] > objh.data[i]) {
					return value;
				}
				else if (data[i] == objh.data[i]) {}
				else if (data[i] < objh.data[i]) {
					value = true;
					return value;
				}
			}
		}
		else if (siz1 < siz2) {
			value = true;
		}

		return value;
	}

	bool operator<=(const HugeInteger &objh) const {
		bool value = true;
		int siz1 = this->size + 1;
		int siz2 = objh.size + 1;
		if (siz1 > siz2) {
			value = false;
			return value;
		}
		else if (siz1 == siz2) {
			for (int i = 0; i < siz1; i++) {
				if (data[i] > objh.data[i]) {
					value = false;
					return value;
				}
				else if (data[i] == objh.data[i]) {}
				else if (data[i] < objh.data[i]) {
					return value;
				}
			}
		}
		else if (siz1 < siz2) {}

		return value;
	}

	bool operator>(const HugeInteger &objh) const {
		bool value = false;
		int siz1 = this->size + 1;
		int siz2 = objh.size + 1;
		if (siz1 < siz2) {
			return value;
		}
		else if (siz1 == siz2) {
			for (int i = 0; i < siz1; i++) {
				if (data[i] < objh.data[i]) {
					return value;
				}
				else if (data[i] == objh.data[i]) {}
				else if (data[i] > objh.data[i]) {
					value = true;
					return value;
				}
			}
		}
		else if (siz1 > siz2) {
			value = true;
		}

		return value;
	}

	bool operator>=(const HugeInteger &objh) const {
		bool value = true;
		int siz1 = this->size + 1;
		int siz2 = objh.size + 1;
		if (siz1 < siz2) {
			value = false;
			return value;
		}
		else if (siz1 == siz2) {
			for (int i = 0; i < siz1; i++) {
				if (data[i] < objh.data[i]) {
					value = false;
					return value;
				}
				else if (data[i] == objh.data[i]) {}
				else if (data[i] > objh.data[i]) {
					return value;
				}
			}
		}
		else if (siz1 > siz2) {}

		return value;
	}

	HugeInteger operator++(int num) {
		HugeInteger temp, one = HugeInteger("1");
		temp = (*this + one);
		*this = temp;

		return temp;
	}

	HugeInteger operator--(int num) {
		HugeInteger temp;
		temp = (*this - 1);
		*this = temp;

		return temp;
	}

	HugeInteger operator+(HugeInteger &objh) {
		HugeInteger Sum;
		char *temp1;
		char *temp2;
		char *temp3;
		int len1, len2, len3;

		len1 = this->size;
		len2 = objh.size;


		int i1 = 0;
		int i2 = 0;
		int carry = 0;
		int val1 = 0;

		if (len1 > len2) {
			temp1 = new char[this->size + 1];
			for (int i = 0; i < this->size + 1; i++) {
				temp1[i] = this->data[i];
			}
			temp2 = new char[objh.size + 1];
			for (int i = 0; i < objh.size + 1; i++) {
				temp2[i] = objh.data[i];
			}
			len3 = len1 + 1;
			i1 = len1 - 1;
			i2 = len2 - 1;
		}
		else {
			temp1 = new char[objh.size + 1];
			for (int i = 0; i < objh.size + 1; i++) {
				temp1[i] = objh.data[i];
			}
			temp2 = new char[this->size + 1];
			for (int i = 0; i < this->size + 1; i++) {
				temp2[i] = this->data[i];
			}
			len3 = len2 + 1;
			i1 = len2 - 1;
			i2 = len1 - 1;
		}

		temp3 = new char[len3 + 1];
		int i = 0;
		while (i < len3 - 1) {
			while (i1 > -1) {
				if (i2 > -1) {
					val1 = (temp1[i1] - 48) + (temp2[i2] - 48) + carry;
					carry = 0;
					if (val1 >= 10) {
						carry = val1 / 10;
						val1 = val1 % 10;
					}
					temp3[i] = (val1 + 48);
				}
				else {
					val1 = (temp1[i1] - 48) + 0 + carry;
					carry = 0;
					if (val1 >= 10) {
						carry = val1 / 10;
						val1 = val1 % 10;
					}
					temp3[i] = (val1 + 48);
				}
				i++;
				i1--;
				i2--;
			}
			if (carry != 0) {
				temp3[i] = (carry + 48);
				i++;
			}

			temp3[i] = '\0';
		}

		Sum = CharToHugInt(temp3, i);

		delete[] temp1;
		temp1 = nullptr;
		delete[] temp2;
		temp2 = nullptr;
		delete[] temp3;
		temp3 = nullptr;


		return Sum;
	}

	HugeInteger operator+(int num) {
		HugeInteger Sum;
		HugeInteger temp = IntToHugInt(num);
		Sum = *this + temp;
		temp.~HugeInteger();

		return Sum;
	}

	friend HugeInteger operator+(int num, HugeInteger &objh) {
		HugeInteger Sum;
		HugeInteger temp = IntToHugInt(num);
		Sum = temp + objh;
		temp.~HugeInteger();

		return Sum;
	}

	HugeInteger operator-(const HugeInteger &objh) {
		HugeInteger Diff;
		char *temp1;
		char *temp2;
		char *temp3;
		int len1, len2, len3;

		len1 = this->size;
		len2 = objh.size;


		int i1 = 0;
		int i2 = 0;
		int val1 = 0;

		if (len1 > len2) {
			temp1 = new char[this->size + 1];
			for (int i = 0; i < this->size + 1; i++) {
				temp1[i] = this->data[i];
			}
			temp2 = new char[objh.size + 1];
			for (int i = 0; i < objh.size + 1; i++) {
				temp2[i] = objh.data[i];
			}
			len3 = len1 + 1;
			i1 = len1 - 1;
			i2 = len2 - 1;
		}
		else {
			temp1 = new char[objh.size + 1];
			for (int i = 0; i < objh.size + 1; i++) {
				temp1[i] = objh.data[i];
			}
			temp2 = new char[this->size + 1];
			for (int i = 0; i < this->size + 1; i++) {
				temp2[i] = this->data[i];
			}
			len3 = len2 + 2;
			i1 = len2 - 1;
			i2 = len1 - 1;
		}

		temp3 = new char[len3 + 1];
		int i = 0;
		while (i < len3 - 1) {
			if (len1 > len2) {
				while (i1 > -1) {
					if (i2 > -1) {
						int x1;
						if (temp1[i1] == '/') {
							temp1[i1 - 1] = (((temp1[i1 - 1] - 48) - 1) + 48);
							x1 = 9;
						}
						else {
							x1 = (temp1[i1] - 48);
						}
						int x2 = (temp2[i2] - 48);
						if (x1 < x2) {
							temp1[i1 - 1] = (((temp1[i1 - 1] - 48) - 1) + 48);
							val1 = (x1 + 10) + (-1 * x2);
						}
						else {
							val1 = x1 + (-1 * x2);
						}
						temp3[i] = (val1 + 48);
					}
					else {
						if (temp1[i1] == '/') {
							temp1[i1 - 1] = (((temp1[i1 - 1] - 48) - 1) + 48);
							temp3[i] = (9 + 48);
						}
						else {
							val1 = (temp1[i1] - 48);
							temp3[i] = (val1 + 48);
						}
					}
					i++;
					i1--;
					i2--;
				}
				temp3[i] = '\0';
			}
			else {
				while (i1 > -1) {
					if (i2 > -1) {
						int x1;
						if (temp1[i1] == '/') {
							temp1[i1 - 1] = (((temp1[i1 - 1] - 48) - 1) + 48);
							x1 = 9;
						}
						else {
							x1 = (temp1[i1] - 48);
						}
						int x2 = (temp2[i2] - 48);
						if (x1 < x2) {
							temp1[i1 - 1] = (((temp1[i1 - 1] - 48) - 1) + 48);
							val1 = (x1 + 10) + (-1 * x2);
						}
						else {
							val1 = x1 + (-1 * x2);
						}
						temp3[i] = (val1 + 48);
					}
					else {
						if (temp1[i1] == '/') {
							temp1[i1 - 1] = (((temp1[i1 - 1] - 48) - 1) + 48);
							temp3[i] = (9 + 48);
						}
						else {
							val1 = (temp1[i1] - 48);
							temp3[i] = (val1 + 48);
						}
					}
					i++;
					i1--;
					i2--;

				}
				if (compare(temp1, temp2) == false) {
					temp3[i] = '-';
					i++;
				}
				temp3[i] = '\0';
				break;
			}
		}
		if (NumFullZero(temp3) == true) {
			char *NewArr;
			NewArr = RemoveZerosFromArr(temp3);
			int NewSiz = 0;
			for (i = 0; NewArr[i] != '\0'; i++) { NewSiz++; }
			Diff = CharToHugInt(NewArr, NewSiz);
		}
		else {
			int NewSiz = 0;
			for (i = 0; temp3[i] != '\0'; i++) { NewSiz++; }
			Diff = CharToHugInt(temp3, NewSiz);
		}

		delete[] temp1;
		temp1 = nullptr;
		delete[] temp2;
		temp2 = nullptr;
		delete[] temp3;
		temp3 = nullptr;

		return Diff;
	}

	HugeInteger operator-(int num) {
		HugeInteger Diff;
		HugeInteger temp = IntToHugInt(num);
		Diff = *this - temp;

		return Diff;
	}

	friend HugeInteger operator-(int num, HugeInteger &objh) {
		HugeInteger Diff;
		HugeInteger temp = IntToHugInt(num);
		Diff = temp - objh;
		temp.~HugeInteger();

		return Diff;
	}

	HugeInteger operator*(const HugeInteger &objh) {
		HugeInteger Product;
		HugeInteger LastLayer;
		HugeInteger NewLayer;
		char *temp1 = nullptr;
		char *temp2 = nullptr;
		char *temp3 = nullptr;
		char *temp4 = nullptr;
		char *temp5 = nullptr;
		int len1, len2, len3;

		len1 = this->size;
		len2 = objh.size;

		int i1 = 0;
		int i2 = 0;
		int carry1 = 0;
		int siZ1 = 0;
		int val1 = 0;
		int siZ2 = 0;
		int time1 = 0;
		int time2 = 0;
		len3 = len1 + len2;

		if (len1 > len2) {
			temp1 = new char[this->size + 1];
			for (int i = 0; i < this->size + 1; i++) {
				temp1[i] = this->data[i];
			}
			temp2 = new char[objh.size + 1];
			for (int i = 0; i < objh.size + 1; i++) {
				temp2[i] = objh.data[i];
			}
			i1 = len1 - 1;
			i2 = len2 - 1;
		}
		else {
			temp1 = new char[objh.size + 1];
			for (int i = 0; i < objh.size + 1; i++) {
				temp1[i] = objh.data[i];
			}
			temp2 = new char[this->size + 1];
			for (int i = 0; i < this->size + 1; i++) {
				temp2[i] = this->data[i];
			}
			i1 = len2 - 1;
			i2 = len1 - 1;
		}

		int i = 0;
		int v = i1;
		temp3 = new char[len3];
		temp4 = new char[len3];
		temp5 = new char[len3 + 2];
		while (i < len3 - 1) {
			if (i2 <= -1) {
				break;
			}
			while (i2 > -1) {
				if (time1 == 0) {

					while (i1 > -1) {

						val1 = ((temp1[i1] - 48) * (temp2[i2] - 48)) + carry1;
						carry1 = 0;
						if (val1 >= 10) {
							carry1 = val1 / 10;
							val1 = val1 % 10;
						}
						temp3[i] = (val1 + 48);
						val1 = 0;

						i++;
						i1--;
					}
					if (carry1 != 0) {
						val1 = carry1;
						carry1 = 0;
						if (val1 >= 10) {
							carry1 = val1 / 10;
							val1 = val1 % 10;
						}
						temp3[i] = (val1 + 48);
						val1 = 0;

						i++;

					}
					time1++;
					carry1 = 0;
					temp3[i] = '\0';

					for (int u = 0; u < i + 1; u++) {
						temp4[u] = temp3[u];
					}
					siZ1 = i;
					i = 0;
					i1 = v;
					i2--;
				}
				else if (time1 > 0) {

					while (i1 > -1) {

						val1 = ((temp1[i1] - 48) * (temp2[i2] - 48)) + carry1;
						carry1 = 0;
						if (val1 >= 10) {
							carry1 = val1 / 10;
							val1 = val1 % 10;

						}
						temp3[i] = (val1 + 48);
						val1 = 0;
						i++;

						i1--;
					}
					if (carry1 != 0) {
						val1 = carry1;
						carry1 = 0;
						if (val1 >= 10) {
							carry1 = val1 / 10;
							val1 = val1 % 10;
						}
						temp3[i] = (val1 + 48);
						val1 = 0;

						i++;

					}
					int e = 0;
					for (; e < time1; e++) {
						temp5[e] = '0';
					}
					for (int u = 0; u < i + 1; u++) {
						temp5[e] = temp3[u];
						e++;
					}
					carry1 = 0;
					i = i + time1;
					siZ2 = i;
					i++;
					temp5[i] = '\0';

					if (time2 == 0) {
						LastLayer = CharToHugInt(temp4, siZ1);
						NewLayer = CharToHugInt(temp5, siZ2);
						LastLayer = (LastLayer + NewLayer);
						time1++;
						time2++;
						i2--;
					}
					else if (time2 > 0) {
						NewLayer = CharToHugInt(temp5, siZ2);
						LastLayer = (LastLayer + NewLayer);
						time1++;
						time2++;
						i2--;
					}
					i = 0;
					i1 = v;
				}
			}

		}
		Product = LastLayer;

		delete[] temp1;
		temp1 = nullptr;
		delete[] temp2;
		temp2 = nullptr;
		delete[] temp3;
		temp3 = nullptr;
		delete[] temp4;
		temp4 = nullptr;
		delete[] temp5;
		temp5 = nullptr;

		return Product;
	}

	HugeInteger operator*(int num) {
		HugeInteger Prod;
		HugeInteger temp = IntToHugInt(num);
		Prod = (*this * temp);
		temp.~HugeInteger();

		return Prod;
	}

	friend HugeInteger operator*(int num, HugeInteger &objh) {
		HugeInteger Prod;
		HugeInteger temp = IntToHugInt(num);
		Prod = (temp * objh);
		temp.~HugeInteger();

		return Prod;
	}

	HugeInteger operator/(HugeInteger &objh) {
		int Q = 0;
		bool x1 = (*this == objh);
		bool x2 = (*this > objh);
		bool x3 = (*this < objh);
		if (x1) {
			Q = 1;
		}
		if (x3) {}
		if (x2) {
			HugeInteger Temp1 = *this;
			HugeInteger Temp2 = objh;
			bool x4 = false;
			while (!x4) {
				Temp1 = (Temp1 - Temp2);
				char *arr1 = Temp1.GetData();
				char *arr2 = Temp2.GetData();
				char *NewArr1 = RemoveZerosFromArr(arr1);
				char *NewArr2 = RemoveZerosFromArr(arr2);
				int NewSiz1 = 0;
				for (int i = 0; NewArr1[i] != '\0'; i++) { NewSiz1++; }
				int NewSiz2 = 0;
				for (int i = 0; NewArr2[i] != '\0'; i++) { NewSiz2++; }
				if (NewSiz1 == NewSiz2 && NewArr1[0] < NewArr2[0] || NewSiz1 < NewSiz2) {
					x4 = true;
				}
				Q++;
			}
		}
		HugeInteger temp = IntToHugInt(Q);

		return temp;
	}

	//HugeInteger operator/(HugeInteger &objh) {
	//	HugeInteger UprNo;
	//	HugeInteger LowrNo;
	//	char *temp1 = nullptr;
	//	char *temp2 = nullptr;
	//	char *temp3 = nullptr;
	//	char *temp4 = nullptr;
	//	char *temp5 = nullptr;
	//	char *samp = nullptr;
	//	char *samp2 = nullptr;
	//	char *roundoff = nullptr;
	//	int len1, len2, len3;

	//	len1 = this->size;
	//	len2 = objh.size;

	//	if (len1 > len2) {
	//		len3 = len1;
	//	}
	//	else {
	//		len3 = len2;
	//	}

	//	samp = new char[len3 + 1];
	//	samp2 = new char[len3 + 1];
	//	roundoff = new char[3];
	//	temp3 = new char[len3 + 1];
	//	temp4 = new char[len3 + 1];
	//	temp5 = new char[len3 + 1];
	//	temp1 = new char[this->size + 1];
	//	for (int i = 0; i < this->size + 1; i++) {
	//		temp1[i] = this->data[i];
	//	}
	//	temp2 = new char[objh.size + 1];
	//	for (int i = 0; i < objh.size + 1; i++) {
	//		temp2[i] = objh.data[i];
	//	}

	//	int i1 = 0;
	//	//int i2 = 0;
	//	//int carry1 = 0;
	//	int siZ1, siZ2;
	//	//int val1 = 0;
	//	int time1 = 0;
	//	int sampl = 0;
	//	int sampl2 = 0;
	//	int samp3 = 0;
	//	int div = 0;
	//	//int time2 = 0;
	//	//len3 = len1 + len2;



	//	int Q = 0;
	//	int x1 = (GorL(temp1, temp2));
	//	int x2 = (GorL(temp1, temp2));
	//	int x3 = (GorL(temp1, temp2));
	//	if (x1 == 0) {
	//		temp3 = new char[2];
	//		temp3[0] = '1';
	//		temp3[1] = '\0';

	//		siZ1 = 0;
	//		for (int i = 0; temp3[i] != '\0'; i++) {
	//			siZ1++;
	//		}

	//		HugeInteger temp = CharToHugInt(temp3, siZ1);
	//		delete[] temp1;
	//		temp1 = nullptr;
	//		delete[] temp2;
	//		temp2 = nullptr;
	//		delete[] temp3;
	//		temp3 = nullptr;
	//		delete[] temp4;
	//		temp4 = nullptr;
	//		delete[] temp5;
	//		temp5 = nullptr;

	//		return temp;

	//	}
	//	else if (x3 == 1) {
	//		int ix = 0;
	//		for (; ix < len1; ix++) {
	//			temp3[ix] = temp1[ix];
	//		}
	//		i1 = ix;
	//		temp3[len1] = '0';
	//		temp3[len1 + 1] = '0';
	//		temp3[len1 + 2] = '\0';

	//		siZ1 = 0;
	//		for (int i = 0; temp3[i] != '\0'; i++) {
	//			siZ1++;
	//		}

	//		UprNo = CharToHugInt(temp3, siZ1);

	//		while (UprNo > LowrNo) {
	//			UprNo = UprNo - LowrNo;
	//			div++;
	//		}

	//		if (div > 45) {
	//			temp5[0] = '1';
	//			temp5[1] = '\0';

	//		}
	//		siZ1 = 0;
	//		for (int i = 0; temp5[i] != '\0'; i++) {
	//			siZ1++;
	//		}

	//		HugeInteger temp = CharToHugInt(temp5, siZ1);
	//		delete[] temp1;
	//		temp1 = nullptr;
	//		delete[] temp2;
	//		temp2 = nullptr;
	//		delete[] temp3;
	//		temp3 = nullptr;
	//		delete[] temp4;
	//		temp4 = nullptr;
	//		delete[] temp5;
	//		temp5 = nullptr;

	//		return temp;
	//	}
	//	else if (x2 == -1) {
	//		while (i1 < len1) {
	//			if (time1 == 0) {
	//				int ix = 0;
	//				for (; ix < len2; ix++) {
	//					temp3[ix] = temp1[ix];
	//				}
	//				i1 = ix;
	//				temp3[len2] = '\0';
	//				if (temp3 < temp2) {
	//					i1 = 0;
	//					ix = 0;
	//					for (; ix < len2 + 1; ix++) {
	//						temp3[ix] = temp1[ix];
	//					}
	//					i1 = ix;
	//					temp3[len2 + 1] = '\0';
	//				}
	//				siZ1 = 0;
	//				for (int i = 0; temp3[i] != '\0'; i++) {
	//					siZ1++;
	//				}
	//				siZ2 = 0;
	//				for (int i = 0; temp2[i] != '\0'; i++) {
	//					siZ2++;
	//				}
	//				UprNo = CharToHugInt(temp3, siZ1);
	//				LowrNo = CharToHugInt(temp2, siZ2);

	//				while (UprNo > LowrNo) {
	//					UprNo = UprNo - LowrNo;
	//					Q++;
	//				}
	//				sampl = atoi(UprNo.GetData());

	//				samp = iNtoa(sampl);

	//				temp5[time1] = (Q + 48);

	//				time1++;
	//			}
	//			else if (time1 > 0) {
	//				//		temp3 = new char[len2 + 1];
	//				int isu = 0;
	//				int ix = 0;
	//				for (; samp[ix] != '\0'; ix++) {
	//					isu++;
	//				}
	//				for (; ix < isu; ix++) {
	//					temp3[ix] = samp[ix];
	//				}
	//				int ul = i1;
	//				i1++;
	//				temp3[isu] = temp2[i1];/////////////////////////////
	//				temp3[isu + 1] = '\0';
	//				int cal = isu + 1;
	//				if (temp3 < temp2) {
	//					while (temp3 < temp2) {
	//						i1++;
	//						temp3[cal] = temp2[i1];
	//						cal++;
	//						temp3[cal] = '\0';
	//					}
	//				}
	//				siZ1 = 0;
	//				for (int i = 0; temp3[i] != '\0'; i++) {
	//					siZ1++;
	//				}
	//				UprNo = CharToHugInt(temp3, siZ1);
	//				while (UprNo > LowrNo) {
	//					UprNo = UprNo - LowrNo;
	//					Q++;
	//				}
	//				sampl = atoi(UprNo.GetData());

	//				samp = iNtoa(sampl);
	//				sampl2 = atoi(samp);

	//				temp5[time1] = (Q + 48);

	//				time1++;
	//			}
	//		}

	//		int sizeQ = 0;
	//		for (int i = 0; temp5[i] != '\0'; i++) {
	//			sizeQ++;
	//		}

	//		samp3 = sampl2 * 100;
	//		//temp3 = atoi(samp3);

	//		siZ1 = 0;
	//		for (int i = 0; temp3[i] != '\0'; i++) {
	//			siZ1++;
	//		}

	//		UprNo = CharToHugInt(temp3, siZ1);

	//		while (UprNo > LowrNo) {
	//			UprNo = UprNo - LowrNo;
	//			div++;
	//		}

	//		if (div > 45) {
	//			temp5[sizeQ] = (((temp5[sizeQ] - 48) + 1) + 48);
	//		}

	//		HugeInteger temp = CharToHugInt(temp5, sizeQ);
	//		delete[] temp1;
	//		temp1 = nullptr;
	//		delete[] temp2;
	//		temp2 = nullptr;
	//		delete[] temp3;
	//		temp3 = nullptr;
	//		delete[] temp4;
	//		temp4 = nullptr;
	//		delete[] temp5;
	//		temp5 = nullptr;

	//		return temp;
	//	}
	//}

	HugeInteger operator/(int num) {
		HugeInteger Quot;
		HugeInteger temp = IntToHugInt(num);
		Quot = (*this / temp);
		temp.~HugeInteger();

		return Quot;
	}

	friend HugeInteger operator/(int num, HugeInteger &objh) {
		HugeInteger Quot;
		HugeInteger temp = IntToHugInt(num);
		Quot = (temp / objh);
		temp.~HugeInteger();

		return Quot;
	}

	HugeInteger squareRoot() {
		HugeInteger SqRt;
		HugeInteger Prod;
		HugeInteger temp;
		HugeInteger temp2("1");
		int w = 0;
		for (int i = 0; this->data[i] != '\0'; i++) { w++; }
		w = pow(10, w - 2);
		HugeInteger temp3 = IntToHugInt(w);

		char zer[] = "0";
		//int x = 0;
		bool com = true;
		if (compare(this->data, zer)) {
			temp.size = 1;
			temp.data = new char[2];
			temp.data[0] = '0';
			temp.data[1] = '\0';
		}
		else {
			HugeInteger temp1 = *this;
			temp = (temp1) / temp3;
			while (com) {
				Prod = (temp * temp);
				com = (Prod <= *this);
				if (com) {
					temp = temp + temp2;
				}
			}
			temp1.~HugeInteger();
		}
		SqRt = temp - temp2;

		return SqRt;
	}


	friend istream &operator>>(istream &in, HugeInteger &q) {
		char *temp;
		int i;
		cout << "Enter the total digits in the HugeInt: \n";
		in >> i;
		temp = new char[i + 1];
		cout << "Enter the HugeInt: \n";
		in.ignore(1, '\n');
		in.clear();
		in.getline(temp, i + 1, '\n');
		q = HugeInteger(temp);
		delete[] temp;

		return in;
	}

	friend ostream &operator<<(ostream &out, HugeInteger q) {
		if (q.data != nullptr) {
			for (int i = 0; i < q.size; i++) {
				out << q.data[i];
			}
		}
		out << endl;

		return out;
	}


	~HugeInteger() {
		delete[]data;
		data = nullptr;
	}
};

int main() {
	//char no1[] = "112";
	//char no2[] = "6727";
	//    HugeInteger h1(3, no1), h2(4, no2);?
	HugeInteger h1("0006327280000"), h2("000000005690");
	cin >> h1;
	cout << h1;
	cin >> h2;
	cout << h2;
	h1++, h2--;
	cout << h1;
	cout << h2;
	cout << h1 << h2 << '\n';
	cout << (h1 == h2) << "\n";
	cout << (h1 != h2) << "\n";
	cout << (h1 < h2) << "\n";
	cout << (h1 > h2) << "\n";
	cout << (h1 <= h2) << "\n";
	cout << (h1 >= h2) << "\n";
	cout << h1 + h2 << "\n";
	cout << h1 - h2 << "\n";
	cout << h1 * h2 << "\n";
	cout << (h1 / h2) << "\n";
	cout << "\nSum of two huge integers is : ";
	HugeInteger h = (h1 + h2);
	cout << h;
	cout << "Difference of two huge integers is : ";
	h = (h1 - h2);
	cout << h;
	cout << "Product of two huge integers is : ";
	h = (h1 * h2);
	cout << h;
	cout << "Division of two huge integers is : ";
	h = (h1 / h2);
	cout << h;
	HugeInteger sh = h.squareRoot();
	cout << sh;


	system("pause");

	return 0;
}
