package com.zaeem.ezcommerce;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Page2Activity extends AppCompatActivity {
    String item, price;
    int imgID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page2);

        String description = "Your Product will be delivered in 5 working days." +
                "Once, order placed will not be be able to cancel it. However, " +
                "you can contact us to make any modification";
        Intent intent = getIntent();
        item = intent.getStringExtra("UniqueItem");
        price = intent.getStringExtra("UniquePrice");
        imgID = intent.getIntExtra("UniqueImage", 0);
        float stars = intent.getFloatExtra("UniqueStars", 0);
        String des = "Description";

        ImageView imageview = (ImageView) findViewById(R.id.imageView3);
        TextView textView1 = (TextView) findViewById(R.id.textView1);
        TextView textView2 = (TextView) findViewById(R.id.textView2);
        TextView textView3 = (TextView) findViewById(R.id.textView3);
        TextView textView4 = (TextView) findViewById(R.id.textView4);
        RatingBar ratingbar = (RatingBar) findViewById(R.id.ratingBar2);
        Button button = (Button) findViewById(R.id.button);

        imageview.setImageResource(imgID);
        textView1.setText(item);
        textView2.setText(price);
        ratingbar.setRating(stars);
        textView3.setText(des);
        textView4.setText(description);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(Page2Activity.this, Page3Activity.class);
                intent1.putExtra("UniqueImage1", imgID);
                intent1.putExtra("UniqueItem1", item);
                intent1.putExtra("UniquePrice1", price);
                Page2Activity.this.startActivity(intent1);
            }
        });
    }

}