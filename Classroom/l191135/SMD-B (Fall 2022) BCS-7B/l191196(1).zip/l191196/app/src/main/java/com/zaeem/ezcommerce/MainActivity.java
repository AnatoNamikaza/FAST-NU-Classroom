package com.zaeem.ezcommerce;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    ArrayList<ProductData> Data = new ArrayList<>();
    public static ArrayList<CartData> cart = new ArrayList<>();
    ProductAdapter adapter;


    private void filter(String text){
        ArrayList<ProductData> filteredData = new ArrayList<>();  ///// initialize empty list every time after search /////

        //// filter the data that is present in original arrayList  ////
        for(ProductData item: Data){
            if(item.getProductname().toLowerCase().contains(text.toLowerCase())){
                filteredData.add(item);
            }
        }

        adapter.filteredList(filteredData);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = (EditText) findViewById(R.id.Editsearch);
        editText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                filter(editable.toString());       /// call this function after every search
            }
        });


        Data.add(new ProductData(R.drawable.bb_passport, "bb passport", 4f, "$750"));
        Data.add(new ProductData(R.drawable.bb_priv, "bb prive", 4.5f, "$880"));
        Data.add(new ProductData(R.drawable.canon, "canon EOS", 3.5f, "$1530"));
        Data.add(new ProductData(R.drawable.iphone_14, "iphone 14", 3.5f, "$1700"));
        Data.add(new ProductData(R.drawable.iphone_airpods, "iphone airpods", 4.5f, "$480"));
        Data.add(new ProductData(R.drawable.key2, "bb key2", 5f, "$1200"));
        Data.add(new ProductData(R.drawable.lens, "Lens", 4.0f, "$800"));

        // setting recyclerview
        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);

        // use a linear layout manager
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);


        adapter = new ProductAdapter(MainActivity.this, Data);
        //RecyclerView.Adapter mAdapter = adapter;
        recyclerView.addItemDecoration(new DividerItemDecoration(this, LinearLayoutManager.VERTICAL));
        recyclerView.setAdapter(adapter);
    }
}