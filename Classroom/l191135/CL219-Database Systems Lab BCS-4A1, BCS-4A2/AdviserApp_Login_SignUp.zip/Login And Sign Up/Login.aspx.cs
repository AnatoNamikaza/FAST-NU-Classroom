﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Database_Project_v0._2
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int empty = 0;

            warning1.Text = warning2.Text = " ";

            SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["connectio_x1"].ToString());

            sqlCon.Open();
            SqlCommand sqlcmd = new SqlCommand("Find_Account", sqlCon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@Email", TextBox.Text.Trim());
            sqlcmd.Parameters.AddWithValue("@Password", TextBox1.Text.Trim());
            SqlParameter Access = new SqlParameter();
            Access.ParameterName = "@Success";
            Access.SqlDbType = SqlDbType.Int;
            Access.Direction = ParameterDirection.Output;
            sqlcmd.Parameters.Add(Access);

            sqlcmd.ExecuteNonQuery();
            int res = Convert.ToInt32(Access.Value);

            if (res == 1)
            {
                Response.Redirect("Home.aspx");
            }
            else if (res == 2)
            {
                warning1.ForeColor = System.Drawing.Color.Red;
                warning1.Text = "Invalid Email";
            }
            else if (res == 3)
            {
                warning2.ForeColor = System.Drawing.Color.Red;
                warning2.Text = "Incorrect Password";
            }
        }
    }
}