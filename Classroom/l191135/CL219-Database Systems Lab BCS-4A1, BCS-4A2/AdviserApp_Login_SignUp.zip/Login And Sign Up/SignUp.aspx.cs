﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Database_Project_v0._2
{
    public partial class SignUp : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int empty = 0;

            warning1.Text = warning2.Text = warning3.Text = warning4.Text = warning5.Text = warning6.Text = " ";

            if (TextBox.Text.Trim() == "")
            {
                warning1.Text = "Name not found.";
                empty++;
            }

            if (TextBox2.Text.Trim() == "")
            {
                warning2.Text = "Email not found.";
                empty++;
            }

            if (TextBox3.Text.Trim() == "")
            {
                warning3.Text = "Phone No not found.";
                empty++;
            }

            if (TextBox4.Text.Trim() == "")
            {
                warning4.Text = "City not found.";
                empty++;
            }

            if (TextBox5.Text.Trim() == "")
            {
                warning5.Text = "Address not found.";
                empty++;
            }

            if (TextBox6.Text.Trim() == "")
            {
                warning6.Text = "Password not found.";
                empty++;
            }

            if (TextBox6.Text.Trim() != TextBox7.Text.Trim())
            {
                warning6.Text = "Password doesnot match.";
                empty++;
            }


            if (Request.Form["CheckBox1"] == null)
            {
                warning6.Text = "Checkbox is unchecked.";
                empty++;
            }

            if (empty > 0) return;

            SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["connectio_x1"].ToString());

            sqlCon.Open();
            SqlCommand sqlcmd = new SqlCommand("Add_New_Account", sqlCon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@Name", TextBox.Text.Trim());
            sqlcmd.Parameters.AddWithValue("@Email", TextBox2.Text.Trim());
            sqlcmd.Parameters.AddWithValue("@PhoneNo", TextBox3.Text.Trim());
            sqlcmd.Parameters.AddWithValue("@City", TextBox4.Text.Trim());
            sqlcmd.Parameters.AddWithValue("@Address", TextBox5.Text.Trim());
            sqlcmd.Parameters.AddWithValue("@Password", TextBox6.Text.Trim());
            SqlParameter Access = new SqlParameter();
            Access.ParameterName = "@Success";
            Access.SqlDbType = SqlDbType.Int;
            Access.Direction = ParameterDirection.Output;
            sqlcmd.Parameters.Add(Access);
            sqlcmd.ExecuteNonQuery();
            int res = Convert.ToInt32(Access.Value);

            if (res == 1)
            {
                Response.Redirect("Login.aspx");
            }
            else if (res == 2)
            {
                warning2.Text = "Email already registered.";
            }
            else if (res == 3)
            {
                warning3.Text = "Contact already registered.";
            }
        }
    }
}