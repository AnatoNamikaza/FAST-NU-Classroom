﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Database_Lab_Project.DAL;

namespace shopewise
{
    public partial class UserMasterPage : System.Web.UI.MasterPage
    {
        static int index = 0;
        string strTemp;
        static int[ , ] productId = new int[10, 2]; // create a matrix of 100 rows and 2 coloumns
        public List<Cart_class> cartItem { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["Email_session"] == null)
            {
                Response.Redirect("login.aspx");
            }
            Cart_DAL tempCS = new Cart_DAL();
            if (HttpContext.Current.Session["Cart"] != null)
            {
                string temp = HttpContext.Current.Session["Cart"].ToString();
                temp = temp.Trim();
                string[] cartParseString = temp.Split(' ');

                //initialization of productId cart 2d arr
                for (int i = 0; i < 10; i++)
                {
                    productId[i, 0] = -1;
                    productId[i, 1] = 0;
                }
                for (int i = 0; i < cartParseString.Length && temp != "" ; i++)
                {
                    // zero index will hold product id
                    productId[i, 0] = Convert.ToInt32(cartParseString[i]);
                    productId[i, 1]++;

                }
                Label1.Text = strTemp;
                cartItem = tempCS.getCartItem(productId, cartParseString.Length);
                index = wordsCount(temp);
            }
        }
        public int wordsCount(string temp)
        {
            int size = 0;
            for (int i = 0; i < temp.Length; i++)
            {
                if (temp[i] == ' ')
                {
                    size++;
                }
            }
            return size;
        }
        public int searchId(int key)
        {
            for (int i = 0; i < 10; i++)
            {
                if (productId[i, 0] == key)
                {
                    return i;
                }
            }
            return -1;
        }

        
        [System.Web.Services.WebMethod]
        public static void removefromCart_cs(string s1)
        {

            if (HttpContext.Current.Session["Cart"] != null && HttpContext.Current.Session["Cart"].ToString() != "")
            {
                int number = Convert.ToInt32(s1);
                for(int i = 0; i< 9; i++)
                {
                    productId[i, 0] = productId[i + 1, 0];
                    productId[i, 1] = productId[i + 1, 1];
                }
                index--;
                string str="";
                for (int i = 0; i< index; i++)
                {
                    str += " " + Convert.ToString(productId[i, 0]);
                }
                str += " 3"; //enter tem value ignore it
                HttpContext.Current.Session["Cart"] = str;
            }
        }

        protected void Refresh(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);
        }


        protected void removeCart(object sender, EventArgs e)
        {
            HttpContext.Current.Session["Cart"] = "";
            Response.Redirect(Request.RawUrl);
        }

        protected void CheckoutCart(object sender, EventArgs e)
        {
            string temp = HttpContext.Current.Session["Cart"].ToString();
            temp = temp.Trim();
            string[] cartParseString = temp.Split(' ');

            //initialization of productId cart 2d arr
            for (int i = 0; i < 10; i++)
            {
                productId[i, 0] = -1;
                productId[i, 1] = 0;
            }
            for (int i = 0; i < cartParseString.Length && temp != ""; i++)
            {
                // zero index will hold product id
                productId[i, 0] = Convert.ToInt32(cartParseString[i]);
                productId[i, 1]++;
            }
            for (int i = 0;  i < cartParseString.Length && temp != ""; i++)
            {
                Products_Records_DAL temp1 = new Products_Records_DAL();
                temp1.Add_to_cart(Session["Email_session"].ToString(), productId[i,0]);
                strTemp = "Order place sucessfully we will deliver your order in 3 days";
            }
            HttpContext.Current.Session["Cart"] = "";
            Response.Redirect(Request.RawUrl);

        }
    }
}