﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Database_Lab_Project.DAL;

namespace final_v1
{
    public partial class productsRemove : System.Web.UI.Page
    {
        public List<product> log_list { set; get; }
        static Products_Records_DAL temp_log = new Products_Records_DAL();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["Email_session"] == null)
            {
                Response.Redirect("login.aspx");
            }
            log_list = temp_log.retriveproductData();
        }

        [System.Web.Services.WebMethod]
        public static void deleteProduct(string s1)
        {
            int id = Convert.ToInt32(s1);
            temp_log.Products_remove(id);  
        }

        protected void Refresh(object sender, EventArgs e)
        {
            Response.Redirect(Request.RawUrl);
        }
    }
}