﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Database_Lab_Project.DAL;


namespace final_v1
{
    public partial class AdminProfile : System.Web.UI.Page
    {
        public Acc_infos profile_item { set; get; }
        type_recognizer_DAL temp_Home_c_p = new type_recognizer_DAL();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["Email_session"] == null)
            {
                Response.Redirect("login.aspx");
            }

            profile_item = temp_Home_c_p.recognizer(Session["Email_session"].ToString());
        }
    }
}