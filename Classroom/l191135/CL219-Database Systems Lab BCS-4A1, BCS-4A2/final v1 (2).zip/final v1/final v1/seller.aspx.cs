﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Database_Lab_Project.DAL;


namespace final_v1
{
    public partial class seller : System.Web.UI.Page
    {
        public List<Seller_Profile_info> log_list { set; get; }
        Seller_Records_DAL temp_log = new Seller_Records_DAL();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["Email_session"] == null)
            {
                Response.Redirect("login.aspx");
            }
            log_list = temp_log.retrivesellerData();
        }
    }
}