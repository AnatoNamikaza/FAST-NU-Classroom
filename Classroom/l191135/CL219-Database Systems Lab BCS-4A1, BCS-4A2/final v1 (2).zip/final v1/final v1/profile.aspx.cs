﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Database_Lab_Project.DAL;

namespace final_v1
{
    public partial class profile : System.Web.UI.Page
    {

        public type_recognizer_DAL check = new type_recognizer_DAL();
        public Acc_infos profile_item = new Acc_infos();
            protected void Page_Load(object sender, EventArgs e)
            {
                if (HttpContext.Current.Session["Email_session"] == null)
                {
                    Response.Redirect("login.aspx");
                }


                profile_item = check.recognizer(Session["Email_session"].ToString());


            }
   
    }
}