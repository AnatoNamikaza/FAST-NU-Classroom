﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using Database_Lab_Project.DAL;

namespace Database_Lab_Project.DAL
{
    public class Account_info
    {
        public string Account_Id;
        public string Account_Name;
        public string Account_rating;
        public string Account_profileImage;
        public string Account_type;
    }

    public class Seller_info
    {
        public string Seller_Id;
        public string Seller_Name;
        public string Seller_description;
        public string Seller_rating;
        public string Seller_shop_location;
        public string Seller_profileImage;
        public string Seller_no_of_sales;
    }

    public class Seller_Profile_info
    {
        public string Seller_Id;
        public string Seller_Name;
        public string Seller_description;
        public string Seller_contact;
        public string Seller_email;
        public string Seller_city;
        public string Seller_rating;
        public string Seller_no_of_sales;
        public string Seller_profileImage;
    }

    public class Consultant_infos
    {
        public string Consultant_Id;
        public string Consultant_Name;
        public string Consultant_description;
        public string Consultant_contact;
        public string Consultant_email;
        public string Consultant_city;
        public string Consultant_rating;
        public string Consultant_no_of_Consultations;
        public string Consultant_profileImage;
        public string Consultant_balance;
    }

    public class Acc_infos
    {
        public string Acc_Id;
        public string Acc_Name;
        public string Acc_type;
        public string Acc_description;
        public string Acc_contact;
        public string Acc_email;
        public string Acc_city;
        public string Acc_rating;
        public string Acc_vals_title;
        public string Acc_vals;
        public string Acc_profileImage;
        public string Acc_balance;
    }

    public class logs_infos
    {
        public string logs_Id;
        public string logs_Account_Id;
        public string logs_Account_Name;
        public string logs_Account_email;
        public string logs_Location;
        public string logs_Device;
        public string logs_Time;
    }

    public class Consultant_record_infos
    {
        public string Request_Id;
        public string Consulter_Id;
        public string Consultant_Id;
        public string Product_Id;
        public string Status;
        public string Recommended_Product_Id;
        public string Consultant_rating;
        public string Consulter_rating;
        public string Date;
    }

    public class Best_Seller_Records_DAL
    {
        public List<Seller_Profile_info> bsd_items { get; set; }

        public List<Seller_Profile_info> retrivebestsellerData()
        {
            SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["shopwise_connection"].ToString());

            sqlCon.Open();
            SqlCommand cm = new SqlCommand("select * from best_seller_data", sqlCon);
            SqlDataReader sdr = cm.ExecuteReader();
            //direct queries run
            bsd_items = new List<Seller_Profile_info>();
            while (sdr.Read())
            {
                Seller_Profile_info temp = new Seller_Profile_info();
                temp.Seller_Id = Convert.ToString(sdr.GetInt32(0));
                temp.Seller_Name = sdr.GetString(1);
                temp.Seller_description = sdr.GetString(2);
                temp.Seller_contact = sdr.GetString(3);
                temp.Seller_email = sdr.GetString(4);
                temp.Seller_city = sdr.GetString(5);
                temp.Seller_rating = Convert.ToString(sdr.GetDouble(6));
                temp.Seller_no_of_sales = Convert.ToString(sdr.GetInt32(7));
                temp.Seller_profileImage = sdr.GetString(8);
                bsd_items.Add(temp);
            }

            sqlCon.Close();

            return bsd_items;
        }
    }

    public class Seller_Records_DAL
    {
        public List<Seller_Profile_info> sd_items { get; set; }

        public List<Seller_Profile_info> retrivesellerData()
        {
            SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["shopwise_connection"].ToString());

            sqlCon.Open();
            SqlCommand cm = new SqlCommand("select * from seller_data", sqlCon);
            SqlDataReader sdr = cm.ExecuteReader();
            //direct queries run
            sd_items = new List<Seller_Profile_info>();
            while (sdr.Read())
            {
                Seller_Profile_info temp = new Seller_Profile_info();
                temp.Seller_Id = Convert.ToString(sdr.GetInt32(0));
                temp.Seller_Name = sdr.GetString(1);
                temp.Seller_description = sdr.GetString(2);
                temp.Seller_contact = sdr.GetString(3);
                temp.Seller_email = sdr.GetString(4);
                temp.Seller_city = sdr.GetString(5);
                temp.Seller_rating = Convert.ToString(sdr.GetDouble(6));
                temp.Seller_no_of_sales = Convert.ToString(sdr.GetInt32(7));
                temp.Seller_profileImage = sdr.GetString(8);
                sd_items.Add(temp);
            }

            sqlCon.Close();

            return sd_items;
        }
    }

    public class Consultant_Records_DAL
    {
        public List<Consultant_infos> cd_items { get; set; }

        public List<Consultant_infos> retriveconsultantData()
        {
            SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["shopwise_connection"].ToString());

            sqlCon.Open();
            SqlCommand cm = new SqlCommand("select * from consultant_data", sqlCon);
            SqlDataReader sdr = cm.ExecuteReader();
            //direct queries run
            cd_items = new List<Consultant_infos>();
            while (sdr.Read())
            {
                Consultant_infos temp = new Consultant_infos();
                temp.Consultant_Id = Convert.ToString(sdr.GetInt32(0));
                temp.Consultant_Name = sdr.GetString(1);
                temp.Consultant_description = sdr.GetString(2);
                temp.Consultant_contact = sdr.GetString(3);
                temp.Consultant_email = sdr.GetString(4);
                temp.Consultant_city = sdr.GetString(5);
                temp.Consultant_rating = Convert.ToString(sdr.GetDouble(6));
                temp.Consultant_no_of_Consultations = Convert.ToString(sdr.GetInt32(7));
                temp.Consultant_profileImage = sdr.GetString(8);
                temp.Consultant_balance = Convert.ToString(sdr.GetInt32(9));
                cd_items.Add(temp);
            }

            sqlCon.Close();

            return cd_items;
        }

        public Consultant_infos retriveconsultantProfileData(string id)
        {
            SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["shopwise_connection"].ToString());

            sqlCon.Open();
            SqlCommand cm = new SqlCommand("select * from dbo.consultant_details('" + id + "')", sqlCon);
            SqlDataReader sdr = cm.ExecuteReader();
            //direct queries run
            Consultant_infos temp = new Consultant_infos();
            if (sdr.Read())
            {
                temp.Consultant_Id = Convert.ToString(sdr.GetInt32(0));
                temp.Consultant_Name = sdr.GetString(1);
                temp.Consultant_description = sdr.GetString(2);
                temp.Consultant_contact = sdr.GetString(3);
                temp.Consultant_email = sdr.GetString(4);
                temp.Consultant_city = sdr.GetString(5);
                temp.Consultant_rating = Convert.ToString(sdr.GetDouble(6));
                temp.Consultant_no_of_Consultations = Convert.ToString(sdr.GetInt32(7));
                temp.Consultant_profileImage = sdr.GetString(8);
                temp.Consultant_balance = Convert.ToString(sdr.GetInt32(9));
                sqlCon.Close();
            }

            sqlCon.Close();

            return temp;
        }

    }

    public class type_recognizer_DAL
    {

        public Acc_infos recognizer(string email)
        {
            SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["shopwise_connection"].ToString());

            sqlCon.Open();
            Acc_infos temp = new Acc_infos();
            SqlCommand sqlcmd = new SqlCommand("get_recognize", sqlCon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@in_email", email);
            SqlParameter
                Access = new SqlParameter(),
                Access1 = new SqlParameter(),
                Access2 = new SqlParameter(),
                Access3 = new SqlParameter(),
                Access4 = new SqlParameter(),
                Access5 = new SqlParameter(),
                Access6 = new SqlParameter(),
                Access7 = new SqlParameter(),
                Access8 = new SqlParameter(),
                Access9 = new SqlParameter(),
                Access10 = new SqlParameter();
            Access.ParameterName = "@Acc_Id";
            Access1.ParameterName = "@Acc_Name";
            Access2.ParameterName = "@Acc_type";
            Access3.ParameterName = "@Acc_description";
            Access4.ParameterName = "@Acc_contact";
            Access5.ParameterName = "@Acc_city";
            Access6.ParameterName = "@Acc_rating";
            Access7.ParameterName = "@Acc_vals_title";
            Access8.ParameterName = "@Acc_vals";
            Access9.ParameterName = "@Acc_profileImage";
            Access10.ParameterName = "@Acc_balance";

            Access.SqlDbType = SqlDbType.Int;
            Access1.SqlDbType = SqlDbType.VarChar;
            Access1.Size = 32;
            Access2.SqlDbType = SqlDbType.VarChar;
            Access2.Size = 20;
            Access3.SqlDbType = SqlDbType.VarChar;
            Access3.Size = 100;
            Access4.SqlDbType = SqlDbType.VarChar;
            Access4.Size = 32;
            Access5.SqlDbType = SqlDbType.VarChar;
            Access5.Size = 32;
            Access6.SqlDbType = SqlDbType.VarChar;
            Access6.Size = 32;
            Access7.SqlDbType = SqlDbType.VarChar;
            Access7.Size = 32;
            Access8.SqlDbType = SqlDbType.VarChar;
            Access8.Size = 20;
            Access9.SqlDbType = SqlDbType.VarChar;
            Access9.Size = 50;
            Access9.SqlDbType = SqlDbType.VarChar;
            Access9.Size = 50;
            Access10.SqlDbType = SqlDbType.VarChar;
            Access10.Size = 32;

            Access.Direction = ParameterDirection.Output;
            Access1.Direction = ParameterDirection.Output;
            Access2.Direction = ParameterDirection.Output;
            Access3.Direction = ParameterDirection.Output;
            Access4.Direction = ParameterDirection.Output;
            Access5.Direction = ParameterDirection.Output;
            Access6.Direction = ParameterDirection.Output;
            Access7.Direction = ParameterDirection.Output;
            Access8.Direction = ParameterDirection.Output;
            Access9.Direction = ParameterDirection.Output;
            Access10.Direction = ParameterDirection.Output;


            sqlcmd.Parameters.Add(Access);
            sqlcmd.Parameters.Add(Access1);
            sqlcmd.Parameters.Add(Access2);
            sqlcmd.Parameters.Add(Access3);
            sqlcmd.Parameters.Add(Access4);
            sqlcmd.Parameters.Add(Access5);
            sqlcmd.Parameters.Add(Access6);
            sqlcmd.Parameters.Add(Access7);
            sqlcmd.Parameters.Add(Access8);
            sqlcmd.Parameters.Add(Access9);
            sqlcmd.Parameters.Add(Access10);
            sqlcmd.ExecuteNonQuery();
            temp.Acc_Id = Access.Value.ToString();
            temp.Acc_Name = Access1.Value.ToString();
            temp.Acc_type = Access2.Value.ToString();
            temp.Acc_description = Access3.Value.ToString();
            temp.Acc_contact = Access4.Value.ToString();
            temp.Acc_city = Access5.Value.ToString();
            temp.Acc_rating = Access6.Value.ToString();
            temp.Acc_vals_title = Access7.Value.ToString();
            temp.Acc_vals = Access8.Value.ToString();
            temp.Acc_profileImage = Access9.Value.ToString();
            temp.Acc_balance = Access10.Value.ToString();
            temp.Acc_email = email;

            sqlCon.Close();

            return temp;
        }

    }

}