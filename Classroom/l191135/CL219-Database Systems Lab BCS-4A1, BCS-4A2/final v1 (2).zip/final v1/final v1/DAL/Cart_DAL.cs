﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using Database_Lab_Project.DAL;

namespace Database_Lab_Project.DAL
{
    public class Cart_DAL
    {
        public List<Cart_class>  getCartItem(int [ , ] array, int size) {
            List<Cart_class> cartItem = new List<Cart_class>();
            for (int i = 0; i < size; i++) {
                SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["shopwise_connection"].ToString());

                sqlCon.Open();
                SqlCommand cm = new SqlCommand(" select Product_ID, Product_Name, Product_Profile_Image, Product_Price from Products where Product_ID = '" + Convert.ToInt32(array[i,0]) + "'" , sqlCon);
                SqlDataReader sdr = cm.ExecuteReader();
                if (sdr.Read()) {
                    Cart_class temp = new Cart_class();
                    temp.ProductID = Convert.ToString(sdr.GetInt32(0));
                    temp.Productname = sdr.GetString(1);
                    temp.image= sdr.GetString(2);
                    temp.price = Convert.ToString(sdr.GetDouble(3));
                    temp.CartID = Convert.ToString(i);
                    temp.quantity = Convert.ToString(array[i, 1]);
                    cartItem.Add(temp);
                }
            }
            return cartItem;
        }
    }
}