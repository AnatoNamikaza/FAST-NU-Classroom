﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using Database_Lab_Project.DAL;

namespace Database_Lab_Project.DAL
{
    public class product
    {
        public string product_Id;
        public string product_Name;
        public string product_price;
        public string product_description;
        public string product_rating;
        public string product_seller_id;
        public string product_shop_location;
        public string product_profileImage;
        public string product_demoImage;
        public string product_no_of_sales;
    }

    public class Products_Records_DAL
    {
        public List<product> sd_items { get; set; }

        public List<product> retriveproductData()
        {
            SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["shopwise_connection"].ToString());

            sqlCon.Open();
            SqlCommand cm = new SqlCommand("select * from Products", sqlCon);
            SqlDataReader sdr = cm.ExecuteReader();
            //direct queries run
            sd_items = new List<product>();
            while (sdr.Read())
            {
                product temp = new product();
                temp.product_Id = Convert.ToString(sdr.GetInt32(0));
                temp.product_Name= sdr.GetString(1);
                temp.product_price= Convert.ToString(sdr.GetDouble(2));
                temp.product_description = sdr.GetString(3);
                temp.product_rating= Convert.ToString(sdr.GetDouble(4));
                temp.product_seller_id = Convert.ToString(sdr.GetInt32(5)); 
                temp.product_shop_location = sdr.GetString(6); 
                temp.product_profileImage = sdr.GetString(7);
                temp.product_demoImage = sdr.GetString(8);
                temp.product_no_of_sales= Convert.ToString(sdr.GetInt32(9));
                sd_items.Add(temp);
            }

            sqlCon.Close();

            return sd_items;
        }

        public void Products_remove(int id)
        {
            SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["shopwise_connection"].ToString());

            sqlCon.Open();
            SqlCommand cm = new SqlCommand("delete from Purchase_Records where Product_ID = " + id.ToString(), sqlCon);
            cm.ExecuteNonQuery();
            cm = new SqlCommand("delete from Products where Product_ID = " + id.ToString(), sqlCon);
            cm.ExecuteNonQuery();
            sqlCon.Close();
        }

        public void Add_to_cart(string email, int id)
        {
            SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["shopwise_connection"].ToString());

            sqlCon.Open();
            SqlCommand sqlcmd = new SqlCommand("add_to_order", sqlCon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@in_email", email);
            sqlcmd.Parameters.AddWithValue("@in_p_id", id);
            sqlcmd.ExecuteNonQuery();
            sqlCon.Close();
        }

        public int Add_to_products(string name, string price, string s_id, string Shop_Loc, string Desc, string P_img, string D_img)
        {
            SqlConnection sqlCon = new SqlConnection(ConfigurationManager.ConnectionStrings["shopwise_connection"].ToString());

            sqlCon.Open();
            SqlCommand sqlcmd = new SqlCommand("string name", sqlCon);
            sqlcmd.CommandType = CommandType.StoredProcedure;
            sqlcmd.Parameters.AddWithValue("@in_p_name", name);
            sqlcmd.Parameters.AddWithValue("@in_p_price", price);
            sqlcmd.Parameters.AddWithValue("@in_p_s_id", s_id);
            sqlcmd.Parameters.AddWithValue("@in_p_shop_location", Shop_Loc);
            sqlcmd.Parameters.AddWithValue("@in_p_description", Desc);
            sqlcmd.Parameters.AddWithValue("@in_p_p_img", P_img);
            sqlcmd.Parameters.AddWithValue("@in_p_d_img", D_img);
            SqlParameter Access = new SqlParameter();
            Access.ParameterName = "@out_res";
            Access.SqlDbType = SqlDbType.Int;
            Access.Direction = ParameterDirection.Output;
            sqlcmd.Parameters.Add(Access);

            sqlcmd.ExecuteNonQuery();
            int res = Convert.ToInt32(Access.Value);

            sqlCon.Close();
            return res;

        }
    }

}