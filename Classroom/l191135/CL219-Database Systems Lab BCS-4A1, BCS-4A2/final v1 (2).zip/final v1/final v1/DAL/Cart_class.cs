﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Database_Lab_Project.DAL
{
    public class Cart_class
    {
        public string image;
        public string ProductID;
        public string Productname;
        public string price;
        public string CartID;
        public string quantity;

    }
}