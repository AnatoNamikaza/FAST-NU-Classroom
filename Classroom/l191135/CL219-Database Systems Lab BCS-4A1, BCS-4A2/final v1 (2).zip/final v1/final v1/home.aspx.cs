﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using Database_Lab_Project.DAL;

namespace shope_wise
{
    public partial class home : System.Web.UI.Page
    {
        public List<product> Product_list { set; get; }
        public List<Seller_Profile_info> best_seller_list { set; get; }
        public List<Consultant_infos> best_Consultant_list { set; get; }
        home_DAL temp_Home = new home_DAL();
        Best_Seller_Records_DAL temp_Home_best_sellers = new Best_Seller_Records_DAL();
        Consultant_Records_DAL temp_Home_Consultant = new Consultant_Records_DAL();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["Email_session"] == null)
            {
                Response.Redirect("login.aspx");
            }
            Product_list = temp_Home.retriveProductData();
            best_seller_list = temp_Home_best_sellers.retrivebestsellerData();
            best_Consultant_list = temp_Home_Consultant.retriveconsultantData();
            
        }

        [System.Web.Services.WebMethod]
        public static void addIntoCart_CS(string s1)
        {

            HttpContext.Current.Session["Cart"].ToString();

            if (HttpContext.Current.Session["Cart"] == null)
            {
                HttpContext.Current.Session["Cart"] = s1;
            }
            else
            {
                string cart = HttpContext.Current.Session["Cart"].ToString();
                cart = cart + " "+ s1 +" ";
                cart = cart.Trim();
                HttpContext.Current.Session["Cart"] = cart;

            }
        }
        
        protected void removeCart(object sender, EventArgs e)
        {
            HttpContext.Current.Session["Cart"] = "";
        }
    }
}