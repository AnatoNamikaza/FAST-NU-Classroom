import matplotlib.pyplot as plt
import pandas as pd
import numpy as np

df =  pd.read_csv('fifa_data.csv')
mylabels = ["under 125","125-150","150-175","175-200","over 200"]
data_col = df["Weight"]

for i in range(0,len(data_col)):
    if data_col[i] != "":
        y = data_col[i].split("lbs")
        data_col[i] = y[0]

r1,r2,r3,r4,r5 = [],[],[],[],[]

for y in data_col:
    x = int(y)
    if x < 125: r1.append(x)
    elif x > 200:   r5.append(x)
    elif x in range(125,150):   r2.append(x)
    elif x in range(150,175):   r3.append(x)
    elif x in range(175,200):   r4.append(x)

Dict = {"under 125": len(r1), "125-150": len(r2), "150-175": len(r3), "175-200": len(r4), "over 200": len(r5)}

data = [len(r1), len(r2), len(r3), len(r4), len(r5)]
explode = (0.1, 0.1, 0.1, 0.1, 0.1)
colors = ( "orange", "cyan", "brown", "grey", "indigo")
wp = { 'linewidth' : 1, 'edgecolor' : "green" }
def func(pct, allvalues):
    absolute = int(pct / 100.*np.sum(allvalues))
    return "{:.1f}%\n({:d} g)".format(pct, absolute)

fig, ax = plt.subplots(figsize =(10, 7))
wedges, texts, autotexts = ax.pie(data,
                                  autopct = lambda pct: func(pct, data),
                                  explode = explode,
                                  labels = mylabels,
                                  shadow = False,
                                  colors = colors,
                                  startangle = 90,
                                  wedgeprops = wp,
                                  textprops = dict(color ="black"))

ax.legend(wedges, mylabels,
          title ="Weights range in lbs",
          loc ="center left",
          bbox_to_anchor =(1, 0, 0.5, 1))
 
plt.setp(autotexts, size = 8, weight ="bold")
ax.set_title("Weight of Professional Soccer Players (lbs)")
plt.show()
