File_1 = 0

try:
    File_1 = open('textfile.txt', 'r')
except:
    print('File not accessable (-_-)')

text_in_file = File_1.read()
File_1.close()
print("\n__________________________________________\n")
print(text_in_file)
print("\n__________________________________________\n")
text_in_file = text_in_file.replace('\n', ' ')
text_in_file = text_in_file.replace('(', ' ')
text_in_file = text_in_file.replace(')', ' ')
text_in_file = text_in_file.replace(',', ' ')
text_in_file = text_in_file.replace('.', ' ')
print("\n__________________________________________\n")
print(text_in_file)
print("\n__________________________________________\n")
words = text_in_file.split(' ')
print("\n__________________________________________\n")
print(words)
print("\n__________________________________________\n")

length_words = []

Max_len = 0
for wrd in words:
    if len(wrd) > Max_len:
        Max_len = len(wrd) 

print("Length of the 1st largest word is: ", Max_len)
print("Length of the 2nd largest word is: ", (Max_len - 1))

[length_words.append(wrd) for wrd in words if len(wrd) == (Max_len - 1) and wrd not in length_words]
print("\n__________________________________________\n")
print("Words with 2nd largest length are:\n")
print(length_words)
print("\n__________________________________________\n")
