import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn_extra.cluster import KMedoids

dataset = pd.read_csv("credit_card.csv")
#X = dataset[['BALANCE', 'PURCHASES']]
X = dataset.iloc[:, [1,3]].values
#print(X)

kmeans = KMeans(n_clusters=8)
kmeans.fit(X)
y_kmeans = kmeans.predict(X)
centers = kmeans.cluster_centers_
plt.scatter(X[:, 0], X[:, 1], c=y_kmeans, s=5, cmap='viridis')
plt.scatter(centers[:, 0], centers[:, 1], c='black', s=20, alpha=0.5)
plt.show()

Kmedoids = KMedoids(n_clusters=8)
Kmedoids.fit(X)
centers = Kmedoids.cluster_centers_
plt.scatter(X[:, 0], X[:, 1], c='blue', s=5, cmap='viridis')
plt.scatter(centers[:, 0], centers[:, 1], c='white', s=20, alpha=0.5)
plt.show()

print("Done")