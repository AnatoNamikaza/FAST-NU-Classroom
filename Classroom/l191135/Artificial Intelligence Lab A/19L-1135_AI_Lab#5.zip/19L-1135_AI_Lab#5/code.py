#Part-1
#----------------------------------
import numpy as np
import matplotlib

w, h = 1000, 700
data = np.zeros((h, w,3), dtype=np.uint8)
#print(data)
data[0:256, 0:256] = [255, 145, 0]
data[0:256, 256:512] = [255, 200, 0]
data[0:256, 512:768] = [255, 230, 0]
data[256:512, 256:512] = [255, 100, 255]
data[512:, 512:] = [125, 145, 255]
data[256:256, 256:256] = [110, 145, 155]
data[512:768, 512:600] = [125, 145, 255]
matplotlib.pyplot.imshow(data)

#data[0:256, 0:256] = [255, 255, 255] # red patch in upper left


#Part-2
#----------------------------------
import pandas as pd
df = pd.read_csv("GHCN_daily_data.csv",header=None)
df.columns=['station', 'date', 'observation', 'value', 'mflag', 'qflag', 'sflag', 'obstime']

select_rows=df.loc[(df['qflag'].isna()) & (df['station'].astype(str).str.startswith('US')) & (df['observation'].astype(str).str.contains('TMIN'))]
select_rows["value"]=select_rows["value"].div(10)
print(select_rows)


output =select_rows[['station', 'date' , 'observation']]
output.head()
output.to_csv("GHCN_output.csv")


#Part-3
#----------------------------------
import matplotlib.pyplot as plt
dog_ratings = pd.read_csv("twitter_dog_rates_data.csv")
dog_ratings['rating'] = dog_ratings['text'].str.extract('(^\d*)', flags=0, expand=True)
print('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
print('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
print('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
print('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
print('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
print('+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++')
dog_ratings.info()


import matplotlib.pyplot as plt
dog_ratings = pd.read_csv("twitter_dog_rates_data.csv")
plt.xticks(rotation=25)
plt.plot(dog_ratings['timestamp'], dog_ratings['rating'], 'b.', alpha=0.5)
plt.plot(dog_ratings['timestamp'], dog_ratings['prediction'], 'r-', linewidth=3)
plt.show()

dog_ratings.head()