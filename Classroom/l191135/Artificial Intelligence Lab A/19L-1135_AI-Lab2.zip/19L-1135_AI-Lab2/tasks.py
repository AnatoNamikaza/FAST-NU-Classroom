#Task---1
def remove_20(nums):
    return [num for num in nums if num != 20]
list1 = [5, 20, 15, 20, 25, 50, 20]
print(remove_20(list1))

#Task---2
def swap_20_with_200(nums):
    if 20 in nums: nums[nums.index(20)] = 200
list2 = [5, 10, 15, 20, 25, 50, 20]
swap_20_with_200(list1)
print(list2)

#Task---3
def uppercase_cars_with_below_50000_KG(dict):
    return [names.upper() for names in dict if dict[names] < 50000]
dict = {"Sedan": 1500, "SUV": 2000, "Pickup": 2500, "Minivan": 1600, "Van": 2400, "Semi": 13600, "Bicycle": 7, "Motorcycle": 110}
print(uppercase_cars_with_below_50000_KG(dict))

#Task---4
tuple1 = (('a', 23), ('b', 37), ('c', 11), ('d',29))
print(sorted(tuple1, key = lambda X:X[1]))

#Task---5
def same_2nd_values(dict):
    for num in dict:
        if num != 45: return False
    return True    
tuple2 = (45, 45, 450, 45)
print(same_2nd_values(tuple2))

#Task---6
def Tuple_Repres():
    return (('25 Jan 2001', 43.50, 25, 'CAT', 92.45),
            ('25 Jan 2001',42.80,50,'DD',51.19),
            ('25 Jan 2001',42.10,75,'EK',34.87),
            ('25 Jan 2001',37.58,100,'GM',37.58))

def Total_Stock(tup):
    return [num[1] * num[2] for num in tup]

def Total_Gain_Loss(tup):
    return [(num[4] * num[2]) - (num[1] * num[2])  for num in tup]


Data = Tuple_Repres()
print(Data)

print(Total_Stock(Data))
print(Total_Gain_Loss(Data))
