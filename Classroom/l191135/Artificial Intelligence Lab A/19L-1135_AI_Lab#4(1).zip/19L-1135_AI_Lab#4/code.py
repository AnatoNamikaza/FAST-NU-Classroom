#Task-1
nums = [1, 2, 3, 4, 5]
print(nums)
print("\nSquare and Cube of every number of the list:")
sqr_cube_nums = list(map(lambda x: (x ** 2, x ** 3), nums))
print(sqr_cube_nums)

#Task-2
class rectangle:
    "This is a rectangle class."
    length  = 0
    width   = 0
    def __init__(self, len = 0, wid = 0):
        self.length = len
        self.width = wid

    def Area(self):
        return (self.length * self.width)    

rect_1 = rectangle(4,5)
print("\nArea of rectangle:")
print(rect_1.Area())

#Task-3
from collections import deque as que_

from matplotlib.pyplot import table
Q = que_()
Q.append('a')
Q.append('b')
Q.append('c')
print(Q)
print("\n================\n")
print(Q.pop())

#Lab_Quiz_1
File_1 = 0

try:
    File_1 = open('Text_1.txt', 'r')
except:
    print('File_1 not accessable (-_-)')

text_in_file = File_1.read()
print(text_in_file)
text_in_lower = text_in_file.lower()
print(text_in_lower)
words = text_in_lower.split(' ')
print(words)

clear_words         = []
clear_words_occ     = []
clear_words_pro     = []
[clear_words.append(wrd) for wrd in words if wrd.isalpha() == True]        
[clear_words_occ.append(clear_words.count(wrd)) for wrd in clear_words]
[clear_words_pro.append(clear_words.count(wrd)/len(words)) for wrd in clear_words]

print(clear_words)
print(clear_words_occ)
print(clear_words_pro)

