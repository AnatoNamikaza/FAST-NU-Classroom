#task-1
X = set([1,3,5])
Y = set([2,4,6])

print( ( X | Y ) - X)
print('--------------')
print('Task-1 is done')
print('--------------')

#task-2
P=8
Q=0

try:
    R = P / Q
    print('P / Q = ', R)
except:
     print('Division by Zero is not possible')
finally:
    print('--------------')
    print('Task-2 is done')
    print('--------------')

#task-3
File_1, File_2 = 0, 0

try:
    File_1 = open('Alphabets.txt', 'r')
except:
    print('File_1 not accessable (-_-)')

text_in_file = File_1.read()

try:
    File_1.close()
except:
    print('File_1 didnot close (-_-)')

try:
    File_2 = open('ReverseAlphabets.txt', 'w+')
except:
    print('File_2 not accessable (-_-)')

str_len =  len(text_in_file) - 1

while str_len > -1:
    try:
        File_2.write(text_in_file[str_len])
    except:
        print('File_2 was not written (-_-)')
    str_len -= 1
File_2.write('\n')
File_2.write(str(len(text_in_file)))

try:
    File_2.close()
except:
    print('File_2 didnot close (-_-)')

print('--------------')
print('Task-3 is done')
print('--------------')

